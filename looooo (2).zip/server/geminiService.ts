import { GoogleGenAI, Type } from '@google/genai';
import type { Character, StoryGenre, StoryScript } from '../src/types/studio.js';

export interface StoryGenerationInput {
  title: string;
  genre: StoryGenre;
  mainIdea: string;
  targetAudience: string;
  desiredDuration: string;
  sceneCount: number;
  emotionalTone: string;
  endingType: string;
  visualStyle: string;
  characters: Character[];
}

export function isGeminiConfigured(): boolean {
  const key = process.env.GEMINI_API_KEY?.trim() ?? '';
  return Boolean(key && key !== 'MY_GEMINI_API_KEY');
}

export async function generateJapaneseStory(input: StoryGenerationInput): Promise<StoryScript> {
  if (!isGeminiConfigured()) {
    throw new Error('GEMINI_API_KEY is not configured in server secrets.');
  }

  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const characterSheet = input.characters.length
    ? input.characters
        .map(
          (c) =>
            `- Name: ${c.name} | Age: ${c.ageDescription} | Personality: ${c.personality} | Appearance: ${c.appearance} | Clothing: ${c.clothing}`,
        )
        .join('\n')
    : 'No fixed characters provided. Create original Japanese characters with clear names and visual traits.';

  const sceneCount = Math.min(Math.max(Number(input.sceneCount) || 6, 3), 24);

  const systemInstruction = `You are a veteran Japanese Motion Comic director, screenwriter, and storyboard planner.
Write 100% original Japanese stories with natural, literary, cinematic Japanese narration and character dialogue.
STRICT ORIGINALITY POLICY:
- Never copy, reference, or imitate existing copyrighted manga, anime, light novels, or recognizable protected characters/IP.
- Every character, setting, and plot twist must be completely original.
VISUAL CONTINUITY:
- Always preserve exact character physical traits and clothing in each scene's English ComfyUI imagePrompt.
- Keep visual style aligned with "${input.visualStyle}" in 16:9 widescreen cinematic framing.
- Output strictly valid JSON matching the schema.`;

  const prompt = `Create an original Japanese Motion Comic episode script and complete scene plan.

Project Title / Episode Seed: ${input.title}
Genre: ${input.genre}
Core Idea: ${input.mainIdea}
Target Audience: ${input.targetAudience}
Desired Duration: ${input.desiredDuration}
Exact Number of Scenes: ${sceneCount}
Emotional Tone: ${input.emotionalTone}
Ending Type: ${input.endingType}

Defined Characters (preserve traits consistently across all scenes):
${characterSheet}

Requirements:
- Write natural Japanese for japaneseTitle, synopsis, narration, dialogue lines, and sceneDescription.
- Write concise director cues for emotionalDirection, visualDescription, and transition.
- Write high-detail Stable Diffusion / ComfyUI English imagePrompt and negativePrompt for each scene, preserving character appearance and clothing.
- Assign cameraMovement from: static, slow_zoom_in, slow_zoom_out, pan_left, pan_right, tilt_up, dramatic_push.
- Assign realistic durationSeconds per scene so total matches ${input.desiredDuration}.`;

  const response = await ai.models.generateContent({
    model: 'gemini-4-hydrogen',
    contents: prompt,
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          japaneseTitle: { type: Type.STRING, description: 'Original Japanese title of the episode.' },
          synopsis: { type: Type.STRING, description: 'Brief Japanese synopsis.' },
          narratorDirection: {
            type: Type.STRING,
            description: 'Voice direction for the deep Japanese male narrator.',
          },
          estimatedDurationSec: { type: Type.INTEGER },
          scenes: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                sceneNumber: { type: Type.INTEGER },
                location: { type: Type.STRING },
                timeOfDay: { type: Type.STRING },
                mood: { type: Type.STRING },
                narration: { type: Type.STRING, description: 'Natural Japanese narration text.' },
                dialogue: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      characterName: { type: Type.STRING },
                      line: { type: Type.STRING, description: 'Japanese spoken dialogue line.' },
                      emotion: { type: Type.STRING },
                    },
                    required: ['characterName', 'line', 'emotion'],
                  },
                },
                characters: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
                sceneDescription: { type: Type.STRING },
                emotionalDirection: { type: Type.STRING },
                visualDescription: { type: Type.STRING },
                transition: { type: Type.STRING },
                imagePrompt: { type: Type.STRING },
                negativePrompt: { type: Type.STRING },
                cameraMovement: { type: Type.STRING },
                durationSeconds: { type: Type.INTEGER },
              },
              required: [
                'sceneNumber',
                'location',
                'timeOfDay',
                'mood',
                'narration',
                'dialogue',
                'characters',
                'sceneDescription',
                'emotionalDirection',
                'visualDescription',
                'transition',
                'imagePrompt',
                'negativePrompt',
                'cameraMovement',
                'durationSeconds',
              ],
            },
          },
        },
        required: ['japaneseTitle', 'synopsis', 'narratorDirection', 'estimatedDurationSec', 'scenes'],
      },
    },
  });

  const rawText = response.text?.trim();
  if (!rawText) {
    throw new Error('Gemini returned an empty response.');
  }

  const parsed = JSON.parse(rawText) as StoryScript;
  const validMoves = new Set([
    'static',
    'slow_zoom_in',
    'slow_zoom_out',
    'pan_left',
    'pan_right',
    'tilt_up',
    'dramatic_push',
  ]);

  parsed.japaneseTitle =
    typeof parsed.japaneseTitle === 'string'
      ? parsed.japaneseTitle.trim().slice(0, 300)
      : input.title.slice(0, 300);
  parsed.synopsis = typeof parsed.synopsis === 'string' ? parsed.synopsis.trim() : '';
  parsed.narratorDirection =
    typeof parsed.narratorDirection === 'string' ? parsed.narratorDirection.trim() : '';
  parsed.estimatedDurationSec = Math.max(10, Math.round(Number(parsed.estimatedDurationSec) || 180));

  parsed.scenes = (Array.isArray(parsed.scenes) ? parsed.scenes : [])
    .slice(0, 50)
    .map((scene, index) => ({
      ...scene,
      sceneNumber: Number(scene.sceneNumber) || index + 1,
      cameraMovement: validMoves.has(scene.cameraMovement) ? scene.cameraMovement : 'slow_zoom_in',
      durationSeconds: Math.max(3, Math.min(45, Math.round(Number(scene.durationSeconds) || 8))),
      dialogue: Array.isArray(scene.dialogue) ? scene.dialogue : [],
      characters: Array.isArray(scene.characters) ? scene.characters : [],
      generatedImageUrl: '',
      generationStatus: 'pending',
    }));

  return parsed;
}
