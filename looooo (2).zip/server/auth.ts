import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type { NextFunction, Request, Response } from 'express';
import { getApp, getApps, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';

export interface AuthenticatedUser {
  uid: string;
  email: string | null;
  name: string | null;
}

export interface AuthenticatedRequest extends Request {
  authUser?: AuthenticatedUser;
  workerId?: string;
}

function getFirebaseProjectId(): string | null {
  try {
    const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
    if (!fs.existsSync(configPath)) return null;
    const raw = fs.readFileSync(configPath, 'utf-8');
    const parsed = JSON.parse(raw) as { projectId?: string };
    return parsed.projectId && parsed.projectId !== 'remixed-project-id' ? parsed.projectId : null;
  } catch {
    return null;
  }
}

export function ensureFirebaseAdmin(): boolean {
  const projectId = getFirebaseProjectId();
  if (!projectId) return false;
  if (!getApps().length) {
    initializeApp({ projectId });
  }
  return true;
}

export async function requireFirebaseAuth(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): Promise<void> {
  if (!ensureFirebaseAdmin()) {
    res.status(503).json({
      error: 'Firebase project is not configured on the server.',
    });
    return;
  }

  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Missing Bearer authentication token.' });
    return;
  }

  const idToken = authHeader.slice('Bearer '.length).trim();
  if (!idToken) {
    res.status(401).json({ error: 'Empty authentication token.' });
    return;
  }

  try {
    const decoded = await getAuth(getApp()).verifyIdToken(idToken);
    if (!decoded.uid) {
      res.status(401).json({ error: 'Invalid user token.' });
      return;
    }
    req.authUser = {
      uid: decoded.uid,
      email: decoded.email ?? null,
      name: typeof decoded.name === 'string' ? decoded.name : null,
    };
    next();
  } catch (error) {
    console.error('[auth] verifyIdToken failed:', error instanceof Error ? error.message : error);
    res.status(401).json({ error: 'Authentication token is invalid or expired.' });
  }
}

export function isWorkerSecretConfigured(): boolean {
  return Boolean(process.env.WORKER_API_SECRET && process.env.WORKER_API_SECRET.trim().length >= 16);
}

export function requireWorkerAuth(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): void {
  const expectedSecret = process.env.WORKER_API_SECRET?.trim() ?? '';
  if (!expectedSecret || expectedSecret.length < 16) {
    res.status(503).json({
      configured: false,
      error: 'WORKER_API_SECRET is not configured on the server (minimum 16 characters required).',
    });
    return;
  }

  const authHeader = req.headers.authorization;
  const headerSecret = req.headers['x-worker-secret'];
  let providedSecret = '';

  if (typeof authHeader === 'string' && authHeader.startsWith('Bearer ')) {
    providedSecret = authHeader.slice('Bearer '.length).trim();
  } else if (typeof headerSecret === 'string') {
    providedSecret = headerSecret.trim();
  }

  if (!providedSecret) {
    res.status(401).json({ error: 'Missing Worker authentication credential.' });
    return;
  }

  const expectedBuf = Buffer.from(expectedSecret, 'utf8');
  const providedBuf = Buffer.from(providedSecret, 'utf8');

  if (expectedBuf.length !== providedBuf.length || !crypto.timingSafeEqual(expectedBuf, providedBuf)) {
    res.status(403).json({ error: 'Invalid Worker authentication credential.' });
    return;
  }

  next();
}
