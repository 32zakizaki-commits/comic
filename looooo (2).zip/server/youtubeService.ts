export interface YouTubeConfigStatus {
  configured: boolean;
  missingVars: string[];
}

export function getYouTubeConfigStatus(): YouTubeConfigStatus {
  const required = [
    'YOUTUBE_CLIENT_ID',
    'YOUTUBE_CLIENT_SECRET',
    'YOUTUBE_REDIRECT_URI',
    'YOUTUBE_REFRESH_TOKEN',
  ] as const;

  const missingVars = required.filter((key) => !process.env[key]?.trim());
  return {
    configured: missingVars.length === 0,
    missingVars: [...missingVars],
  };
}

export async function prepareYouTubePublish(input: {
  episodeId: string;
  episodeStatus: string;
  title: string;
  description: string;
  tags: string[];
  visibility: 'private' | 'unlisted' | 'public';
  scheduledPublishAt?: string;
}): Promise<{ ok: boolean; message: string; channelTitle?: string }> {
  if (input.episodeStatus !== 'approved') {
    throw new Error('HUMAN_APPROVAL_REQUIRED: Episode must be approved in the Approval Center before YouTube publishing.');
  }

  const status = getYouTubeConfigStatus();
  if (!status.configured) {
    throw new Error(
      `YOUTUBE_NOT_CONFIGURED: Missing server secrets (${status.missingVars.join(', ')}).`,
    );
  }

  // Exchange refresh token for an access token via Google OAuth2
  const tokenResp = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: process.env.YOUTUBE_CLIENT_ID!.trim(),
      client_secret: process.env.YOUTUBE_CLIENT_SECRET!.trim(),
      refresh_token: process.env.YOUTUBE_REFRESH_TOKEN!.trim(),
      grant_type: 'refresh_token',
    }),
  });

  if (!tokenResp.ok) {
    const errText = await tokenResp.text();
    throw new Error(`YouTube OAuth token refresh failed (${tokenResp.status}): ${errText}`);
  }

  const tokenData = (await tokenResp.json()) as { access_token?: string };
  if (!tokenData.access_token) {
    throw new Error('YouTube OAuth response did not include an access_token.');
  }

  // Verify channel ownership before upload
  const channelResp = await fetch(
    'https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true',
    {
      headers: {
        Authorization: `Bearer ${tokenData.access_token}`,
      },
    },
  );

  if (!channelResp.ok) {
    const errText = await channelResp.text();
    throw new Error(`YouTube channel verification failed (${channelResp.status}): ${errText}`);
  }

  const channelData = (await channelResp.json()) as {
    items?: Array<{ snippet?: { title?: string } }>;
  };
  const channelTitle = channelData.items?.[0]?.snippet?.title ?? 'Authenticated Channel';

  return {
    ok: true,
    channelTitle,
    message: `YouTube OAuth verified for channel "${channelTitle}". Video upload queue authorized for manual trigger.`,
  };
}
