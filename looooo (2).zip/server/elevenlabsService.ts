import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const AUDIO_DIR = path.resolve(process.cwd(), '.data', 'uploads', 'audio');

export function isElevenLabsConfigured(): boolean {
  const key = process.env.ELEVENLABS_API_KEY?.trim() ?? '';
  return Boolean(key.length > 0);
}

export async function listElevenLabsVoices(): Promise<
  Array<{ voiceId: string; name: string; category: string; labels: Record<string, string> }>
> {
  if (!isElevenLabsConfigured()) {
    throw new Error('ELEVENLABS_API_KEY is not configured in server secrets.');
  }

  const resp = await fetch('https://api.elevenlabs.io/v1/voices', {
    headers: {
      'xi-api-key': process.env.ELEVENLABS_API_KEY!.trim(),
    },
  });

  if (!resp.ok) {
    const errText = await resp.text();
    throw new Error(`ElevenLabs voices error (${resp.status}): ${errText}`);
  }

  const data = (await resp.json()) as {
    voices?: Array<{
      voice_id: string;
      name: string;
      category?: string;
      labels?: Record<string, string>;
    }>;
  };

  return (data.voices ?? []).map((v) => ({
    voiceId: v.voice_id,
    name: v.name,
    category: v.category ?? 'custom',
    labels: v.labels ?? {},
  }));
}

export async function synthesizeJapaneseVoice(input: {
  text: string;
  voiceId?: string;
  stability?: number;
  similarityBoost?: number;
  style?: number;
  speed?: number;
}): Promise<{
  audioUrl: string;
  filename: string;
  byteLength: number;
  voiceIdUsed: string;
}> {
  if (!isElevenLabsConfigured()) {
    throw new Error('ELEVENLABS_API_KEY is not configured in server secrets.');
  }

  const voiceId =
    input.voiceId?.trim() ||
    process.env.ELEVENLABS_DEFAULT_VOICE_ID?.trim() ||
    'pNInz6obpgDQGcFmaJgB'; // Standard deep male voice fallback if user hasn't set custom ID

  const payload = {
    text: input.text,
    model_id: 'eleven_multilingual_v2',
    language_code: 'ja',
    voice_settings: {
      stability: Math.min(1, Math.max(0, input.stability ?? 0.55)),
      similarity_boost: Math.min(1, Math.max(0, input.similarityBoost ?? 0.78)),
      style: Math.min(1, Math.max(0, input.style ?? 0.25)),
      use_speaker_boost: true,
    },
  };

  const resp = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}`, {
    method: 'POST',
    headers: {
      'xi-api-key': process.env.ELEVENLABS_API_KEY!.trim(),
      'Content-Type': 'application/json',
      Accept: 'audio/mpeg',
    },
    body: JSON.stringify(payload),
  });

  if (!resp.ok) {
    const errText = await resp.text();
    throw new Error(`ElevenLabs TTS error (${resp.status}): ${errText}`);
  }

  const arrayBuffer = await resp.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);

  if (!fs.existsSync(AUDIO_DIR)) {
    fs.mkdirSync(AUDIO_DIR, { recursive: true });
  }

  const filename = `tts_${Date.now()}_${crypto.randomBytes(4).toString('hex')}.mp3`;
  const targetPath = path.resolve(AUDIO_DIR, filename);
  if (!targetPath.startsWith(AUDIO_DIR + path.sep)) {
    throw new Error('Invalid audio output path.');
  }
  fs.writeFileSync(targetPath, buffer);

  return {
    audioUrl: `/api/assets/audio/${filename}`,
    filename,
    byteLength: buffer.byteLength,
    voiceIdUsed: voiceId,
  };
}
