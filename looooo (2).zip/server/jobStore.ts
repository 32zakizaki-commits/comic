import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type {
  ApprovalRecord,
  JobType,
  ProductionJob,
  ProductionStatus,
  WorkerMetrics,
  WorkerNode,
  WorkerStatus,
} from '../src/types/studio.js';

interface StudioQueueState {
  jobs: Record<string, ProductionJob>;
  workers: Record<string, WorkerNode>;
  approvals: Record<string, ApprovalRecord>;
}

const DATA_DIR = path.resolve(process.cwd(), '.data');
const STATE_FILE = path.join(DATA_DIR, 'studio-state.json');
const DEFAULT_LEASE_MS = 120_000; // 2 minutes per heartbeat/progress window
const WORKER_HEARTBEAT_TIMEOUT_MS = 45_000; // 45 seconds before marking Offline

const ALLOWED_JOB_TRANSITIONS: Record<ProductionStatus, ProductionStatus[]> = {
  draft: ['queued', 'cancelled'],
  queued: ['claimed', 'cancelled', 'failed'],
  claimed: ['processing', 'queued', 'failed', 'cancelled'],
  processing: ['uploading', 'completed', 'failed', 'queued', 'cancelled'],
  uploading: ['completed', 'pending_approval', 'failed', 'queued', 'cancelled'],
  completed: ['pending_approval', 'approved', 'rejected', 'queued'],
  failed: ['queued', 'cancelled'],
  cancelled: ['queued'],
  pending_approval: ['approved', 'rejected', 'queued'],
  approved: ['queued'],
  rejected: ['queued', 'draft'],
};

function canTransition(from: ProductionStatus, to: ProductionStatus): boolean {
  if (from === to) return true;
  return ALLOWED_JOB_TRANSITIONS[from]?.includes(to) ?? false;
}

class TransactionalJobStore {
  private state: StudioQueueState = { jobs: {}, workers: {}, approvals: {} };
  private mutex: Promise<void> = Promise.resolve();
  private reaperTimer: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.loadFromDisk();
    this.startReaper();
  }

  private ensureDataDir(): void {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private loadFromDisk(): void {
    this.ensureDataDir();
    if (!fs.existsSync(STATE_FILE)) {
      this.persistSync();
      return;
    }
    try {
      const raw = fs.readFileSync(STATE_FILE, 'utf-8');
      const parsed = JSON.parse(raw) as Partial<StudioQueueState>;
      this.state = {
        jobs: parsed.jobs ?? {},
        workers: parsed.workers ?? {},
        approvals: parsed.approvals ?? {},
      };
    } catch (error) {
      console.error('[jobStore] Failed to parse state file, resetting clean state:', error);
      this.state = { jobs: {}, workers: {}, approvals: {} };
    }
  }

  private persistSync(): void {
    this.ensureDataDir();
    const tmpPath = `${STATE_FILE}.tmp`;
    fs.writeFileSync(tmpPath, JSON.stringify(this.state, null, 2), 'utf-8');
    fs.renameSync(tmpPath, STATE_FILE);
  }

  private withLock<T>(fn: () => Promise<T> | T): Promise<T> {
    const run = this.mutex.then(fn, fn);
    this.mutex = run.then(
      () => undefined,
      () => undefined,
    );
    return run;
  }

  private startReaper(): void {
    if (this.reaperTimer) return;
    this.reaperTimer = setInterval(() => {
      void this.reapExpiredLeases();
    }, 10_000);
    this.reaperTimer.unref();
  }

  private reapExpiredStateSync(): boolean {
    const now = Date.now();
    let changed = false;

    // Mark silent workers offline
    for (const worker of Object.values(this.state.workers)) {
      const lastBeat = Date.parse(worker.lastHeartbeat);
      if (worker.status !== 'Offline' && Number.isFinite(lastBeat) && now - lastBeat > WORKER_HEARTBEAT_TIMEOUT_MS) {
        worker.status = 'Offline';
        worker.currentJobId = null;
        worker.currentJobProgress = null;
        changed = true;
      }
    }

    // Reclaim expired job leases for retry or fail if max attempts reached
    for (const job of Object.values(this.state.jobs)) {
      if (job.status === 'claimed' || job.status === 'processing' || job.status === 'uploading') {
        const leaseEnd = job.leaseExpiresAt ? Date.parse(job.leaseExpiresAt) : 0;
        if (leaseEnd > 0 && now > leaseEnd) {
          const isoNow = new Date(now).toISOString();
          if (job.attemptCount < job.maxAttempts) {
            job.status = 'queued';
            job.workerId = undefined;
            job.leaseExpiresAt = undefined;
            job.progress = 0;
            job.stageMessage = `Lease expired; re-queued for attempt ${job.attemptCount + 1}/${job.maxAttempts}`;
            job.updatedAt = isoNow;
            job.history.push({
              timestamp: isoNow,
              status: 'queued',
              message: 'Worker lease expired; eligible for retry.',
            });
          } else {
            job.status = 'failed';
            job.workerId = undefined;
            job.leaseExpiresAt = undefined;
            job.errorMessage = 'Job lease timed out after maximum retry attempts.';
            job.stageMessage = 'Failed: lease timed out after maximum retry attempts';
            job.updatedAt = isoNow;
            job.history.push({
              timestamp: isoNow,
              status: 'failed',
              message: 'Job timed out after reaching maxAttempts.',
            });
          }
          changed = true;
        }
      }
    }

    return changed;
  }

  async reapExpiredLeases(): Promise<void> {
    await this.withLock(() => {
      if (this.reapExpiredStateSync()) {
        this.persistSync();
      }
    });
  }

  async createJob(
    userId: string,
    input: {
      projectId: string;
      episodeId: string;
      episodeTitle: string;
      sceneNumber?: number;
      type: JobType;
      payload: Record<string, unknown>;
      idempotencyKey?: string;
      maxAttempts?: number;
    },
  ): Promise<{ job: ProductionJob; deduplicated: boolean }> {
    return this.withLock(() => {
      if (input.idempotencyKey) {
        const existing = Object.values(this.state.jobs).find(
          (j) =>
            j.userId === userId &&
            j.idempotencyKey === input.idempotencyKey &&
            j.status !== 'failed' &&
            j.status !== 'cancelled',
        );
        if (existing) {
          return { job: existing, deduplicated: true };
        }
      }

      const activeExisting = Object.values(this.state.jobs).find(
        (j) =>
          j.userId === userId &&
          j.episodeId === input.episodeId &&
          j.type === input.type &&
          (j.sceneNumber ?? null) === (input.sceneNumber ?? null) &&
          ['queued', 'claimed', 'processing', 'uploading'].includes(j.status),
      );
      if (activeExisting) {
        return { job: activeExisting, deduplicated: true };
      }

      const now = new Date().toISOString();
      const jobId = `job_${crypto.randomBytes(8).toString('hex')}`;
      const job: ProductionJob = {
        jobId,
        userId,
        projectId: input.projectId,
        episodeId: input.episodeId,
        episodeTitle: input.episodeTitle,
        sceneNumber: input.sceneNumber,
        type: input.type,
        status: 'queued',
        progress: 0,
        stageMessage: 'Queued for local production worker',
        payload: input.payload,
        attemptCount: 0,
        maxAttempts: Math.min(Math.max(input.maxAttempts ?? 3, 1), 5),
        idempotencyKey: input.idempotencyKey,
        history: [
          {
            timestamp: now,
            status: 'queued',
            message: `Job created (${input.type})`,
          },
        ],
        createdAt: now,
        updatedAt: now,
      };

      this.state.jobs[jobId] = job;
      this.persistSync();
      return { job, deduplicated: false };
    });
  }

  async rehydrateJob(
    userId: string,
    input: {
      jobId: string;
      projectId: string;
      episodeId: string;
      episodeTitle: string;
      sceneNumber?: number;
      type: JobType;
      status?: ProductionStatus;
      progress?: number;
      stageMessage?: string;
      payload?: Record<string, unknown>;
      workerId?: string;
      leaseExpiresAt?: string;
      attemptCount?: number;
      maxAttempts?: number;
      errorMessage?: string;
      outputUrl?: string;
      createdAt?: string;
      updatedAt?: string;
    },
  ): Promise<{ job: ProductionJob; recovered: boolean }> {
    return this.withLock(() => {
      const existing = this.state.jobs[input.jobId];
      if (existing) {
        if (existing.userId !== userId) {
          throw new Error('FORBIDDEN_JOB_OWNERSHIP');
        }
        return { job: existing, recovered: false };
      }

      const now = new Date().toISOString();
      const rawStatus: ProductionStatus = input.status ?? 'queued';
      // If a job was mid-flight when the server restarted and no worker holds it in memory,
      // safely return it to 'queued' so the worker can claim it cleanly.
      const recoveredStatus: ProductionStatus = ['claimed', 'processing', 'uploading'].includes(
        rawStatus,
      )
        ? 'queued'
        : rawStatus;

      const job: ProductionJob = {
        jobId: input.jobId,
        userId,
        projectId: input.projectId,
        episodeId: input.episodeId,
        episodeTitle: input.episodeTitle || 'Recovered Episode',
        sceneNumber: typeof input.sceneNumber === 'number' ? input.sceneNumber : undefined,
        type: input.type,
        status: recoveredStatus,
        progress:
          recoveredStatus === 'queued'
            ? 0
            : Math.max(0, Math.min(100, Math.round(input.progress ?? 0))),
        stageMessage:
          recoveredStatus === 'queued' && rawStatus !== 'queued'
            ? 'Recovered from Firestore after server restart; queued for worker'
            : input.stageMessage || 'Recovered from Firestore job mirror',
        payload: input.payload ?? {},
        workerId: recoveredStatus === 'queued' ? undefined : input.workerId,
        leaseExpiresAt: recoveredStatus === 'queued' ? undefined : input.leaseExpiresAt,
        attemptCount: Math.max(0, Math.min(10, Math.round(input.attemptCount ?? 0))),
        maxAttempts: Math.max(1, Math.min(10, Math.round(input.maxAttempts ?? 3))),
        errorMessage: input.errorMessage,
        outputUrl: input.outputUrl,
        history: [
          {
            timestamp: now,
            status: recoveredStatus,
            message: `Recovered from Firestore job document (${input.jobId}).`,
          },
        ],
        createdAt: input.createdAt || now,
        updatedAt: input.updatedAt || now,
      };

      this.state.jobs[input.jobId] = job;
      this.persistSync();
      return { job, recovered: true };
    });
  }

  async listJobs(userId: string): Promise<ProductionJob[]> {
    return this.withLock(() => {
      if (this.reapExpiredStateSync()) {
        this.persistSync();
      }
      return Object.values(this.state.jobs)
        .filter((j) => j.userId === userId)
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    });
  }

  async getJob(userId: string, jobId: string): Promise<ProductionJob | null> {
    return this.withLock(() => {
      const job = this.state.jobs[jobId];
      if (!job || job.userId !== userId) return null;
      return job;
    });
  }

  async cancelJob(userId: string, jobId: string): Promise<ProductionJob> {
    return this.withLock(() => {
      const job = this.state.jobs[jobId];
      if (!job || job.userId !== userId) {
        throw new Error('NOT_FOUND');
      }
      if (!canTransition(job.status, 'cancelled')) {
        throw new Error(`INVALID_TRANSITION:${job.status}->cancelled`);
      }
      const now = new Date().toISOString();
      job.status = 'cancelled';
      job.workerId = undefined;
      job.leaseExpiresAt = undefined;
      job.stageMessage = 'Cancelled by operator';
      job.updatedAt = now;
      job.history.push({ timestamp: now, status: 'cancelled', message: 'Cancelled by user.' });
      this.persistSync();
      return job;
    });
  }

  async retryJob(userId: string, jobId: string): Promise<ProductionJob> {
    return this.withLock(() => {
      const job = this.state.jobs[jobId];
      if (!job || job.userId !== userId) {
        throw new Error('NOT_FOUND');
      }
      if (!canTransition(job.status, 'queued')) {
        throw new Error(`INVALID_TRANSITION:${job.status}->queued`);
      }
      const now = new Date().toISOString();
      job.status = 'queued';
      job.progress = 0;
      job.errorMessage = undefined;
      job.workerId = undefined;
      job.leaseExpiresAt = undefined;
      job.attemptCount = 0;
      job.stageMessage = 'Re-queued manually for retry';
      job.updatedAt = now;
      job.history.push({ timestamp: now, status: 'queued', message: 'Manually re-queued.' });
      this.persistSync();
      return job;
    });
  }

  async registerWorker(input: {
    workerId?: string;
    name: string;
    machineName?: string;
    hostname: string;
    os: string;
    version?: string;
    capabilities: string[];
  }): Promise<WorkerNode> {
    return this.withLock(() => {
      const now = new Date().toISOString();
      const workerId = input.workerId && /^[a-zA-Z0-9_-]{3,64}$/.test(input.workerId)
        ? input.workerId
        : `wrk_${crypto.randomBytes(6).toString('hex')}`;

      const existing = this.state.workers[workerId];
      const hostname = input.hostname.slice(0, 100);
      const worker: WorkerNode = {
        workerId,
        name: input.name.slice(0, 100),
        machineName: (input.machineName || hostname).slice(0, 100),
        hostname,
        os: input.os.slice(0, 80),
        version: (input.version || existing?.version || '1.0.0').slice(0, 40),
        status: 'Online',
        capabilities: input.capabilities.slice(0, 16),
        lastHeartbeat: now,
        registeredAt: existing?.registeredAt ?? now,
        currentJobId: existing?.currentJobId ?? null,
        currentJobProgress: existing?.currentJobProgress ?? null,
        metrics: existing?.metrics ?? null,
        lastError: null,
      };
      this.state.workers[workerId] = worker;
      this.persistSync();
      return worker;
    });
  }

  async heartbeatWorker(input: {
    workerId: string;
    status?: WorkerStatus;
    version?: string;
    machineName?: string;
    currentJobId?: string | null;
    currentJobProgress?: number | null;
    metrics?: WorkerMetrics | null;
    lastError?: string | null;
  }): Promise<WorkerNode> {
    return this.withLock(() => {
      const worker = this.state.workers[input.workerId];
      if (!worker) {
        throw new Error('WORKER_NOT_REGISTERED');
      }
      const now = new Date().toISOString();
      worker.lastHeartbeat = now;
      if (input.version) worker.version = input.version.slice(0, 40);
      if (input.machineName) worker.machineName = input.machineName.slice(0, 100);
      if (input.status) {
        worker.status = input.status;
      } else {
        worker.status = worker.currentJobId ? 'Busy' : 'Online';
      }
      if (input.currentJobId !== undefined) worker.currentJobId = input.currentJobId;
      if (input.currentJobProgress !== undefined) worker.currentJobProgress = input.currentJobProgress;
      if (input.metrics !== undefined) worker.metrics = input.metrics;
      if (input.lastError !== undefined) worker.lastError = input.lastError;

      // Renew active job lease if worker is holding one
      if (worker.currentJobId && this.state.jobs[worker.currentJobId]) {
        const job = this.state.jobs[worker.currentJobId];
        if (job.workerId === worker.workerId && ['claimed', 'processing', 'uploading'].includes(job.status)) {
          job.leaseExpiresAt = new Date(Date.now() + DEFAULT_LEASE_MS).toISOString();
        }
      }

      this.persistSync();
      return worker;
    });
  }

  async unregisterWorker(workerId: string): Promise<WorkerNode | null> {
    return this.withLock(() => {
      const worker = this.state.workers[workerId];
      if (!worker) return null;
      const now = new Date().toISOString();
      worker.status = 'Offline';
      worker.currentJobId = null;
      worker.currentJobProgress = null;

      for (const job of Object.values(this.state.jobs)) {
        if (
          job.workerId === workerId &&
          ['claimed', 'processing', 'uploading'].includes(job.status)
        ) {
          if (job.attemptCount < job.maxAttempts) {
            job.status = 'queued';
            job.workerId = undefined;
            job.leaseExpiresAt = undefined;
            job.progress = 0;
            job.stageMessage = `Worker disconnected cleanly; re-queued (attempt ${job.attemptCount}/${job.maxAttempts})`;
            job.updatedAt = now;
            job.history.push({
              timestamp: now,
              status: 'queued',
              message: `Worker ${workerId} disconnected cleanly; job re-queued.`,
            });
          } else {
            job.status = 'failed';
            job.workerId = undefined;
            job.leaseExpiresAt = undefined;
            job.errorMessage = 'Worker disconnected after maximum retry attempts.';
            job.stageMessage = 'Failed: worker disconnected after max attempts';
            job.updatedAt = now;
            job.history.push({
              timestamp: now,
              status: 'failed',
              message: 'Worker disconnected at maxAttempts.',
            });
          }
        }
      }

      this.persistSync();
      return worker;
    });
  }

  async claimNextJob(workerId: string, capabilities: string[] = []): Promise<ProductionJob | null> {
    return this.withLock(() => {
      this.reapExpiredStateSync();
      const worker = this.state.workers[workerId];
      if (!worker) {
        throw new Error('WORKER_NOT_REGISTERED');
      }

      // Check if worker already holds an active job
      const alreadyClaimed = Object.values(this.state.jobs).find(
        (j) => j.workerId === workerId && ['claimed', 'processing', 'uploading'].includes(j.status),
      );
      if (alreadyClaimed) {
        return alreadyClaimed;
      }

      const queuedJobs = Object.values(this.state.jobs)
        .filter((j) => j.status === 'queued')
        .filter((j) => capabilities.length === 0 || capabilities.includes(j.type) || capabilities.includes('all'))
        .sort((a, b) => a.createdAt.localeCompare(b.createdAt));

      const nextJob = queuedJobs[0];
      if (!nextJob) {
        worker.status = 'Online';
        worker.lastHeartbeat = new Date().toISOString();
        worker.currentJobId = null;
        worker.currentJobProgress = null;
        this.persistSync();
        return null;
      }

      const nowMs = Date.now();
      const nowIso = new Date(nowMs).toISOString();
      nextJob.status = 'claimed';
      nextJob.workerId = workerId;
      nextJob.attemptCount += 1;
      nextJob.leaseExpiresAt = new Date(nowMs + DEFAULT_LEASE_MS).toISOString();
      nextJob.stageMessage = `Claimed by ${worker.name} (attempt ${nextJob.attemptCount}/${nextJob.maxAttempts})`;
      nextJob.updatedAt = nowIso;
      nextJob.history.push({
        timestamp: nowIso,
        status: 'claimed',
        message: `Atomically claimed by worker ${workerId}.`,
      });

      worker.status = 'Busy';
      worker.lastHeartbeat = nowIso;
      worker.currentJobId = nextJob.jobId;
      worker.currentJobProgress = 0;

      this.persistSync();
      return nextJob;
    });
  }

  async reportProgress(input: {
    workerId: string;
    jobId: string;
    progress: number;
    status?: 'processing' | 'uploading';
    stageMessage?: string;
  }): Promise<ProductionJob> {
    return this.withLock(() => {
      const job = this.state.jobs[input.jobId];
      if (!job) throw new Error('JOB_NOT_FOUND');
      if (job.workerId !== input.workerId) throw new Error('LEASE_OWNERSHIP_MISMATCH');

      const targetStatus: ProductionStatus = input.status ?? 'processing';
      if (!canTransition(job.status, targetStatus)) {
        throw new Error(`INVALID_TRANSITION:${job.status}->${targetStatus}`);
      }

      const nowMs = Date.now();
      const nowIso = new Date(nowMs).toISOString();
      job.status = targetStatus;
      job.progress = Math.max(0, Math.min(100, Math.round(input.progress)));
      if (input.stageMessage) job.stageMessage = input.stageMessage.slice(0, 300);
      job.leaseExpiresAt = new Date(nowMs + DEFAULT_LEASE_MS).toISOString();
      job.updatedAt = nowIso;

      const worker = this.state.workers[input.workerId];
      if (worker) {
        worker.status = 'Busy';
        worker.lastHeartbeat = nowIso;
        worker.currentJobId = job.jobId;
        worker.currentJobProgress = job.progress;
      }

      this.persistSync();
      return job;
    });
  }

  async completeJob(input: {
    workerId: string;
    jobId: string;
    outputUrl: string;
    outputMetadata?: Record<string, unknown>;
    enterApproval?: boolean;
  }): Promise<ProductionJob> {
    return this.withLock(() => {
      const job = this.state.jobs[input.jobId];
      if (!job) throw new Error('JOB_NOT_FOUND');
      if (job.workerId !== input.workerId) throw new Error('LEASE_OWNERSHIP_MISMATCH');

      const finalStatus: ProductionStatus = input.enterApproval ? 'pending_approval' : 'completed';
      if (!canTransition(job.status, finalStatus)) {
        throw new Error(`INVALID_TRANSITION:${job.status}->${finalStatus}`);
      }

      const nowIso = new Date().toISOString();
      job.status = finalStatus;
      job.progress = 100;
      job.outputUrl = input.outputUrl;
      job.outputMetadata = input.outputMetadata;
      job.leaseExpiresAt = undefined;
      job.stageMessage = input.enterApproval
        ? 'Render uploaded; awaiting human review in Approval Center'
        : 'Production job completed';
      job.updatedAt = nowIso;
      job.history.push({
        timestamp: nowIso,
        status: finalStatus,
        message: `Completed by worker ${input.workerId}.`,
      });

      const worker = this.state.workers[input.workerId];
      if (worker) {
        worker.status = 'Online';
        worker.lastHeartbeat = nowIso;
        worker.currentJobId = null;
        worker.currentJobProgress = null;
      }

      this.persistSync();
      return job;
    });
  }

  async failJob(input: {
    workerId: string;
    jobId: string;
    errorMessage: string;
    retryable?: boolean;
  }): Promise<ProductionJob> {
    return this.withLock(() => {
      const job = this.state.jobs[input.jobId];
      if (!job) throw new Error('JOB_NOT_FOUND');
      if (job.workerId !== input.workerId) throw new Error('LEASE_OWNERSHIP_MISMATCH');

      const nowIso = new Date().toISOString();
      const shouldRetry = Boolean(input.retryable) && job.attemptCount < job.maxAttempts;
      const nextStatus: ProductionStatus = shouldRetry ? 'queued' : 'failed';

      if (!canTransition(job.status, nextStatus)) {
        throw new Error(`INVALID_TRANSITION:${job.status}->${nextStatus}`);
      }

      job.status = nextStatus;
      job.errorMessage = input.errorMessage.slice(0, 1000);
      job.workerId = undefined;
      job.leaseExpiresAt = undefined;
      job.stageMessage = shouldRetry
        ? `Attempt ${job.attemptCount} failed; re-queued for retry`
        : `Failed: ${job.errorMessage}`;
      job.updatedAt = nowIso;
      job.history.push({
        timestamp: nowIso,
        status: nextStatus,
        message: job.errorMessage,
      });

      const worker = this.state.workers[input.workerId];
      if (worker) {
        worker.status = 'Error';
        worker.lastHeartbeat = nowIso;
        worker.currentJobId = null;
        worker.currentJobProgress = null;
        worker.lastError = job.errorMessage;
      }

      this.persistSync();
      return job;
    });
  }

  async listWorkers(): Promise<WorkerNode[]> {
    return this.withLock(() => {
      if (this.reapExpiredStateSync()) {
        this.persistSync();
      }
      return Object.values(this.state.workers).sort((a, b) =>
        b.lastHeartbeat.localeCompare(a.lastHeartbeat),
      );
    });
  }

  async getQueueStats(): Promise<{
    queuedCount: number;
    activeCount: number;
    completedCount: number;
    failedCount: number;
  }> {
    return this.withLock(() => {
      this.reapExpiredStateSync();
      const all = Object.values(this.state.jobs);
      return {
        queuedCount: all.filter((j) => j.status === 'queued').length,
        activeCount: all.filter((j) => ['claimed', 'processing', 'uploading'].includes(j.status)).length,
        completedCount: all.filter((j) => ['completed', 'pending_approval', 'approved'].includes(j.status)).length,
        failedCount: all.filter((j) => j.status === 'failed').length,
      };
    });
  }

  async reviewApproval(
    userId: string,
    approvalId: string,
    input: {
      episodeId: string;
      projectId: string;
      decision: 'approved' | 'rejected' | 'changes_requested';
      comments: string;
    },
  ): Promise<ApprovalRecord> {
    return this.withLock(() => {
      const nowIso = new Date().toISOString();
      const record: ApprovalRecord = {
        approvalId,
        userId,
        projectId: input.projectId,
        episodeId: input.episodeId,
        reviewerId: userId,
        decision: input.decision,
        comments: input.comments.slice(0, 2000),
        reviewedAt: nowIso,
      };
      this.state.approvals[approvalId] = record;

      // Sync any pending_approval jobs for this episode
      for (const job of Object.values(this.state.jobs)) {
        if (job.userId === userId && job.episodeId === input.episodeId && job.status === 'pending_approval') {
          const target: ProductionStatus = input.decision === 'approved' ? 'approved' : 'rejected';
          if (canTransition(job.status, target)) {
            job.status = target;
            job.updatedAt = nowIso;
            job.stageMessage = `Reviewed: ${input.decision}`;
            job.history.push({
              timestamp: nowIso,
              status: target,
              message: `Reviewer ${userId}: ${input.decision} — ${record.comments}`,
            });
          }
        }
      }

      this.persistSync();
      return record;
    });
  }
}

export const jobStore = new TransactionalJobStore();
