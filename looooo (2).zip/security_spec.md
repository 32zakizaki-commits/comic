# JapanComic Studio — Security Specification (Phase 0)

## Data Invariants
1. Every `projects`, `characters`, `episodes`, `approvals`, `settings`, and `jobs` document MUST carry `userId == request.auth.uid` on create and keep `userId` and `createdAt` immutable on update.
2. `characters` and `episodes` MUST belong to an existing `projects` document owned by `request.auth.uid` (verified via `exists()` and `get()`).
3. `approvals` MUST reference an existing `episodes` document owned by `request.auth.uid`, and `reviewerId` MUST equal `request.auth.uid`.
4. Personally Identifiable Information (`email`) is isolated in `/users/{userId}/private/{docId}` and readable/writable only by `userId`.
5. `workers` cannot be created, updated, or deleted from client SDKs; all worker registration, heartbeat, and job claiming happen through server-authenticated `/api/worker/*` endpoints.
6. Every `allow list` rule evaluates `resource.data.userId == request.auth.uid` directly without `get()` or `exists()`.

## Dirty Dozen Adversarial Payloads (Must Return PERMISSION_DENIED)
1. **Identity Spoof on Project Create**: Creating `/projects/p1` with `userId: "other_uid"` when `auth.uid == "attacker"`.
2. **Unverified Email Write**: Writing `/projects/p1` when `request.auth.token.email_verified == false`.
3. **Shadow Ghost Field Injection**: Creating `/projects/p1` with an extra unlisted key `isAdmin: true`.
4. **Orphaned Character Create**: Creating `/characters/c1` referencing a non-existent `projectId: "missing_proj"`.
5. **Cross-Tenant Character Hijack**: Creating `/characters/c1` referencing a `projectId` owned by another user.
6. **Immutable Owner Tamper**: Updating `/projects/p1` to change `userId` to another user.
7. **Timestamp Forgery**: Creating `/projects/p1` with a backdated `createdAt` not equal to `request.time`.
8. **ID Poisoning**: Writing `/projects/<1500-char-junk-id>` exceeding 128 chars or containing invalid symbols.
9. **PII Cross-User Read**: Reading `/users/victim/private/info` as `attacker`.
10. **Blanket Collection List**: Listing `/projects` without a query filter enforcing `userId == auth.uid`.
11. **Unbounded Array Exhaustion**: Writing `/characters/c1` with `referenceImages` exceeding 5 entries.
12. **Client Worker Spoofing**: Writing `/workers/w1` directly from the client SDK to fake an `Online` worker.
