# JapanComic Studio — Backend REST API Documentation

All user endpoints require a Firebase Auth ID token in the `Authorization: Bearer <idToken>` header. User ownership is verified server-side from the decoded token (`req.authUser.uid`).

## Integration & Health
- `GET /api/health` — Public health check.
- `GET /api/integrations/status` — Returns boolean configuration flags for Gemini, ElevenLabs, Firebase, Worker auth, and YouTube OAuth (never exposes raw secrets).

## Gemini Story Studio
- `POST /api/gemini/story` — Generates an original Japanese Motion Comic script and structured scene breakdown using `gemini-4-hydrogen`.

## ElevenLabs Voice Studio
- `GET /api/elevenlabs/voices` — Lists configured ElevenLabs voices (requires `ELEVENLABS_API_KEY`).
- `POST /api/elevenlabs/tts` — Synthesizes Japanese narration or dialogue (`eleven_multilingual_v2`, `language_code: "ja"`).

## Production Jobs & Approvals
- `POST /api/jobs` — Creates an idempotent production job (`scene_image`, `voice_synthesis`, `video_render`, `full_episode`).
- `GET /api/jobs` — Lists jobs owned by the authenticated user.
- `GET /api/jobs/:id` — Returns a single job and its transition history.
- `POST /api/jobs/:id/cancel` — Cancels an active or queued job.
- `POST /api/jobs/:id/retry` — Re-queues a failed or cancelled job.
- `POST /api/approvals/:id/review` — Records human approval/rejection and unlocks YouTube publishing upon approval.

## YouTube Publishing Gate
- `GET /api/youtube/status` — Returns whether YouTube OAuth server credentials are configured.
- `POST /api/youtube/publish` — Enforces `episodeStatus === 'approved'` and verifies YouTube OAuth refresh token before authorizing release.
