# JapanComic Studio — Worker API Documentation

All `/api/worker/*` endpoints authenticate using `Authorization: Bearer <WORKER_API_SECRET>` (or `X-Worker-Secret`) verified with constant-time comparison on the server.

## Endpoints

- `GET /api/worker/status`
  - Verifies worker authentication and returns server time, heartbeat/lease intervals, and current queue counts.
- `POST /api/worker/register`
  - Registers a Windows 11 worker node (`workerId`, `name`, `machineName`, `hostname`, `os`, `version`, `capabilities`).
- `POST /api/worker/heartbeat`
  - Sends `status` (`Online` | `Offline` | `Busy` | `Error`), `version`, `machineName`, `currentJobId`, `currentJobProgress`, `metrics` (`cpuUsagePercent`, `gpuName`, `gpuUsagePercent`, `gpuMemoryUsedMb`, `gpuMemoryTotalMb`, `diskFreeGb`), and `lastError`. Automatically renews active job leases.
- `POST /api/worker/unregister`
  - Gracefully marks a disconnecting worker `Offline` and immediately re-queues any active leased job for retry.
- `POST /api/worker/claim`
  - Atomically claims the oldest `queued` job matching worker capabilities under a 120-second lease. Guarantees no two workers can claim the same job simultaneously.
- `POST /api/worker/progress`
  - Reports `progress` (`0–100`), `status` (`processing` | `uploading`), and `stageMessage`, renewing the job lease.
- `POST /api/worker/upload`
  - Uploads base64 scene PNGs, audio MP3s, or rendered MP4 artifacts (validated extension and size) and returns the studio asset URL.
- `POST /api/worker/complete`
  - Marks the job `completed` (or `pending_approval` when `enterApproval: true` for rendered videos) and attaches `outputUrl` + `outputMetadata`.
- `POST /api/worker/fail`
  - Reports `errorMessage` and `retryable` flag. Re-queues automatically if `attemptCount < maxAttempts`.

## Lease Timeout Reaper & Atomic Transactions
- Every 10 seconds (and synchronously on claim/list operations), the server checks for expired leases (`>120s` without progress/heartbeat) and silent workers (`>45s` without heartbeat), marking stale workers `Offline` and returning interrupted jobs to `queued` for retry (up to `maxAttempts`).
- Firestore `/jobs/{jobId}` mirrors are updated using `runTransaction` so status, attempt counts, and lease timestamps remain atomic across concurrent snapshots.
