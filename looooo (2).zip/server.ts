import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { createServer as createViteServer } from 'vite';
import {
  ensureFirebaseAdmin,
  isWorkerSecretConfigured,
  requireFirebaseAuth,
  requireWorkerAuth,
  type AuthenticatedRequest,
} from './server/auth.js';
import {
  isElevenLabsConfigured,
  listElevenLabsVoices,
  synthesizeJapaneseVoice,
} from './server/elevenlabsService.js';
import { generateJapaneseStory, isGeminiConfigured } from './server/geminiService.js';
import { jobStore } from './server/jobStore.js';
import { getYouTubeConfigStatus, prepareYouTubePublish } from './server/youtubeService.js';
import type { IntegrationStatus, JobType, StoryGenre } from './src/types/studio.js';

const PORT = Number(process.env.PORT) || 3000;
const UPLOAD_ROOT = path.resolve(process.cwd(), '.data', 'uploads');

function resolveSharedBackendUrl(req: express.Request): string {
  const configured = (process.env.SHARED_APP_URL || process.env.APP_URL || '').trim().replace(/\/+$/, '');
  if (configured && configured !== 'MY_APP_URL' && configured.startsWith('http')) {
    return configured.replace('://ais-dev-', '://ais-pre-');
  }
  const forwardedHost = (req.headers['x-forwarded-host'] || req.headers.host || '').toString().split(',')[0].trim();
  if (forwardedHost) {
    const prodHost = forwardedHost.replace(/^ais-dev-/, 'ais-pre-');
    const proto =
      prodHost.includes('localhost') || prodHost.startsWith('127.0.0.1') ? 'http' : 'https';
    return `${proto}://${prodHost}`;
  }
  return 'https://ais-pre-iwein4jbokv72xdav7enbz-964336458859.europe-west2.run.app';
}

function ensureUploadDirs(): void {
  for (const sub of ['audio', 'scenes', 'videos']) {
    const dir = path.join(UPLOAD_ROOT, sub);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }
}

function getStorageBucketFromConfig(): string | null {
  try {
    const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
    if (!fs.existsSync(configPath)) return null;
    const raw = fs.readFileSync(configPath, 'utf-8');
    const parsed = JSON.parse(raw) as { storageBucket?: string };
    return parsed.storageBucket || null;
  } catch {
    return null;
  }
}

async function startServer(): Promise<void> {
  ensureUploadDirs();
  const app = express();
  app.set('trust proxy', 1);
  app.use(express.json({ limit: '15mb' }));

  // Healthcheck
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'JapanComic Studio Control Plane',
      timestamp: new Date().toISOString(),
    });
  });

  // Integration Status (never exposes secret values)
  app.get('/api/integrations/status', requireFirebaseAuth, (req, res) => {
    const ytStatus = getYouTubeConfigStatus();
    const status: IntegrationStatus = {
      geminiConfigured: isGeminiConfigured(),
      elevenlabsConfigured: isElevenLabsConfigured(),
      workerAuthConfigured: isWorkerSecretConfigured(),
      firebaseConfigured: ensureFirebaseAdmin(),
      youtubeConfigured: ytStatus.configured,
      storageBucket: getStorageBucketFromConfig(),
      comfyuiMode: 'Local Worker Bridge Only (never exposed directly)',
      sharedBackendUrl: resolveSharedBackendUrl(req),
    };
    res.json(status);
  });

  // Safely serve uploaded studio assets (audio, rendered scenes, videos) with path confinement
  app.get('/api/assets/:category/:filename', (req, res) => {
    const { category, filename } = req.params;
    if (!['audio', 'scenes', 'videos'].includes(category)) {
      res.status(400).json({ error: 'Invalid asset category.' });
      return;
    }
    if (!/^[a-zA-Z0-9._-]+$/.test(filename)) {
      res.status(400).json({ error: 'Invalid filename.' });
      return;
    }
    const baseDir = path.resolve(UPLOAD_ROOT, category);
    const resolved = path.resolve(baseDir, filename);
    if (!resolved.startsWith(baseDir + path.sep)) {
      res.status(403).json({ error: 'Forbidden path.' });
      return;
    }
    if (!fs.existsSync(resolved)) {
      res.status(404).json({ error: 'Asset not found.' });
      return;
    }
    res.sendFile(resolved);
  });

  // =========================================================================
  // GEMINI STORY GENERATION (Server-side only)
  // =========================================================================
  app.post('/api/gemini/story', requireFirebaseAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const body = req.body as Record<string, unknown>;
      const title = typeof body.title === 'string' ? body.title.trim() : '';
      const mainIdea = typeof body.mainIdea === 'string' ? body.mainIdea.trim() : '';
      const genre = (typeof body.genre === 'string' ? body.genre : 'Drama') as StoryGenre;

      if (!title || !mainIdea) {
        res.status(400).json({ error: 'Story title and main idea are required.' });
        return;
      }

      const story = await generateJapaneseStory({
        title: title.slice(0, 200),
        genre,
        mainIdea: mainIdea.slice(0, 8000),
        targetAudience: typeof body.targetAudience === 'string' ? body.targetAudience.slice(0, 300) : 'Japanese YouTube Drama Audience',
        desiredDuration: typeof body.desiredDuration === 'string' ? body.desiredDuration.slice(0, 120) : '3 minutes',
        sceneCount: Number(body.sceneCount) || 6,
        emotionalTone: typeof body.emotionalTone === 'string' ? body.emotionalTone.slice(0, 300) : 'Tense & Dramatic',
        endingType: typeof body.endingType === 'string' ? body.endingType.slice(0, 300) : 'Bittersweet Twist',
        visualStyle: typeof body.visualStyle === 'string' ? body.visualStyle.slice(0, 80) : 'Motion Comic',
        characters: Array.isArray(body.characters) ? body.characters : [],
      });

      res.json({ story });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Story generation failed.';
      console.error('[gemini/story] error:', message);
      res.status(isGeminiConfigured() ? 500 : 503).json({ error: message });
    }
  });

  // =========================================================================
  // ELEVENLABS VOICE STUDIO (Server-side only)
  // =========================================================================
  app.get('/api/elevenlabs/voices', requireFirebaseAuth, async (_req, res) => {
    if (!isElevenLabsConfigured()) {
      res.status(503).json({
        configured: false,
        voices: [],
        error: 'ELEVENLABS_API_KEY is not configured in server secrets.',
      });
      return;
    }
    try {
      const voices = await listElevenLabsVoices();
      res.json({ configured: true, voices });
    } catch (error) {
      res.status(502).json({
        configured: true,
        error: error instanceof Error ? error.message : 'Failed to fetch ElevenLabs voices.',
      });
    }
  });

  app.post('/api/elevenlabs/tts', requireFirebaseAuth, async (req, res) => {
    if (!isElevenLabsConfigured()) {
      res.status(503).json({
        configured: false,
        error: 'ELEVENLABS_API_KEY is not configured in server secrets.',
      });
      return;
    }

    const body = req.body as Record<string, unknown>;
    const text = typeof body.text === 'string' ? body.text.trim() : '';
    if (!text || text.length > 5000) {
      res.status(400).json({ error: 'Text must be between 1 and 5000 characters.' });
      return;
    }

    try {
      const result = await synthesizeJapaneseVoice({
        text,
        voiceId: typeof body.voiceId === 'string' ? body.voiceId : undefined,
        stability: typeof body.stability === 'number' ? body.stability : undefined,
        similarityBoost: typeof body.similarityBoost === 'number' ? body.similarityBoost : undefined,
        style: typeof body.style === 'number' ? body.style : undefined,
      });
      res.json({ configured: true, ...result });
    } catch (error) {
      res.status(502).json({
        configured: true,
        error: error instanceof Error ? error.message : 'Voice synthesis failed.',
      });
    }
  });

  // =========================================================================
  // PRODUCTION JOBS & APPROVALS (Authenticated Users)
  // =========================================================================
  app.post('/api/jobs', requireFirebaseAuth, async (req: AuthenticatedRequest, res) => {
    const userId = req.authUser!.uid;
    const body = req.body as Record<string, unknown>;

    const projectId = typeof body.projectId === 'string' ? body.projectId.trim() : '';
    const episodeId = typeof body.episodeId === 'string' ? body.episodeId.trim() : '';
    const episodeTitle = typeof body.episodeTitle === 'string' ? body.episodeTitle.trim() : 'Untitled Episode';
    const type = body.type as JobType;

    if (!projectId || !episodeId) {
      res.status(400).json({ error: 'projectId and episodeId are required.' });
      return;
    }
    if (!['scene_image', 'voice_synthesis', 'video_render', 'full_episode'].includes(type)) {
      res.status(400).json({ error: 'Invalid job type.' });
      return;
    }

    const result = await jobStore.createJob(userId, {
      projectId,
      episodeId,
      episodeTitle: episodeTitle.slice(0, 200),
      sceneNumber: typeof body.sceneNumber === 'number' ? body.sceneNumber : undefined,
      type,
      payload: typeof body.payload === 'object' && body.payload !== null ? (body.payload as Record<string, unknown>) : {},
      idempotencyKey: typeof body.idempotencyKey === 'string' ? body.idempotencyKey.slice(0, 128) : undefined,
    });

    res.status(result.deduplicated ? 200 : 201).json(result);
  });

  app.get('/api/jobs', requireFirebaseAuth, async (req: AuthenticatedRequest, res) => {
    const jobs = await jobStore.listJobs(req.authUser!.uid);
    res.json({ jobs });
  });

  // Recover/rehydrate Firestore jobs back into the backend queue after a server restart
  // Preserves exact jobId and userId ownership without duplicating existing jobs.
  app.post('/api/jobs/rehydrate', requireFirebaseAuth, async (req: AuthenticatedRequest, res) => {
    const userId = req.authUser!.uid;
    const body = req.body as Record<string, unknown>;
    const rawJobs = Array.isArray(body.jobs) ? body.jobs : [];

    const recoveredIds: string[] = [];
    for (const item of rawJobs.slice(0, 100)) {
      if (!item || typeof item !== 'object') continue;
      const rec = item as Record<string, unknown>;
      const jobId = typeof rec.jobId === 'string' ? rec.jobId.trim() : '';
      const projectId = typeof rec.projectId === 'string' ? rec.projectId.trim() : '';
      const episodeId = typeof rec.episodeId === 'string' ? rec.episodeId.trim() : '';
      const type = rec.type as JobType;

      if (!jobId || !/^[a-zA-Z0-9_-]{3,128}$/.test(jobId)) continue;
      if (!projectId || !episodeId) continue;
      if (!['scene_image', 'voice_synthesis', 'video_render', 'full_episode'].includes(type)) {
        continue;
      }

      try {
        const result = await jobStore.rehydrateJob(userId, {
          jobId,
          projectId,
          episodeId,
          episodeTitle:
            typeof rec.episodeTitle === 'string'
              ? rec.episodeTitle.slice(0, 200)
              : 'Recovered Episode',
          sceneNumber: typeof rec.sceneNumber === 'number' ? rec.sceneNumber : undefined,
          type,
          status: typeof rec.status === 'string' ? (rec.status as never) : 'queued',
          progress: typeof rec.progress === 'number' ? rec.progress : 0,
          stageMessage: typeof rec.stageMessage === 'string' ? rec.stageMessage.slice(0, 300) : undefined,
          payload:
            typeof rec.payload === 'object' && rec.payload !== null
              ? (rec.payload as Record<string, unknown>)
              : {},
          workerId: typeof rec.workerId === 'string' ? rec.workerId : undefined,
          leaseExpiresAt: typeof rec.leaseExpiresAt === 'string' ? rec.leaseExpiresAt : undefined,
          attemptCount: typeof rec.attemptCount === 'number' ? rec.attemptCount : 0,
          maxAttempts: typeof rec.maxAttempts === 'number' ? rec.maxAttempts : 3,
          errorMessage: typeof rec.errorMessage === 'string' ? rec.errorMessage : undefined,
          outputUrl: typeof rec.outputUrl === 'string' ? rec.outputUrl : undefined,
        });
        if (result.recovered) {
          recoveredIds.push(jobId);
        }
      } catch (err) {
        console.warn('[jobs/rehydrate] skipped job:', jobId, err);
      }
    }

    const jobs = await jobStore.listJobs(userId);
    res.json({ recoveredIds, jobs });
  });

  app.get('/api/jobs/:id', requireFirebaseAuth, async (req: AuthenticatedRequest, res) => {
    const job = await jobStore.getJob(req.authUser!.uid, String(req.params.id));
    if (!job) {
      res.status(404).json({ error: 'Job not found.' });
      return;
    }
    res.json({ job });
  });

  app.post('/api/jobs/:id/cancel', requireFirebaseAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const job = await jobStore.cancelJob(req.authUser!.uid, String(req.params.id));
      res.json({ job });
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Cancel failed.';
      res.status(msg === 'NOT_FOUND' ? 404 : 409).json({ error: msg });
    }
  });

  app.post('/api/jobs/:id/retry', requireFirebaseAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const job = await jobStore.retryJob(req.authUser!.uid, String(req.params.id));
      res.json({ job });
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Retry failed.';
      res.status(msg === 'NOT_FOUND' ? 404 : 409).json({ error: msg });
    }
  });

  app.post('/api/approvals/:id/review', requireFirebaseAuth, async (req: AuthenticatedRequest, res) => {
    const userId = req.authUser!.uid;
    const approvalId = String(req.params.id);
    const body = req.body as Record<string, unknown>;
    const episodeId = typeof body.episodeId === 'string' ? body.episodeId.trim() : '';
    const projectId = typeof body.projectId === 'string' ? body.projectId.trim() : '';
    const decision = body.decision as 'approved' | 'rejected' | 'changes_requested';
    const comments = typeof body.comments === 'string' ? body.comments.trim() : '';

    if (!episodeId || !projectId) {
      res.status(400).json({ error: 'episodeId and projectId are required.' });
      return;
    }
    if (!['approved', 'rejected', 'changes_requested'].includes(decision)) {
      res.status(400).json({ error: 'Invalid decision.' });
      return;
    }

    const approval = await jobStore.reviewApproval(userId, approvalId, {
      episodeId,
      projectId,
      decision,
      comments,
    });
    res.json({ approval });
  });

  app.get('/api/workers', requireFirebaseAuth, async (_req, res) => {
    const workers = await jobStore.listWorkers();
    res.json({ workers });
  });

  // =========================================================================
  // YOUTUBE PUBLISHING GATE (Authenticated Users)
  // =========================================================================
  app.get('/api/youtube/status', requireFirebaseAuth, (_req, res) => {
    res.json(getYouTubeConfigStatus());
  });

  app.post('/api/youtube/publish', requireFirebaseAuth, async (req, res) => {
    const body = req.body as Record<string, unknown>;
    try {
      const result = await prepareYouTubePublish({
        episodeId: String(body.episodeId ?? ''),
        episodeStatus: String(body.episodeStatus ?? ''),
        title: String(body.title ?? ''),
        description: String(body.description ?? ''),
        tags: Array.isArray(body.tags) ? body.tags.map(String) : [],
        visibility: (body.visibility as 'private' | 'unlisted' | 'public') ?? 'private',
        scheduledPublishAt: typeof body.scheduledPublishAt === 'string' ? body.scheduledPublishAt : undefined,
      });
      res.json(result);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'YouTube publish verification failed.';
      const statusCode = message.startsWith('HUMAN_APPROVAL_REQUIRED')
        ? 403
        : message.startsWith('YOUTUBE_NOT_CONFIGURED')
          ? 503
          : 502;
      res.status(statusCode).json({ error: message });
    }
  });

  // =========================================================================
  // WORKER API (Authenticated via WORKER_API_SECRET)
  // =========================================================================
  app.get('/api/worker/status', requireWorkerAuth, async (_req, res) => {
    const queueStats = await jobStore.getQueueStats();
    res.json({
      ok: true,
      serverTime: new Date().toISOString(),
      heartbeatIntervalSec: 15,
      heartbeatTimeoutSec: 45,
      leaseDurationSec: 120,
      ...queueStats,
    });
  });

  app.post('/api/worker/register', requireWorkerAuth, async (req, res) => {
    const body = req.body as Record<string, unknown>;
    const worker = await jobStore.registerWorker({
      workerId: typeof body.workerId === 'string' ? body.workerId : undefined,
      name: typeof body.name === 'string' ? body.name : 'Windows11-Worker',
      machineName: typeof body.machineName === 'string' ? body.machineName : undefined,
      hostname: typeof body.hostname === 'string' ? body.hostname : 'unknown-host',
      os: typeof body.os === 'string' ? body.os : 'Windows 11',
      version: typeof body.version === 'string' ? body.version : undefined,
      capabilities: Array.isArray(body.capabilities) ? body.capabilities.map(String) : ['all'],
    });
    res.json({
      worker,
      serverTime: new Date().toISOString(),
      heartbeatIntervalSec: 15,
      leaseDurationSec: 120,
    });
  });

  app.post('/api/worker/heartbeat', requireWorkerAuth, async (req, res) => {
    const body = req.body as Record<string, unknown>;
    const workerId = typeof body.workerId === 'string' ? body.workerId : '';
    if (!workerId) {
      res.status(400).json({ error: 'workerId is required.' });
      return;
    }
    try {
      const worker = await jobStore.heartbeatWorker({
        workerId,
        status: body.status as 'Online' | 'Offline' | 'Busy' | 'Error' | undefined,
        version: typeof body.version === 'string' ? body.version : undefined,
        machineName: typeof body.machineName === 'string' ? body.machineName : undefined,
        currentJobId: body.currentJobId as string | null | undefined,
        currentJobProgress: typeof body.currentJobProgress === 'number' ? body.currentJobProgress : undefined,
        metrics: typeof body.metrics === 'object' ? (body.metrics as never) : undefined,
        lastError: typeof body.lastError === 'string' ? body.lastError : undefined,
      });
      res.json({
        worker,
        serverTime: new Date().toISOString(),
      });
    } catch (error) {
      res.status(404).json({ error: error instanceof Error ? error.message : 'Worker not found.' });
    }
  });

  app.post('/api/worker/unregister', requireWorkerAuth, async (req, res) => {
    const body = req.body as Record<string, unknown>;
    const workerId = typeof body.workerId === 'string' ? body.workerId : '';
    if (!workerId) {
      res.status(400).json({ error: 'workerId is required.' });
      return;
    }
    const worker = await jobStore.unregisterWorker(workerId);
    res.json({ worker, serverTime: new Date().toISOString() });
  });

  app.post('/api/worker/claim', requireWorkerAuth, async (req, res) => {
    const body = req.body as Record<string, unknown>;
    const workerId = typeof body.workerId === 'string' ? body.workerId : '';
    if (!workerId) {
      res.status(400).json({ error: 'workerId is required.' });
      return;
    }
    try {
      const job = await jobStore.claimNextJob(
        workerId,
        Array.isArray(body.capabilities) ? body.capabilities.map(String) : [],
      );
      res.json({
        job,
        leaseDurationSec: 120,
        serverTime: new Date().toISOString(),
      });
    } catch (error) {
      res.status(404).json({ error: error instanceof Error ? error.message : 'Claim failed.' });
    }
  });

  app.post('/api/worker/progress', requireWorkerAuth, async (req, res) => {
    const body = req.body as Record<string, unknown>;
    const workerId = typeof body.workerId === 'string' ? body.workerId : '';
    const jobId = typeof body.jobId === 'string' ? body.jobId : '';
    if (!workerId || !jobId) {
      res.status(400).json({ error: 'workerId and jobId are required.' });
      return;
    }
    try {
      const job = await jobStore.reportProgress({
        workerId,
        jobId,
        progress: Number(body.progress) || 0,
        status: body.status === 'uploading' ? 'uploading' : 'processing',
        stageMessage: typeof body.stageMessage === 'string' ? body.stageMessage : undefined,
      });
      res.json({ job });
    } catch (error) {
      res.status(409).json({ error: error instanceof Error ? error.message : 'Progress update rejected.' });
    }
  });

  app.post('/api/worker/complete', requireWorkerAuth, async (req, res) => {
    const body = req.body as Record<string, unknown>;
    const workerId = typeof body.workerId === 'string' ? body.workerId : '';
    const jobId = typeof body.jobId === 'string' ? body.jobId : '';
    const outputUrl = typeof body.outputUrl === 'string' ? body.outputUrl : '';
    if (!workerId || !jobId || !outputUrl) {
      res.status(400).json({ error: 'workerId, jobId, and outputUrl are required.' });
      return;
    }
    try {
      const job = await jobStore.completeJob({
        workerId,
        jobId,
        outputUrl,
        outputMetadata: typeof body.outputMetadata === 'object' ? (body.outputMetadata as Record<string, unknown>) : undefined,
        enterApproval: Boolean(body.enterApproval),
      });
      res.json({ job });
    } catch (error) {
      res.status(409).json({ error: error instanceof Error ? error.message : 'Complete rejected.' });
    }
  });

  app.post('/api/worker/fail', requireWorkerAuth, async (req, res) => {
    const body = req.body as Record<string, unknown>;
    const workerId = typeof body.workerId === 'string' ? body.workerId : '';
    const jobId = typeof body.jobId === 'string' ? body.jobId : '';
    const errorMessage = typeof body.errorMessage === 'string' ? body.errorMessage : 'Worker reported an error.';
    if (!workerId || !jobId) {
      res.status(400).json({ error: 'workerId and jobId are required.' });
      return;
    }
    try {
      const job = await jobStore.failJob({
        workerId,
        jobId,
        errorMessage,
        retryable: body.retryable !== false,
      });
      res.json({ job });
    } catch (error) {
      res.status(409).json({ error: error instanceof Error ? error.message : 'Fail report rejected.' });
    }
  });

  // Safe Worker binary artifact upload (base64 JSON payload with strict MIME/size/path validation)
  app.post('/api/worker/upload', requireWorkerAuth, (req, res) => {
    const body = req.body as Record<string, unknown>;
    const category = typeof body.category === 'string' ? body.category : '';
    const dataBase64 = typeof body.dataBase64 === 'string' ? body.dataBase64 : '';
    const ext = typeof body.extension === 'string' ? body.extension.toLowerCase() : '';

    if (!['scenes', 'audio', 'videos'].includes(category)) {
      res.status(400).json({ error: 'category must be scenes, audio, or videos.' });
      return;
    }
    if (!['png', 'jpg', 'jpeg', 'webp', 'mp3', 'wav', 'mp4'].includes(ext)) {
      res.status(400).json({ error: 'Unsupported file extension.' });
      return;
    }
    if (!dataBase64) {
      res.status(400).json({ error: 'dataBase64 is required.' });
      return;
    }

    const buffer = Buffer.from(dataBase64, 'base64');
    if (buffer.byteLength === 0 || buffer.byteLength > 12 * 1024 * 1024) {
      res.status(400).json({ error: 'Uploaded file size must be between 1 byte and 12MB via API.' });
      return;
    }

    const safeFilename = `${category}_${Date.now()}_${crypto.randomBytes(5).toString('hex')}.${ext}`;
    const baseDir = path.resolve(UPLOAD_ROOT, category);
    const targetPath = path.resolve(baseDir, safeFilename);
    if (!targetPath.startsWith(baseDir + path.sep)) {
      res.status(403).json({ error: 'Forbidden path.' });
      return;
    }

    fs.writeFileSync(targetPath, buffer);
    res.status(201).json({
      url: `/api/assets/${category}/${safeFilename}`,
      byteLength: buffer.byteLength,
    });
  });

  // Keep unknown API requests in the API namespace. Without this guard,
  // Express's SPA fallback can return index.html (HTTP 200 / HTML) for a
  // missing API route, making frontend hosting look like a healthy backend.
  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'API route not found.' });
  });

  // =========================================================================
  // VITE DEV MIDDLEWARE / PRODUCTION STATIC SERVING
  // =========================================================================
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`JapanComic Studio server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((error) => {
  console.error('Fatal server startup error:', error);
  process.exit(1);
});
