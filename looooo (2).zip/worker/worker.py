"""
JapanComic Studio — Windows 11 Local Production Worker
Connects outbound over authenticated HTTPS to the cloud control center.
Never exposes local ComfyUI ports to the public internet.
"""

import base64
import json
import os
import platform
import re
import shutil
import socket
import subprocess
import tempfile
import threading
import time
import urllib.parse
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import psutil
import requests
from dotenv import load_dotenv

load_dotenv()

WORKER_VERSION = "1.3.0"
DEFAULT_SHARED_BACKEND_URL = "https://ais-pre-iwein4jbokv72xdav7enbz-964336458859.europe-west2.run.app"


def normalize_backend_url(raw_url: str) -> str:
    cleaned = raw_url.strip().rstrip("/")
    if not cleaned:
        return DEFAULT_SHARED_BACKEND_URL
    if "://ais-dev-" in cleaned:
        fixed = cleaned.replace("://ais-dev-", "://ais-pre-")
        print(
            f"[worker] WARNING: Detected development preview URL ({cleaned}). "
            f"Automatically switching to Shared Production URL: {fixed}"
        )
        return fixed
    if "localhost" in cleaned or "127.0.0.1" in cleaned:
        print(
            f"[worker] WARNING: STUDIO_BACKEND_URL is set to local address ({cleaned}). "
            f"For remote Cloud Control Center connection, set STUDIO_BACKEND_URL={DEFAULT_SHARED_BACKEND_URL}"
        )
    return cleaned


STUDIO_BACKEND_URL = normalize_backend_url(
    os.getenv("STUDIO_BACKEND_URL", DEFAULT_SHARED_BACKEND_URL)
)
WORKER_API_SECRET = os.getenv("WORKER_API_SECRET", "").strip()
MACHINE_NAME = socket.gethostname()
WORKER_ID = os.getenv("WORKER_ID", f"win11_{MACHINE_NAME.lower()}")
WORKER_NAME = os.getenv("WORKER_NAME", f"ASUS-Win11-{MACHINE_NAME}")
COMFYUI_URL = os.getenv("COMFYUI_URL", "http://127.0.0.1:8188").rstrip("/")
COMFYUI_CHECKPOINT = os.getenv("COMFYUI_CHECKPOINT", "animagineXL_v31.safetensors")
FFMPEG_BIN = os.getenv("FFMPEG_BIN", "ffmpeg")
HEARTBEAT_INTERVAL_SEC = int(os.getenv("HEARTBEAT_INTERVAL_SEC", "15"))
POLL_INTERVAL_SEC = int(os.getenv("POLL_INTERVAL_SEC", "5"))

state_lock = threading.Lock()
current_job_id: Optional[str] = None
current_job_progress: Optional[int] = None
worker_status: str = "Online"
last_error: Optional[str] = None


def api_headers() -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {WORKER_API_SECRET}",
        "X-Worker-Secret": WORKER_API_SECRET,
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def collect_hardware_metrics() -> Dict[str, Any]:
    cpu_pct = psutil.cpu_percent(interval=0.2)
    disk = shutil.disk_usage(os.getcwd())
    disk_free_gb = round(disk.free / (1024 ** 3), 2)

    gpu_name = None
    gpu_usage = None
    vram_used = None
    vram_total = None

    try:
        out = subprocess.check_output(
            [
                "nvidia-smi",
                "--query-gpu=name,utilization.gpu,memory.used,memory.total",
                "--format=csv,noheader,nounits",
            ],
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=3,
        ).strip()
        if out:
            parts = [p.strip() for p in out.splitlines()[0].split(",")]
            if len(parts) == 4:
                gpu_name = parts[0]
                gpu_usage = float(parts[1])
                vram_used = int(float(parts[2]))
                vram_total = int(float(parts[3]))
    except Exception:
        pass

    return {
        "cpuUsagePercent": round(cpu_pct, 1),
        "gpuName": gpu_name,
        "gpuUsagePercent": gpu_usage,
        "gpuMemoryUsedMb": vram_used,
        "gpuMemoryTotalMb": vram_total,
        "diskFreeGb": disk_free_gb,
    }


def run_backend_connection_diagnostics() -> None:
    print(f"[diagnostics] Verifying connection to Cloud Control Center: {STUDIO_BACKEND_URL}")
    try:
        health_resp = requests.get(
            f"{STUDIO_BACKEND_URL}/api/health",
            headers={"Accept": "application/json"},
            timeout=15,
        )
        ctype = health_resp.headers.get("content-type", "")
        if health_resp.status_code != 200 or "application/json" not in ctype:
            raise RuntimeError(
                f"/api/health returned HTTP {health_resp.status_code} (Content-Type: {ctype}). "
                f"Ensure STUDIO_BACKEND_URL uses the Shared App URL ({DEFAULT_SHARED_BACKEND_URL})."
            )
        try:
            health_data = health_resp.json()
        except ValueError as exc:
            raise RuntimeError("/api/health returned invalid JSON.") from exc

        # Match the documented Express health contract; a generic HTML page or
        # unrelated JSON endpoint must never be accepted as the control plane.
        if not isinstance(health_data, dict):
            raise RuntimeError("/api/health JSON response must be an object.")
        if health_data.get('status') != 'ok':
            raise RuntimeError("/api/health response must contain status='ok'.")
        if health_data.get('service') != 'JapanComic Studio Control Plane':
            raise RuntimeError("/api/health returned an unexpected service identity.")
        if not isinstance(health_data.get('timestamp'), str) or not health_data['timestamp'].strip():
            raise RuntimeError("/api/health response is missing its server timestamp.")

        print(
            f"[diagnostics] Backend health OK: {health_data['service']} "
            f"(server timestamp: {health_data['timestamp']})"
        )
    except Exception as exc:
        raise SystemExit(f"FATAL: Cannot reach STUDIO_BACKEND_URL ({STUDIO_BACKEND_URL}): {exc}")

    try:
        status_resp = requests.get(
            f"{STUDIO_BACKEND_URL}/api/worker/status",
            headers=api_headers(),
            timeout=15,
        )
        if status_resp.status_code == 503:
            raise SystemExit(
                "FATAL: Server returned HTTP 503 — WORKER_API_SECRET is not configured in the "
                "Cloud Control Center server environment secrets (minimum 16 characters)."
            )
        if status_resp.status_code in (401, 403):
            raise SystemExit(
                f"FATAL: Server returned HTTP {status_resp.status_code} — WORKER_API_SECRET in "
                "worker/.env does not match WORKER_API_SECRET configured on the Cloud server."
            )
        status_resp.raise_for_status()
        status_data = status_resp.json()
        print(
            f"[diagnostics] Worker authentication verified! Queue stats: "
            f"queued={status_data.get('queuedCount', 0)}, "
            f"active={status_data.get('activeCount', 0)}, "
            f"completed={status_data.get('completedCount', 0)}"
        )
    except SystemExit:
        raise
    except Exception as exc:
        raise SystemExit(f"FATAL: Worker authentication diagnostic failed: {exc}")


def check_comfyui_connectivity() -> Tuple[bool, str]:
    try:
        resp = requests.get(f"{COMFYUI_URL}/system_stats", timeout=5)
        if resp.status_code == 200:
            return True, f"ComfyUI online at {COMFYUI_URL}"
        return False, f"ComfyUI returned HTTP {resp.status_code} at {COMFYUI_URL}"
    except Exception as exc:
        return False, f"ComfyUI unreachable at {COMFYUI_URL}: {exc}"


def register_worker() -> None:
    payload = {
        "workerId": WORKER_ID,
        "name": WORKER_NAME,
        "machineName": MACHINE_NAME,
        "hostname": MACHINE_NAME,
        "os": f"{platform.system()} {platform.release()}",
        "version": WORKER_VERSION,
        "capabilities": ["scene_image", "voice_synthesis", "video_render", "full_episode"],
    }
    resp = requests.post(
        f"{STUDIO_BACKEND_URL}/api/worker/register",
        headers=api_headers(),
        json=payload,
        timeout=15,
    )
    resp.raise_for_status()
    print(f"[worker] Registered {WORKER_ID} (v{WORKER_VERSION} on {MACHINE_NAME}) with {STUDIO_BACKEND_URL}")


def unregister_worker() -> None:
    try:
        requests.post(
            f"{STUDIO_BACKEND_URL}/api/worker/unregister",
            headers=api_headers(),
            json={"workerId": WORKER_ID},
            timeout=10,
        )
        print(f"[worker] Marked {WORKER_ID} Offline cleanly.")
    except Exception as exc:
        print(f"[worker] unregister warning: {exc}")


def heartbeat_loop() -> None:
    while True:
        try:
            with state_lock:
                payload = {
                    "workerId": WORKER_ID,
                    "status": worker_status,
                    "version": WORKER_VERSION,
                    "machineName": MACHINE_NAME,
                    "currentJobId": current_job_id,
                    "currentJobProgress": current_job_progress,
                    "metrics": collect_hardware_metrics(),
                    "lastError": last_error,
                }
            resp = requests.post(
                f"{STUDIO_BACKEND_URL}/api/worker/heartbeat",
                headers=api_headers(),
                json=payload,
                timeout=15,
            )
            if resp.status_code == 404:
                register_worker()
        except Exception as exc:
            print(f"[heartbeat] warning: {exc}")
        time.sleep(HEARTBEAT_INTERVAL_SEC)


def report_progress(job_id: str, progress: int, stage_message: str, status: str = "processing") -> None:
    global current_job_progress
    with state_lock:
        current_job_progress = progress
    requests.post(
        f"{STUDIO_BACKEND_URL}/api/worker/progress",
        headers=api_headers(),
        json={
            "workerId": WORKER_ID,
            "jobId": job_id,
            "progress": progress,
            "status": status,
            "stageMessage": stage_message,
        },
        timeout=15,
    ).raise_for_status()


def upload_artifact(category: str, file_path: Path, extension: str) -> str:
    raw = file_path.read_bytes()
    b64 = base64.b64encode(raw).decode("ascii")
    resp = requests.post(
        f"{STUDIO_BACKEND_URL}/api/worker/upload",
        headers=api_headers(),
        json={
            "category": category,
            "extension": extension,
            "dataBase64": b64,
        },
        timeout=120,
    )
    resp.raise_for_status()
    return resp.json()["url"]


def parse_lora_spec(raw_tag: str) -> Tuple[Optional[str], float]:
    """
    Parses a LoRA tag in either '<lora:filename:weight>' or 'filename.safetensors[:weight]' format.
    """
    tag = raw_tag.strip()
    if not tag:
        return None, 0.8
    m = re.match(r"^<lora:([^:>]+)(?::([0-9.]+))?>$", tag, re.IGNORECASE)
    if m:
        name = m.group(1).strip()
        weight = float(m.group(2)) if m.group(2) else 0.8
        if not name.lower().endswith((".safetensors", ".pt", ".ckpt")):
            name = f"{name}.safetensors"
        return name, weight

    parts = tag.split(":")
    name = parts[0].strip()
    weight = 0.8
    if len(parts) > 1:
        try:
            weight = float(parts[1])
        except ValueError:
            weight = 0.8
    if not name.lower().endswith((".safetensors", ".pt", ".ckpt")):
        name = f"{name}.safetensors"
    return name, weight


def upload_reference_image_to_comfyui(image_url: str, work_dir: Path) -> Optional[str]:
    """
    Downloads a character reference image URL and uploads it to local ComfyUI /upload/image
    so IPAdapter or reference nodes can consume it locally.
    """
    try:
        full_url = image_url if image_url.startswith("http") else f"{STUDIO_BACKEND_URL}{image_url}"
        resp = requests.get(full_url, timeout=20)
        resp.raise_for_status()
        ref_path = work_dir / f"char_ref_{int(time.time() * 1000)}.png"
        ref_path.write_bytes(resp.content)
        with ref_path.open("rb") as f:
            up_resp = requests.post(
                f"{COMFYUI_URL}/upload/image",
                files={"image": (ref_path.name, f, "image/png")},
                data={"overwrite": "true"},
                timeout=15,
            )
            if up_resp.status_code == 200:
                return up_resp.json().get("name", ref_path.name)
    except Exception as exc:
        print(f"[worker] Reference image staging notice: {exc}")
    return None


def get_comfyui_available_nodes() -> set:
    try:
        resp = requests.get(f"{COMFYUI_URL}/object_info", timeout=8)
        if resp.status_code == 200:
            return set(resp.json().keys())
    except Exception:
        pass
    return set()


def run_comfyui_scene(job: Dict[str, Any], work_dir: Path) -> Path:
    """
    Executes a local ComfyUI workflow at COMFYUI_URL.
    - Verifies live ComfyUI connectivity before dispatching.
    - Respects width & height from job.payload (clamped to multiples of 8).
    - Applies character appearance/clothing continuity, LoRA Loader nodes, and IPAdapter reference images when present.
    """
    ok, msg = check_comfyui_connectivity()
    if not ok:
        raise RuntimeError(f"Local ComfyUI connectivity check failed: {msg}")

    payload = job.get("payload", {})
    raw_width = int(payload.get("width") or 1920)
    raw_height = int(payload.get("height") or 1080)
    target_width = max(512, min(2048, (raw_width // 8) * 8))
    target_height = max(512, min(2048, (raw_height // 8) * 8))

    positive = str(payload.get("imagePrompt") or "japanese motion comic scene, cinematic lighting").strip()
    negative = str(payload.get("negativePrompt") or "lowres, watermark, text, blurry").strip()

    characters: List[Dict[str, Any]] = payload.get("characters") if isinstance(payload.get("characters"), list) else []
    available_nodes = get_comfyui_available_nodes()

    # Build character visual continuity descriptors and extract LoRA / IPAdapter configurations
    char_prompt_additions: List[str] = []
    lora_specs: List[Tuple[str, float]] = []
    primary_ref_image_name: Optional[str] = None
    primary_ipadapter_weight: float = 0.75

    for ch in characters:
        if not isinstance(ch, dict):
            continue
        c_name = str(ch.get("name") or "").strip()
        c_app = str(ch.get("appearance") or "").strip()
        c_cloth = str(ch.get("clothing") or "").strip()
        if c_name and (c_app or c_cloth):
            trait_str = ", ".join(filter(None, [c_name, c_app, c_cloth]))
            if trait_str.lower() not in positive.lower():
                char_prompt_additions.append(trait_str)

        raw_lora = str(ch.get("comfyLoraTag") or "").strip()
        if raw_lora:
            lora_name, lora_weight = parse_lora_spec(raw_lora)
            if lora_name:
                lora_specs.append((lora_name, lora_weight))

        ref_imgs = ch.get("referenceImages")
        if primary_ref_image_name is None and isinstance(ref_imgs, list) and len(ref_imgs) > 0:
            first_url = str(ref_imgs[0] or "").strip()
            if first_url:
                uploaded_name = upload_reference_image_to_comfyui(first_url, work_dir)
                if uploaded_name:
                    primary_ref_image_name = uploaded_name
                    try:
                        primary_ipadapter_weight = float(ch.get("ipAdapterWeight") or 0.75)
                    except (TypeError, ValueError):
                        primary_ipadapter_weight = 0.75

    if char_prompt_additions:
        positive = f"{positive}, {', '.join(char_prompt_additions)}"

    workflow: Dict[str, Any] = {
        "4": {
            "class_type": "CheckpointLoaderSimple",
            "inputs": {"ckpt_name": COMFYUI_CHECKPOINT},
        },
        "5": {
            "class_type": "EmptyLatentImage",
            "inputs": {
                "width": target_width,
                "height": target_height,
                "batch_size": 1,
            },
        },
    }

    current_model_ref: List[Any] = ["4", 0]
    current_clip_ref: List[Any] = ["4", 1]

    # Chain LoraLoader nodes when character LoRAs are configured and supported by ComfyUI
    if lora_specs and ("LoraLoader" in available_nodes or not available_nodes):
        for idx, (lora_name, lora_weight) in enumerate(lora_specs):
            node_id = str(10 + idx)
            workflow[node_id] = {
                "class_type": "LoraLoader",
                "inputs": {
                    "model": current_model_ref,
                    "clip": current_clip_ref,
                    "lora_name": lora_name,
                    "strength_model": lora_weight,
                    "strength_clip": lora_weight,
                },
            }
            current_model_ref = [node_id, 0]
            current_clip_ref = [node_id, 1]

    # Chain IPAdapterUnifiedLoader + IPAdapter when reference image is uploaded and IPAdapter nodes exist
    if (
        primary_ref_image_name
        and "LoadImage" in available_nodes
        and "IPAdapterUnifiedLoader" in available_nodes
        and "IPAdapter" in available_nodes
    ):
        workflow["20"] = {
            "class_type": "LoadImage",
            "inputs": {"image": primary_ref_image_name},
        }
        workflow["21"] = {
            "class_type": "IPAdapterUnifiedLoader",
            "inputs": {
                "model": current_model_ref,
                "preset": "STANDARD (medium strength)",
            },
        }
        workflow["22"] = {
            "class_type": "IPAdapter",
            "inputs": {
                "model": ["21", 0],
                "ipadapter": ["21", 1],
                "image": ["20", 0],
                "weight": max(0.0, min(2.0, primary_ipadapter_weight)),
                "start_at": 0.0,
                "end_at": 1.0,
                "weight_type": "standard",
            },
        }
        current_model_ref = ["22", 0]

    workflow["6"] = {
        "class_type": "CLIPTextEncode",
        "inputs": {"text": positive, "clip": current_clip_ref},
    }
    workflow["7"] = {
        "class_type": "CLIPTextEncode",
        "inputs": {"text": negative, "clip": current_clip_ref},
    }
    workflow["3"] = {
        "class_type": "KSampler",
        "inputs": {
            "seed": int(time.time()) % 2_000_000_000,
            "steps": 24,
            "cfg": 7.0,
            "sampler_name": "dpmpp_2m",
            "scheduler": "karras",
            "denoise": 1.0,
            "model": current_model_ref,
            "positive": ["6", 0],
            "negative": ["7", 0],
            "latent_image": ["5", 0],
        },
    }
    workflow["8"] = {
        "class_type": "VAEDecode",
        "inputs": {"samples": ["3", 0], "vae": ["4", 2]},
    }
    workflow["9"] = {
        "class_type": "SaveImage",
        "inputs": {
            "filename_prefix": f"jcs_{job['jobId']}",
            "images": ["8", 0],
        },
    }

    prompt_resp = requests.post(f"{COMFYUI_URL}/prompt", json={"prompt": workflow}, timeout=20)
    if prompt_resp.status_code != 200 and lora_specs:
        # If a specified LoRA file isn't installed locally, fall back to base checkpoint model cleanly
        print(
            f"[worker] Notice: ComfyUI rejected LoRA workflow (HTTP {prompt_resp.status_code}); "
            "retrying with base checkpoint."
        )
        for k in list(workflow.keys()):
            if k not in ("3", "4", "5", "6", "7", "8", "9"):
                del workflow[k]
        workflow["6"]["inputs"]["clip"] = ["4", 1]
        workflow["7"]["inputs"]["clip"] = ["4", 1]
        workflow["3"]["inputs"]["model"] = ["4", 0]
        prompt_resp = requests.post(f"{COMFYUI_URL}/prompt", json={"prompt": workflow}, timeout=20)

    prompt_resp.raise_for_status()
    prompt_id = prompt_resp.json()["prompt_id"]

    # Poll ComfyUI local history until image appears
    for step in range(90):
        time.sleep(2)
        report_progress(
            job["jobId"],
            min(80, 15 + step),
            f"Generating {target_width}x{target_height} artwork via local ComfyUI",
        )
        hist_resp = requests.get(f"{COMFYUI_URL}/history/{prompt_id}", timeout=10)
        if hist_resp.status_code == 200:
            hist = hist_resp.json()
            if prompt_id in hist:
                outputs = hist[prompt_id].get("outputs", {})
                for node_out in outputs.values():
                    images = node_out.get("images", [])
                    if images:
                        img_info = images[0]
                        qs = urllib.parse.urlencode(
                            {
                                "filename": img_info["filename"],
                                "subfolder": img_info.get("subfolder", ""),
                                "type": img_info.get("type", "output"),
                            }
                        )
                        img_bytes = requests.get(f"{COMFYUI_URL}/view?{qs}", timeout=30).content
                        out_path = work_dir / f"scene_{job.get('sceneNumber', 1)}.png"
                        out_path.write_bytes(img_bytes)
                        return out_path

    raise RuntimeError("Timed out waiting for local ComfyUI output.")


def run_ffmpeg_render(job: Dict[str, Any], work_dir: Path) -> Path:
    """
    Renders 1920x1080 30fps H.264/AAC MP4 from scene images, pan/zoom motion, and narration audio.
    """
    payload = job.get("payload", {})
    scenes: List[Dict[str, Any]] = payload.get("scenes", [])
    if not scenes:
        raise RuntimeError("No scenes supplied in video_render job payload.")

    clip_paths: List[Path] = []
    total_scenes = len(scenes)

    for idx, sc in enumerate(scenes):
        img_url = sc.get("generatedImageUrl", "")
        if not img_url:
            raise RuntimeError(f"Scene {sc.get('sceneNumber', idx + 1)} has no generated image URL.")
        full_img_url = img_url if img_url.startswith("http") else f"{STUDIO_BACKEND_URL}{img_url}"
        img_path = work_dir / f"scene_{idx}.png"
        img_path.write_bytes(requests.get(full_img_url, timeout=30).content)

        dur = max(3, int(sc.get("durationSeconds", 6)))
        frames = dur * 30
        clip_path = work_dir / f"clip_{idx}.mp4"

        vf = (
            f"scale=3840:2160,"
            f"zoompan=z='min(zoom+0.0008,1.15)':d={frames}:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s=1920x1080:fps=30,"
            f"format=yuv420p"
        )
        subprocess.run(
            [
                FFMPEG_BIN, "-y", "-loop", "1", "-i", str(img_path),
                "-vf", vf, "-t", str(dur),
                "-c:v", "libx264", "-preset", "medium", "-crf", "18",
                str(clip_path),
            ],
            check=True,
        )
        clip_paths.append(clip_path)
        pct = 15 + int(((idx + 1) / total_scenes) * 65)
        report_progress(job["jobId"], pct, f"Encoded scene clip {idx + 1}/{total_scenes}")

    concat_file = work_dir / "concat.txt"
    concat_file.write_text("\n".join([f"file '{p.as_posix()}'" for p in clip_paths]), encoding="utf-8")

    merged_video = work_dir / "merged.mp4"
    subprocess.run(
        [FFMPEG_BIN, "-y", "-f", "concat", "-safe", "0", "-i", str(concat_file), "-c", "copy", str(merged_video)],
        check=True,
    )

    audio_url = payload.get("narrationAudioUrl", "")
    final_mp4 = work_dir / "master_1080p.mp4"
    if audio_url:
        full_audio_url = audio_url if audio_url.startswith("http") else f"{STUDIO_BACKEND_URL}{audio_url}"
        audio_path = work_dir / "narration.mp3"
        audio_path.write_bytes(requests.get(full_audio_url, timeout=30).content)
        subprocess.run(
            [
                FFMPEG_BIN, "-y", "-i", str(merged_video), "-i", str(audio_path),
                "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest",
                str(final_mp4),
            ],
            check=True,
        )
    else:
        final_mp4 = merged_video

    return final_mp4


def process_job(job: Dict[str, Any]) -> None:
    global current_job_id, current_job_progress, worker_status, last_error
    job_id = job["jobId"]
    job_type = job["type"]

    with state_lock:
        current_job_id = job_id
        current_job_progress = 0
        worker_status = "Busy"

    try:
        with tempfile.TemporaryDirectory(prefix="jcs_worker_") as tmp:
            work_dir = Path(tmp)
            if job_type == "scene_image":
                report_progress(job_id, 10, "Checking local ComfyUI & submitting prompt")
                img_path = run_comfyui_scene(job, work_dir)
                report_progress(job_id, 90, "Uploading scene artwork", status="uploading")
                asset_url = upload_artifact("scenes", img_path, "png")
                requests.post(
                    f"{STUDIO_BACKEND_URL}/api/worker/complete",
                    headers=api_headers(),
                    json={
                        "workerId": WORKER_ID,
                        "jobId": job_id,
                        "outputUrl": asset_url,
                        "enterApproval": False,
                    },
                    timeout=30,
                ).raise_for_status()
            elif job_type in ("video_render", "full_episode"):
                report_progress(job_id, 10, "Preparing 1080p FFmpeg render pipeline")
                mp4_path = run_ffmpeg_render(job, work_dir)
                report_progress(job_id, 90, "Uploading 1080p MP4 master", status="uploading")
                asset_url = upload_artifact("videos", mp4_path, "mp4")
                requests.post(
                    f"{STUDIO_BACKEND_URL}/api/worker/complete",
                    headers=api_headers(),
                    json={
                        "workerId": WORKER_ID,
                        "jobId": job_id,
                        "outputUrl": asset_url,
                        "enterApproval": True,
                        "outputMetadata": {"resolution": "1920x1080", "fps": 30},
                    },
                    timeout=60,
                ).raise_for_status()
            else:
                raise RuntimeError(f"Unsupported local worker job type: {job_type}")

        with state_lock:
            last_error = None
            worker_status = "Online"

    except Exception as exc:
        err_msg = str(exc)
        print(f"[worker] Job {job_id} failed: {err_msg}")
        with state_lock:
            last_error = err_msg
            worker_status = "Error"
        try:
            requests.post(
                f"{STUDIO_BACKEND_URL}/api/worker/fail",
                headers=api_headers(),
                json={
                    "workerId": WORKER_ID,
                    "jobId": job_id,
                    "errorMessage": err_msg,
                    "retryable": True,
                },
                timeout=15,
            )
        except Exception:
            pass
    finally:
        with state_lock:
            current_job_id = None
            current_job_progress = None
            if worker_status != "Error":
                worker_status = "Online"


def verify_local_tools() -> None:
    ok, msg = check_comfyui_connectivity()
    if ok:
        print(f"[worker] {msg}")
    else:
        print(f"[worker] Warning: {msg} (scene_image jobs will fail until ComfyUI is started)")

    if shutil.which(FFMPEG_BIN):
        print(f"[worker] FFmpeg found: {FFMPEG_BIN}")
    else:
        print(f"[worker] Warning: FFmpeg binary '{FFMPEG_BIN}' not found in PATH")


def main() -> None:
    if not WORKER_API_SECRET or len(WORKER_API_SECRET) < 16:
        raise SystemExit("ERROR: Set WORKER_API_SECRET (16+ chars) in worker/.env before starting.")

    run_backend_connection_diagnostics()
    verify_local_tools()
    register_worker()
    hb_thread = threading.Thread(target=heartbeat_loop, daemon=True)
    hb_thread.start()

    print("[worker] Polling for production jobs... Press Ctrl+C to stop cleanly.")
    try:
        while True:
            try:
                resp = requests.post(
                    f"{STUDIO_BACKEND_URL}/api/worker/claim",
                    headers=api_headers(),
                    json={"workerId": WORKER_ID, "capabilities": ["all"]},
                    timeout=15,
                )
                resp.raise_for_status()
                job = resp.json().get("job")
                if job:
                    print(f"[worker] Claimed job {job['jobId']} ({job['type']})")
                    process_job(job)
            except Exception as exc:
                print(f"[worker] Poll error: {exc}")
            time.sleep(POLL_INTERVAL_SEC)
    except KeyboardInterrupt:
        print("\n[worker] Shutdown requested...")
    finally:
        unregister_worker()


if __name__ == "__main__":
    main()
