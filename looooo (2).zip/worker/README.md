# JapanComic Studio — Windows 11 Local Production Worker (v1.2.0)

This Python worker runs on your local ASUS Windows 11 PC alongside **ComfyUI** (`http://127.0.0.1:8188`) and **FFmpeg**. It connects outbound over authenticated HTTPS to the JapanComic Studio cloud backend so local GPU ports are never exposed to the public internet.

## Setup (Windows 11)

1. Install Python 3.11+, NVIDIA CUDA drivers, and verify `ffmpeg -version` works in PowerShell.
2. Start ComfyUI locally on `http://127.0.0.1:8188`.
3. Configure `WORKER_API_SECRET` (16+ random characters) in your Cloud Control Center secrets and copy it into `worker/.env`:
   ```powershell
   cd worker
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   copy .env.example .env
   # Edit .env and set STUDIO_BACKEND_URL & WORKER_API_SECRET
   python worker.py
   ```
4. Open **Worker Monitor** in JapanComic Studio to verify live `Online` status, machine name, worker version, CPU/GPU/VRAM telemetry, and heartbeat timestamps.
