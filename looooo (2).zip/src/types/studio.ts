export type ProductionStatus =
  | 'draft'
  | 'queued'
  | 'claimed'
  | 'processing'
  | 'uploading'
  | 'completed'
  | 'failed'
  | 'cancelled'
  | 'pending_approval'
  | 'approved'
  | 'rejected';

export type StoryGenre =
  | 'Drama'
  | 'Business'
  | 'Revenge'
  | 'Mystery'
  | 'Romance'
  | 'Historical'
  | 'Psychological'
  | 'Thriller'
  | 'Inspirational';

export type VisualStyle =
  | 'Motion Comic'
  | 'Seinen Ink'
  | 'Watercolor Anime'
  | 'Noir Manga';

export type WorkerStatus = 'Online' | 'Offline' | 'Busy' | 'Error';

export type ConnectionState = 'checking' | 'connected' | 'offline' | 'error';

export type NavSection =
  | 'dashboard'
  | 'projects'
  | 'story-studio'
  | 'characters'
  | 'scenes'
  | 'voice-studio'
  | 'video-composer'
  | 'production-queue'
  | 'approval-center'
  | 'worker-monitor'
  | 'worker-setup'
  | 'youtube-publishing'
  | 'settings';

export interface Project {
  projectId: string;
  userId: string;
  title: string;
  description: string;
  language: 'ja';
  visualStyle: VisualStyle;
  status: 'active' | 'archived' | 'completed';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface CharacterVoiceSettings {
  stability: number;
  similarityBoost: number;
  style: number;
  speakingRate: number;
  voiceDirection: string;
}

export interface Character {
  characterId: string;
  userId: string;
  projectId: string;
  name: string;
  ageDescription: string;
  personality: string;
  appearance: string;
  clothing: string;
  referenceImages: string[];
  comfyLoraTag?: string;
  ipAdapterWeight?: number;
  voiceId: string;
  voiceSettings: CharacterVoiceSettings;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface DialogueLine {
  characterName: string;
  line: string;
  emotion: string;
}

export interface Scene {
  sceneNumber: number;
  narration: string;
  dialogue: DialogueLine[];
  characters: string[];
  location: string;
  timeOfDay: string;
  mood: string;
  sceneDescription: string;
  emotionalDirection: string;
  visualDescription: string;
  transition: string;
  imagePrompt: string;
  negativePrompt: string;
  cameraMovement: 'static' | 'slow_zoom_in' | 'slow_zoom_out' | 'pan_left' | 'pan_right' | 'tilt_up' | 'dramatic_push';
  durationSeconds: number;
  generatedImageUrl: string;
  generationStatus: 'pending' | 'queued' | 'generating' | 'generated' | 'approved' | 'failed';
  audioUrl?: string;
}

export interface StoryScript {
  japaneseTitle: string;
  synopsis: string;
  narratorDirection: string;
  estimatedDurationSec: number;
  scenes: Scene[];
}

export interface RenderHistoryEntry {
  renderId: string;
  jobId: string;
  renderedAt: string;
  durationSec: number;
  resolution: string;
  fps: number;
  videoUrl: string;
  status: 'completed' | 'failed';
  notes?: string;
}

export interface VideoOutput {
  url: string;
  durationSec: number;
  resolution: string;
  fps: number;
  format: string;
  videoCodec: string;
  audioCodec: string;
  aspectRatio: string;
  renderedAt: string;
  renderHistory: RenderHistoryEntry[];
}

export interface YouTubeDraft {
  videoTitle: string;
  description: string;
  tags: string[];
  thumbnailUrl: string;
  visibility: 'private' | 'unlisted' | 'public';
  scheduledPublishAt: string;
  publishedVideoId?: string;
  publishedAt?: string;
}

export interface Episode {
  episodeId: string;
  userId: string;
  projectId: string;
  title: string;
  japaneseTitle?: string;
  genre: StoryGenre;
  mainIdea?: string;
  targetAudience?: string;
  desiredDuration?: string;
  sceneCount?: number;
  emotionalTone?: string;
  endingType?: string;
  status: ProductionStatus;
  scriptApproved: boolean;
  storyScript?: StoryScript;
  scenes: Scene[];
  narrationAudioUrl?: string;
  videoOutput?: VideoOutput;
  youtubeDraft?: YouTubeDraft;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface ApprovalRecord {
  approvalId: string;
  userId: string;
  projectId: string;
  episodeId: string;
  reviewerId: string;
  decision: 'approved' | 'rejected' | 'changes_requested';
  comments: string;
  reviewedAt?: unknown;
}

export interface StudioSettings {
  userId: string;
  comfyuiUrl: string;
  defaultVoiceDirection: string;
  videoResolution: '1920x1080';
  videoFps: 30;
  videoFormat: 'mp4';
  videoCodec: 'H.264';
  audioCodec: 'AAC';
  aspectRatio: '16:9';
  storagePrefix: string;
  updatedAt?: unknown;
}

export type JobType = 'scene_image' | 'voice_synthesis' | 'video_render' | 'full_episode';

export interface ProductionJob {
  jobId: string;
  userId: string;
  projectId: string;
  episodeId: string;
  episodeTitle: string;
  sceneNumber?: number;
  type: JobType;
  status: ProductionStatus;
  progress: number;
  stageMessage?: string;
  payload: Record<string, unknown>;
  workerId?: string;
  leaseExpiresAt?: string;
  attemptCount: number;
  maxAttempts: number;
  idempotencyKey?: string;
  errorMessage?: string;
  outputUrl?: string;
  outputMetadata?: Record<string, unknown>;
  history: Array<{
    timestamp: string;
    status: ProductionStatus;
    message: string;
  }>;
  createdAt: string;
  updatedAt: string;
}

export interface WorkerMetrics {
  cpuUsagePercent: number | null;
  gpuName: string | null;
  gpuUsagePercent: number | null;
  gpuMemoryUsedMb: number | null;
  gpuMemoryTotalMb: number | null;
  diskFreeGb: number | null;
}

export interface WorkerNode {
  workerId: string;
  name: string;
  machineName?: string;
  hostname: string;
  os: string;
  version?: string;
  status: WorkerStatus;
  capabilities: string[];
  lastHeartbeat: string;
  registeredAt: string;
  currentJobId: string | null;
  currentJobProgress: number | null;
  metrics: WorkerMetrics | null;
  lastError: string | null;
}

export interface IntegrationStatus {
  geminiConfigured: boolean;
  elevenlabsConfigured: boolean;
  workerAuthConfigured: boolean;
  firebaseConfigured: boolean;
  youtubeConfigured: boolean;
  storageBucket: string | null;
  comfyuiMode: string;
  sharedBackendUrl?: string;
}
