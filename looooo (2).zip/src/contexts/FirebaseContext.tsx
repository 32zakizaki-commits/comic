import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import { doc, getDoc, serverTimestamp, setDoc } from 'firebase/firestore';
import { useCallback } from 'react';
import {
  auth,
  checkFirestoreConnection,
  db,
  googleProvider,
  handleFirestoreError,
  OperationType,
  type FirestoreConnectionState,
} from '../lib/firebase';

interface FirebaseContextValue {
  user: User | null;
  authReady: boolean;
  authError: string | null;
  signingIn: boolean;
  firestoreStatus: FirestoreConnectionState;
  firestoreError: string | null;
  recheckFirestoreConnection: () => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  signOutUser: () => Promise<void>;
  getIdToken: () => Promise<string | null>;
}

const FirebaseContext = createContext<FirebaseContextValue | null>(null);

async function syncUserProfileDocs(user: User): Promise<void> {
  const userRef = doc(db, 'users', user.uid);
  const privateRef = doc(db, 'users', user.uid, 'private', 'info');

  try {
    const existing = await getDoc(userRef);
    if (!existing.exists()) {
      await setDoc(userRef, {
        uid: user.uid,
        displayName: (user.displayName || 'Studio Producer').slice(0, 120),
        photoURL: (user.photoURL || '').slice(0, 500),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(
        userRef,
        {
          displayName: (user.displayName || 'Studio Producer').slice(0, 120),
          photoURL: (user.photoURL || '').slice(0, 500),
          updatedAt: serverTimestamp(),
        },
        { merge: true },
      );
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
  }

  if (user.email) {
    try {
      const existingPriv = await getDoc(privateRef);
      if (!existingPriv.exists()) {
        await setDoc(privateRef, {
          uid: user.uid,
          email: user.email.slice(0, 254),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}/private/info`);
    }
  }
}

export function FirebaseProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [signingIn, setSigningIn] = useState(false);
  const [firestoreStatus, setFirestoreStatus] = useState<FirestoreConnectionState>('checking');
  const [firestoreError, setFirestoreError] = useState<string | null>(null);

  const recheckFirestoreConnection = useCallback(async (uidOverride?: string | null) => {
    setFirestoreStatus('checking');
    const result = await checkFirestoreConnection(
      uidOverride !== undefined ? uidOverride : auth.currentUser?.uid ?? null,
    );
    setFirestoreStatus(result.status);
    setFirestoreError(result.error);
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (nextUser) => {
      setUser(nextUser);
      setAuthReady(true);
      if (nextUser) {
        try {
          await syncUserProfileDocs(nextUser);
          setFirestoreStatus('connected');
          setFirestoreError(null);
        } catch (err) {
          console.error('[auth] profile sync warning:', err);
          setFirestoreStatus('error');
          setFirestoreError(err instanceof Error ? err.message : 'Firestore profile sync failed.');
        }
        void recheckFirestoreConnection(nextUser.uid);
      } else {
        void recheckFirestoreConnection(null);
      }
    });
    return () => unsub();
  }, [recheckFirestoreConnection]);

  const signInWithGoogle = async () => {
    setAuthError(null);
    setSigningIn(true);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Google sign-in failed.';
      setAuthError(msg);
    } finally {
      setSigningIn(false);
    }
  };

  const signOutUser = async () => {
    await signOut(auth);
  };

  const getIdToken = async (): Promise<string | null> => {
    if (!auth.currentUser) return null;
    return auth.currentUser.getIdToken();
  };

  return (
    <FirebaseContext.Provider
      value={{
        user,
        authReady,
        authError,
        signingIn,
        firestoreStatus,
        firestoreError,
        recheckFirestoreConnection: () => recheckFirestoreConnection(),
        signInWithGoogle,
        signOutUser,
        getIdToken,
      }}
    >
      {children}
    </FirebaseContext.Provider>
  );
}

export function useFirebase(): FirebaseContextValue {
  const ctx = useContext(FirebaseContext);
  if (!ctx) {
    throw new Error('useFirebase must be used inside FirebaseProvider');
  }
  return ctx;
}
