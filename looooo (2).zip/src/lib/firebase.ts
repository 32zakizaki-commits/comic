import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { doc, getDocFromServer, getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const storage = getStorage(app);
export const googleProvider = new GoogleAuthProvider();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null,
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid ?? null,
      email: auth.currentUser?.email ?? null,
      emailVerified: auth.currentUser?.emailVerified ?? null,
      isAnonymous: auth.currentUser?.isAnonymous ?? null,
      tenantId: auth.currentUser?.tenantId ?? null,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) ?? [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export type FirestoreConnectionState = 'checking' | 'connected' | 'offline' | 'error';

export async function checkFirestoreConnection(
  uid?: string | null,
): Promise<{ status: FirestoreConnectionState; error: string | null }> {
  try {
    if (uid) {
      await getDocFromServer(doc(db, 'users', uid));
    } else {
      await getDocFromServer(doc(db, 'test', 'connection'));
    }
    return { status: 'connected', error: null };
  } catch (error) {
    const code =
      typeof error === 'object' && error !== null && 'code' in error
        ? String((error as { code?: unknown }).code)
        : '';
    const message = error instanceof Error ? error.message : String(error);

    if (!uid && (code === 'permission-denied' || code === 'not-found')) {
      return { status: 'connected', error: null };
    }
    if (
      code === 'unavailable' ||
      message.includes('the client is offline') ||
      message.toLowerCase().includes('network')
    ) {
      return {
        status: 'offline',
        error: 'Firestore client is offline or unreachable.',
      };
    }
    return { status: 'error', error: message };
  }
}

async function testConnection(): Promise<void> {
  const result = await checkFirestoreConnection(null);
  if (result.status === 'offline') {
    console.error('Please check your Firebase configuration. Firestore client is offline.');
  }
}

void testConnection();
