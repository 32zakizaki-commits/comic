import { AlertTriangle, Mic, Play, RefreshCw } from 'lucide-react';
import { useEffect, useState } from 'react';
import { apiFetch } from '../lib/apiClient';
import type { Character, Episode, IntegrationStatus } from '../types/studio';

interface VoiceStudioViewProps {
  episodes: Episode[];
  characters: Character[];
  integrations: IntegrationStatus | null;
  selectedEpisodeId: string | null;
  onSelectEpisode: (episodeId: string) => void;
  onUpdateEpisode: (episodeId: string, updates: Partial<Episode>) => Promise<void>;
}

interface ElevenLabsVoice {
  voiceId: string;
  name: string;
  category: string;
}

export function VoiceStudioView({
  episodes,
  characters,
  integrations,
  selectedEpisodeId,
  onSelectEpisode,
  onUpdateEpisode,
}: VoiceStudioViewProps) {
  const activeEpisode =
    episodes.find((e) => e.episodeId === selectedEpisodeId) ?? episodes[0] ?? null;

  const [voices, setVoices] = useState<ElevenLabsVoice[]>([]);
  const [loadingVoices, setLoadingVoices] = useState(false);
  const [selectedVoiceId, setSelectedVoiceId] = useState('');
  const [customText, setCustomText] = useState('');
  const [stability, setStability] = useState(0.55);
  const [similarityBoost, setSimilarityBoost] = useState(0.78);
  const [generating, setGenerating] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(
    activeEpisode?.narrationAudioUrl ?? null,
  );
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (activeEpisode) {
      const fullNarration = activeEpisode.scenes
        .map((s) => s.narration)
        .filter(Boolean)
        .join('\n\n');
      setCustomText(fullNarration);
      setPreviewUrl(activeEpisode.narrationAudioUrl ?? null);
    }
  }, [activeEpisode?.episodeId]);

  const fetchVoices = async () => {
    if (!integrations?.elevenlabsConfigured) return;
    setLoadingVoices(true);
    setErrorMsg(null);
    try {
      const res = await apiFetch<{ configured: boolean; voices: ElevenLabsVoice[] }>(
        '/api/elevenlabs/voices',
      );
      setVoices(res.voices);
      if (res.voices[0] && !selectedVoiceId) {
        setSelectedVoiceId(res.voices[0].voiceId);
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to fetch ElevenLabs voices.');
    } finally {
      setLoadingVoices(false);
    }
  };

  useEffect(() => {
    if (integrations?.elevenlabsConfigured) {
      void fetchVoices();
    }
  }, [integrations?.elevenlabsConfigured]);

  const handleSynthesize = async (textOverride?: string, voiceOverride?: string) => {
    const textToSpeak = (textOverride ?? customText).trim();
    if (!textToSpeak) {
      setErrorMsg('Enter Japanese narration or dialogue text to synthesize.');
      return;
    }
    setGenerating(true);
    setErrorMsg(null);
    try {
      const res = await apiFetch<{ audioUrl: string; byteLength: number }>(
        '/api/elevenlabs/tts',
        {
          method: 'POST',
          body: JSON.stringify({
            text: textToSpeak,
            voiceId: voiceOverride || selectedVoiceId || undefined,
            stability,
            similarityBoost,
          }),
        },
      );
      setPreviewUrl(res.audioUrl);
      if (activeEpisode && !textOverride) {
        await onUpdateEpisode(activeEpisode.episodeId, {
          narrationAudioUrl: res.audioUrl,
        });
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Voice synthesis failed.');
    } finally {
      setGenerating(false);
    }
  };

  const configured = integrations?.elevenlabsConfigured ?? false;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">Voice Studio</h1>
          <p className="text-sm text-[#94A3B8] mt-1">
            Server-side ElevenLabs Japanese voice synthesis · Default direction: Deep professional Japanese male narrator.
          </p>
        </div>

        {episodes.length > 0 && (
          <select
            value={activeEpisode?.episodeId ?? ''}
            onChange={(e) => onSelectEpisode(e.target.value)}
            className="bg-[#121824] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
          >
            {episodes.map((ep) => (
              <option key={ep.episodeId} value={ep.episodeId}>
                {ep.title}
              </option>
            ))}
          </select>
        )}
      </div>

      {!configured && (
        <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-1 text-xs">
            <div className="font-semibold text-amber-300">
              ElevenLabs API: Not configured
            </div>
            <p className="text-[#CBD5E1]">
              Add <code className="font-mono-tabular text-amber-200">ELEVENLABS_API_KEY</code> (and optional{' '}
              <code className="font-mono-tabular text-amber-200">ELEVENLABS_DEFAULT_VOICE_ID</code>) to your server environment secrets to synthesize real Japanese voiceovers. Keys stay strictly on the backend.
            </p>
          </div>
        </div>
      )}

      {errorMsg && (
        <div className="p-3.5 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">
          {errorMsg}
        </div>
      )}

      <div className="grid lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
              Japanese Documentary Narrator Synthesis
            </h2>
            {configured && (
              <button
                type="button"
                onClick={() => void fetchVoices()}
                className="inline-flex items-center gap-1 text-xs text-amber-400 hover:text-amber-300 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingVoices ? 'animate-spin' : ''}`} />
                <span>Refresh Voices</span>
              </button>
            )}
          </div>

          <div className="grid sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2 space-y-1">
              <label className="text-xs text-[#94A3B8]">Narrator Voice</label>
              <select
                value={selectedVoiceId}
                onChange={(e) => setSelectedVoiceId(e.target.value)}
                disabled={!configured}
                className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9] disabled:opacity-50"
              >
                <option value="">
                  {configured ? 'Default Deep Japanese Male Narrator' : 'Not configured'}
                </option>
                {voices.map((v) => (
                  <option key={v.voiceId} value={v.voiceId}>
                    {v.name} ({v.category})
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-xs text-[#94A3B8]">Stability ({stability})</label>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={stability}
                onChange={(e) => setStability(Number(e.target.value))}
                className="w-full accent-amber-500 mt-2"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs text-[#94A3B8]">Japanese Narration Script</label>
            <textarea
              rows={7}
              value={customText}
              onChange={(e) => setCustomText(e.target.value)}
              placeholder="日本語のナレーションテキストを入力してください..."
              className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2.5 text-sm text-[#F1F5F9] leading-relaxed"
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
            <div className="text-xs text-[#64748B]">
              Model: eleven_multilingual_v2 · Language: ja
            </div>
            <button
              type="button"
              disabled={!configured || generating}
              onClick={() => void handleSynthesize()}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 disabled:opacity-50 cursor-pointer"
            >
              <Mic className="w-4 h-4" />
              <span>{generating ? 'Synthesizing...' : 'Generate Japanese Voiceover'}</span>
            </button>
          </div>

          {previewUrl && (
            <div className="pt-4 border-t border-[#232D3F] space-y-2">
              <div className="text-xs font-medium text-emerald-400">Generated Audio Preview</div>
              <audio controls src={previewUrl} className="w-full" />
            </div>
          )}
        </div>

        {/* Character Dialogue Voices */}
        <div className="lg:col-span-5 bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-4">
          <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
            Character Dialogue Profiles
          </h2>
          {characters.length === 0 ? (
            <p className="text-xs text-[#64748B]">
              No characters defined yet. Create characters in Character Manager to map custom dialogue voice IDs.
            </p>
          ) : (
            <div className="space-y-3">
              {characters.map((ch) => (
                <div
                  key={ch.characterId}
                  className="p-3.5 rounded-lg bg-[#0B0F17] border border-[#232D3F] flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-[#F1F5F9] truncate">{ch.name}</div>
                    <div className="text-[11px] font-mono-tabular text-[#94A3B8] truncate">
                      Voice: {ch.voiceId} · Stability {ch.voiceSettings?.stability ?? 0.55}
                    </div>
                  </div>
                  <button
                    type="button"
                    disabled={!configured || generating}
                    onClick={() =>
                      void handleSynthesize(
                        `私は${ch.name}です。準備はできています。`,
                        ch.voiceId,
                      )
                    }
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-[#171F2E] border border-[#232D3F] text-xs text-amber-400 hover:border-amber-500/40 disabled:opacity-40 shrink-0 cursor-pointer"
                  >
                    <Play className="w-3 h-3" />
                    <span>Test</span>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
