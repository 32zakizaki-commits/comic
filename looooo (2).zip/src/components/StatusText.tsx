import {
  AlertCircle,
  CheckCircle2,
  Clock,
  Cpu,
  FileEdit,
  Loader2,
  PauseCircle,
  UploadCloud,
  XCircle,
} from 'lucide-react';
import type { ProductionStatus, WorkerStatus } from '../types/studio';

const STATUS_CONFIG: Record<
  ProductionStatus,
  { label: string; colorClass: string; Icon: typeof Clock }
> = {
  draft: { label: 'Draft', colorClass: 'text-slate-400', Icon: FileEdit },
  queued: { label: 'Queued', colorClass: 'text-amber-400', Icon: Clock },
  claimed: { label: 'Claimed', colorClass: 'text-amber-300', Icon: Cpu },
  processing: { label: 'Processing', colorClass: 'text-amber-400', Icon: Loader2 },
  uploading: { label: 'Uploading', colorClass: 'text-sky-400', Icon: UploadCloud },
  completed: { label: 'Completed', colorClass: 'text-emerald-400', Icon: CheckCircle2 },
  failed: { label: 'Failed', colorClass: 'text-red-400', Icon: AlertCircle },
  cancelled: { label: 'Cancelled', colorClass: 'text-slate-500', Icon: PauseCircle },
  pending_approval: { label: 'Pending Approval', colorClass: 'text-amber-300', Icon: Clock },
  approved: { label: 'Approved', colorClass: 'text-emerald-400', Icon: CheckCircle2 },
  rejected: { label: 'Rejected', colorClass: 'text-red-400', Icon: XCircle },
};

export function ProductionStatusLabel({ status }: { status: ProductionStatus }) {
  const cfg = STATUS_CONFIG[status] ?? STATUS_CONFIG.draft;
  const Icon = cfg.Icon;
  const spin = status === 'processing';
  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-medium whitespace-nowrap ${cfg.colorClass}`}>
      <Icon className={`w-3.5 h-3.5 shrink-0 ${spin ? 'animate-spin' : ''}`} />
      <span>{cfg.label}</span>
    </span>
  );
}

export function WorkerStatusLabel({ status }: { status: WorkerStatus }) {
  const map: Record<WorkerStatus, { colorClass: string; Icon: typeof CheckCircle2 }> = {
    Online: { colorClass: 'text-emerald-400', Icon: CheckCircle2 },
    Busy: { colorClass: 'text-amber-400', Icon: Loader2 },
    Offline: { colorClass: 'text-slate-400', Icon: PauseCircle },
    Error: { colorClass: 'text-red-400', Icon: AlertCircle },
  };
  const cfg = map[status] ?? map.Offline;
  const Icon = cfg.Icon;
  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-medium whitespace-nowrap ${cfg.colorClass}`}>
      <Icon className={`w-3.5 h-3.5 shrink-0 ${status === 'Busy' ? 'animate-spin' : ''}`} />
      <span>{status}</span>
    </span>
  );
}
