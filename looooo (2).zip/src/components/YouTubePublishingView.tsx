import { AlertTriangle, Lock, Save, Youtube } from 'lucide-react';
import { useEffect, useState } from 'react';
import { apiFetch } from '../lib/apiClient';
import type { Episode, IntegrationStatus } from '../types/studio';
import { ProductionStatusLabel } from './StatusText';

interface YouTubePublishingViewProps {
  episodes: Episode[];
  integrations: IntegrationStatus | null;
  onUpdateEpisode: (episodeId: string, updates: Partial<Episode>) => Promise<void>;
}

export function YouTubePublishingView({
  episodes,
  integrations,
  onUpdateEpisode,
}: YouTubePublishingViewProps) {
  const [selectedEpId, setSelectedEpId] = useState(episodes[0]?.episodeId ?? '');
  const activeEpisode =
    episodes.find((e) => e.episodeId === selectedEpId) ?? episodes[0] ?? null;

  const [videoTitle, setVideoTitle] = useState('');
  const [description, setDescription] = useState('');
  const [tagsText, setTagsText] = useState('モーションコミック, 日本語ストーリー, 漫画動画');
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [visibility, setVisibility] = useState<'private' | 'unlisted' | 'public'>('private');
  const [scheduledPublishAt, setScheduledPublishAt] = useState('');

  const [saving, setSaving] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (activeEpisode) {
      setVideoTitle(
        activeEpisode.youtubeDraft?.videoTitle ||
          activeEpisode.japaneseTitle ||
          activeEpisode.title,
      );
      setDescription(
        activeEpisode.youtubeDraft?.description ||
          activeEpisode.storyScript?.synopsis ||
          '',
      );
      setTagsText(
        activeEpisode.youtubeDraft?.tags?.join(', ') ||
          'モーションコミック, 日本語ストーリー, JapanComic',
      );
      setThumbnailUrl(
        activeEpisode.youtubeDraft?.thumbnailUrl ||
          activeEpisode.scenes?.[0]?.generatedImageUrl ||
          '',
      );
      setVisibility(activeEpisode.youtubeDraft?.visibility ?? 'private');
      setScheduledPublishAt(activeEpisode.youtubeDraft?.scheduledPublishAt ?? '');
    }
  }, [activeEpisode?.episodeId]);

  const isApproved = activeEpisode?.status === 'approved';
  const youtubeConfigured = integrations?.youtubeConfigured ?? false;

  const handleSaveDraft = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeEpisode) return;
    setSaving(true);
    setNotice(null);
    setErrorMsg(null);
    try {
      await onUpdateEpisode(activeEpisode.episodeId, {
        youtubeDraft: {
          videoTitle: videoTitle.trim(),
          description: description.trim(),
          tags: tagsText
            .split(',')
            .map((t) => t.trim())
            .filter(Boolean)
            .slice(0, 20),
          thumbnailUrl: thumbnailUrl.trim(),
          visibility,
          scheduledPublishAt,
        },
      });
      setNotice('YouTube release metadata saved to episode.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to save YouTube draft.');
    } finally {
      setSaving(false);
    }
  };

  const handleManualPublish = async () => {
    if (!activeEpisode) return;
    setPublishing(true);
    setNotice(null);
    setErrorMsg(null);
    try {
      const res = await apiFetch<{ ok: boolean; message: string }>(
        '/api/youtube/publish',
        {
          method: 'POST',
          body: JSON.stringify({
            episodeId: activeEpisode.episodeId,
            episodeStatus: activeEpisode.status,
            title: videoTitle,
            description,
            tags: tagsText
              .split(',')
              .map((t) => t.trim())
              .filter(Boolean),
            visibility,
            scheduledPublishAt,
          }),
        },
      );
      setNotice(res.message);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Publish verification failed.');
    } finally {
      setPublishing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">
            YouTube Publishing
          </h1>
          <p className="text-sm text-[#94A3B8] mt-1">
            Manual release preparation. Publishing stays disabled until explicit approval in Approval Center and valid YouTube OAuth secrets.
          </p>
        </div>

        {episodes.length > 0 && (
          <select
            value={activeEpisode?.episodeId ?? ''}
            onChange={(e) => setSelectedEpId(e.target.value)}
            className="bg-[#121824] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
          >
            {episodes.map((ep) => (
              <option key={ep.episodeId} value={ep.episodeId}>
                {ep.title} ({ep.status})
              </option>
            ))}
          </select>
        )}
      </div>

      {!youtubeConfigured && (
        <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-1 text-xs">
            <div className="font-semibold text-amber-300">
              YouTube OAuth: Not configured
            </div>
            <p className="text-[#CBD5E1]">
              Configure <code className="font-mono-tabular">YOUTUBE_CLIENT_ID</code>,{' '}
              <code className="font-mono-tabular">YOUTUBE_CLIENT_SECRET</code>,{' '}
              <code className="font-mono-tabular">YOUTUBE_REDIRECT_URI</code>, and{' '}
              <code className="font-mono-tabular">YOUTUBE_REFRESH_TOKEN</code> on the server to enable YouTube upload authorization. You can still prepare and save release metadata below.
            </p>
          </div>
        </div>
      )}

      {activeEpisode && !isApproved && (
        <div className="p-4 rounded-xl bg-[#121824] border border-[#232D3F] flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-xs text-[#CBD5E1]">
            <Lock className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              Publishing is locked for <strong>{activeEpisode.title}</strong> until a human reviewer marks it <strong>Approved</strong> in the Approval Center.
            </span>
          </div>
          <ProductionStatusLabel status={activeEpisode.status} />
        </div>
      )}

      {errorMsg && (
        <div className="p-3.5 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">
          {errorMsg}
        </div>
      )}
      {notice && (
        <div className="p-3.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300">
          {notice}
        </div>
      )}

      {activeEpisode && (
        <form
          onSubmit={(e) => void handleSaveDraft(e)}
          className="bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-4 max-w-4xl"
        >
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-[#94A3B8]">Video Title</label>
              <input
                type="text"
                value={videoTitle}
                onChange={(e) => setVideoTitle(e.target.value)}
                className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-[#94A3B8]">Thumbnail Image URL</label>
              <input
                type="text"
                value={thumbnailUrl}
                onChange={(e) => setThumbnailUrl(e.target.value)}
                placeholder="Populated from approved scene frame or custom URL"
                className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-[#94A3B8]">Description</label>
            <textarea
              rows={5}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
            />
          </div>

          <div className="grid sm:grid-cols-3 gap-4">
            <div className="sm:col-span-1 space-y-1.5">
              <label className="text-xs font-medium text-[#94A3B8]">Visibility</label>
              <select
                value={visibility}
                onChange={(e) =>
                  setVisibility(e.target.value as 'private' | 'unlisted' | 'public')
                }
                className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
              >
                <option value="private">Private</option>
                <option value="unlisted">Unlisted</option>
                <option value="public">Public</option>
              </select>
            </div>
            <div className="sm:col-span-2 space-y-1.5">
              <label className="text-xs font-medium text-[#94A3B8]">
                Scheduled Publishing Time (Optional)
              </label>
              <input
                type="datetime-local"
                value={scheduledPublishAt}
                onChange={(e) => setScheduledPublishAt(e.target.value)}
                className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm font-mono-tabular text-[#F1F5F9]"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-[#94A3B8]">Tags (Comma-separated)</label>
            <input
              type="text"
              value={tagsText}
              onChange={(e) => setTagsText(e.target.value)}
              className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
            />
          </div>

          <div className="flex flex-wrap items-center justify-end gap-3 pt-2 border-t border-[#232D3F]">
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#171F2E] border border-[#232D3F] text-sm font-medium text-[#F1F5F9] hover:border-slate-500 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Saving...' : 'Save Release Metadata'}</span>
            </button>
            <button
              type="button"
              disabled={!isApproved || !youtubeConfigured || publishing}
              onClick={() => void handleManualPublish()}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 disabled:opacity-40 cursor-pointer"
            >
              <Youtube className="w-4 h-4" />
              <span>
                {publishing ? 'Authorizing...' : 'Verify & Queue Manual Publish'}
              </span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
