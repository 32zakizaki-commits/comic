import {
  Activity,
  AlertTriangle,
  Check,
  Image as ImageIcon,
  RefreshCw,
  RotateCcw,
  Sparkles,
  XCircle,
} from 'lucide-react';
import { useMemo, useState } from 'react';
import type { FirestoreJobRecord } from '../hooks/useStudioData';
import type {
  Character,
  ConnectionState,
  Episode,
  JobType,
  ProductionJob,
  ProductionStatus,
  WorkerNode,
  WorkerStatus,
} from '../types/studio';

interface SceneGeneratorViewProps {
  episodes: Episode[];
  characters: Character[];
  jobs: ProductionJob[];
  firestoreJobs: FirestoreJobRecord[];
  workers: WorkerNode[];
  workerAuthConfigured?: boolean;
  apiStatus: ConnectionState;
  apiError: string | null;
  firestoreStatus: ConnectionState;
  firestoreError: string | null;
  lastJobError: string | null;
  selectedEpisodeId: string | null;
  onSelectEpisode: (episodeId: string) => void;
  onUpdateEpisode: (episodeId: string, updates: Partial<Episode>) => Promise<void>;
  onEnqueueJob: (input: {
    projectId: string;
    episodeId: string;
    episodeTitle: string;
    sceneNumber?: number;
    type: JobType;
    payload: Record<string, unknown>;
    idempotencyKey?: string;
  }) => Promise<{ job: ProductionJob; deduplicated: boolean }>;
  onCancelJob: (jobId: string) => Promise<void>;
  onRetryJob: (jobId: string) => Promise<void>;
  onRecheckConnections: () => Promise<void>;
}

const STYLE_SPECIMEN = '/src/assets/images/motion_comic_specimen_1795391144276.jpg';
const ACTIVE_STATUSES: ProductionStatus[] = ['queued', 'claimed', 'processing', 'uploading'];

function isActiveStatus(status?: ProductionStatus): boolean {
  return Boolean(status && ACTIVE_STATUSES.includes(status));
}

function formatConnectionLabel(state: ConnectionState): string {
  switch (state) {
    case 'connected':
      return 'Connected';
    case 'offline':
      return 'Offline';
    case 'error':
      return 'Error';
    default:
      return 'Checking...';
  }
}

function getConnectionTextClass(state: ConnectionState): string {
  switch (state) {
    case 'connected':
      return 'text-emerald-400';
    case 'offline':
    case 'error':
      return 'text-red-400';
    default:
      return 'text-amber-400';
  }
}

function getWorkerStatusTextClass(status: WorkerStatus): string {
  switch (status) {
    case 'Online':
      return 'text-emerald-400';
    case 'Busy':
      return 'text-amber-400';
    case 'Error':
      return 'text-red-400';
    default:
      return 'text-slate-400';
  }
}

export function SceneGeneratorView({
  episodes,
  characters,
  jobs,
  firestoreJobs,
  workers,
  workerAuthConfigured = true,
  apiStatus,
  apiError,
  firestoreStatus,
  firestoreError,
  lastJobError,
  selectedEpisodeId,
  onSelectEpisode,
  onUpdateEpisode,
  onEnqueueJob,
  onCancelJob,
  onRetryJob,
  onRecheckConnections,
}: SceneGeneratorViewProps) {
  const activeEpisode =
    episodes.find((e) => e.episodeId === selectedEpisodeId) ?? episodes[0] ?? null;

  const [dispatchingScene, setDispatchingScene] = useState<number | 'all' | null>(null);
  const [busyJobActionId, setBusyJobActionId] = useState<string | null>(null);
  const [rechecking, setRechecking] = useState(false);
  const [lastDispatchedJobId, setLastDispatchedJobId] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [specimenFailed, setSpecimenFailed] = useState(false);

  const projectChars = activeEpisode
    ? characters.filter((c) => c.projectId === activeEpisode.projectId)
    : [];

  // Derive worker connection state cleanly from real worker heartbeats
  const activeWorker = useMemo(
    () =>
      workers.find((w) => w.status === 'Online' || w.status === 'Busy') ??
      workers[0] ??
      null,
    [workers],
  );
  const workerStatus: WorkerStatus = activeWorker?.status ?? 'Offline';
  const isWorkerOffline = workerStatus === 'Offline' || workers.length === 0;

  // Index Firestore job mirrors by jobId for real-time listener synchronization & diagnostics
  const firestoreJobMap = useMemo(() => {
    const map = new Map<string, FirestoreJobRecord>();
    for (const fj of firestoreJobs) {
      map.set(fj.jobId, fj);
    }
    return map;
  }, [firestoreJobs]);

  // Merge backend jobs with real-time Firestore listener snapshots for each scene of activeEpisode
  const episodeSceneJobs = useMemo(() => {
    if (!activeEpisode) return new Map<number, ProductionJob>();
    const map = new Map<number, ProductionJob>();

    const relevantBackendJobs = jobs.filter(
      (j) =>
        j.episodeId === activeEpisode.episodeId &&
        j.type === 'scene_image' &&
        typeof j.sceneNumber === 'number',
    );

    for (const job of relevantBackendJobs) {
      const sn = job.sceneNumber!;
      if (!map.has(sn)) {
        const fsMirror = firestoreJobMap.get(job.jobId);
        const mergedProgress =
          fsMirror && fsMirror.progress > job.progress && fsMirror.status === job.status
            ? fsMirror.progress
            : job.progress;
        map.set(sn, {
          ...job,
          progress: mergedProgress,
          stageMessage: fsMirror?.stageMessage || job.stageMessage,
          errorMessage: fsMirror?.errorMessage || job.errorMessage,
          workerId: fsMirror?.workerId || job.workerId,
          outputUrl: fsMirror?.outputUrl || job.outputUrl,
        });
      }
    }

    // Fallback to Firestore /jobs/{jobId} mirror if backend queue is still rehydrating
    for (const fsJob of firestoreJobs) {
      if (
        fsJob.episodeId === activeEpisode.episodeId &&
        fsJob.type === 'scene_image' &&
        typeof fsJob.sceneNumber === 'number' &&
        !map.has(fsJob.sceneNumber)
      ) {
        map.set(fsJob.sceneNumber, {
          jobId: fsJob.jobId,
          userId: fsJob.userId,
          projectId: fsJob.projectId,
          episodeId: fsJob.episodeId,
          episodeTitle: activeEpisode.title,
          sceneNumber: fsJob.sceneNumber,
          type: fsJob.type,
          status: fsJob.status,
          progress: fsJob.progress,
          stageMessage: fsJob.stageMessage,
          payload: {},
          workerId: fsJob.workerId,
          leaseExpiresAt: fsJob.leaseExpiresAt,
          attemptCount: fsJob.attemptCount ?? 0,
          maxAttempts: fsJob.maxAttempts ?? 3,
          errorMessage: fsJob.errorMessage,
          outputUrl: fsJob.outputUrl,
          history: [],
          createdAt: '',
          updatedAt: '',
        });
      }
    }

    return map;
  }, [activeEpisode, jobs, firestoreJobs, firestoreJobMap]);

  // Select diagnostic target job (most recently dispatched job if it belongs to this episode, otherwise latest scene job)
  const diagnosticJob = useMemo(() => {
    if (!activeEpisode) return null;
    if (lastDispatchedJobId) {
      const match = jobs.find(
        (j) =>
          j.jobId === lastDispatchedJobId &&
          j.episodeId === activeEpisode.episodeId &&
          j.type === 'scene_image',
      );
      if (match) return match;
    }
    return (
      jobs.find(
        (j) => j.episodeId === activeEpisode.episodeId && j.type === 'scene_image',
      ) ?? null
    );
  }, [activeEpisode, jobs, lastDispatchedJobId]);

  const diagnosticFsMirror = diagnosticJob
    ? firestoreJobMap.get(diagnosticJob.jobId) ?? null
    : null;

  const diagnosticLastError =
    errorMsg ||
    lastJobError ||
    apiError ||
    firestoreError ||
    diagnosticJob?.errorMessage ||
    activeWorker?.lastError ||
    null;

  const queueSceneJob = async (sceneNumber: number) => {
    if (!activeEpisode) return;
    if (dispatchingScene !== null) return;

    const existingJob = episodeSceneJobs.get(sceneNumber);
    if (existingJob && isActiveStatus(existingJob.status)) {
      setErrorMsg(
        `Scene ${sceneNumber} already has an active job (${existingJob.jobId} · ${existingJob.status}).`,
      );
      return;
    }

    const scene = activeEpisode.scenes.find((s) => s.sceneNumber === sceneNumber);
    if (!scene) return;

    setDispatchingScene(sceneNumber);
    setErrorMsg(null);
    setNotice(null);

    try {
      const res = await onEnqueueJob({
        projectId: activeEpisode.projectId,
        episodeId: activeEpisode.episodeId,
        episodeTitle: activeEpisode.title,
        sceneNumber,
        type: 'scene_image',
        payload: {
          sceneNumber,
          imagePrompt: scene.imagePrompt,
          negativePrompt: scene.negativePrompt,
          cameraMovement: scene.cameraMovement,
          characters: projectChars.filter((c) => scene.characters?.includes(c.name)),
          width: 1920,
          height: 1080,
        },
      });

      setLastDispatchedJobId(res.job.jobId);

      const nextScenes = activeEpisode.scenes.map((sc) =>
        sc.sceneNumber === sceneNumber ? { ...sc, generationStatus: 'queued' as const } : sc,
      );
      await onUpdateEpisode(activeEpisode.episodeId, { scenes: nextScenes });

      if (res.deduplicated) {
        setNotice(
          `Existing active job ${res.job.jobId} reused for Scene ${sceneNumber} (duplicate submission prevented).`,
        );
      } else if (isWorkerOffline) {
        setNotice(
          `Job ${res.job.jobId} created in Firestore & backend queue. Worker Offline – Waiting for Production Worker.`,
        );
      } else {
        setNotice(
          `Job ${res.job.jobId} queued for Scene ${sceneNumber} (${activeWorker?.name ?? 'Local Worker'}).`,
        );
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to queue scene job.');
    } finally {
      setDispatchingScene(null);
    }
  };

  const queueAllScenes = async () => {
    if (!activeEpisode || activeEpisode.scenes.length === 0) return;
    if (dispatchingScene !== null) return;

    const eligibleScenes = activeEpisode.scenes.filter((sc) => {
      const existing = episodeSceneJobs.get(sc.sceneNumber);
      return !existing || !isActiveStatus(existing.status);
    });

    if (eligibleScenes.length === 0) {
      setNotice('All scenes already have active jobs in the production queue.');
      return;
    }

    setDispatchingScene('all');
    setErrorMsg(null);
    setNotice(null);

    const queuedIds: string[] = [];
    const queuedSceneNums = new Set<number>();

    try {
      for (const sc of eligibleScenes) {
        const res = await onEnqueueJob({
          projectId: activeEpisode.projectId,
          episodeId: activeEpisode.episodeId,
          episodeTitle: activeEpisode.title,
          sceneNumber: sc.sceneNumber,
          type: 'scene_image',
          payload: {
            sceneNumber: sc.sceneNumber,
            imagePrompt: sc.imagePrompt,
            negativePrompt: sc.negativePrompt,
            cameraMovement: sc.cameraMovement,
            characters: projectChars.filter((c) => sc.characters?.includes(c.name)),
            width: 1920,
            height: 1080,
          },
        });
        queuedIds.push(res.job.jobId);
        queuedSceneNums.add(sc.sceneNumber);
        setLastDispatchedJobId(res.job.jobId);
      }

      const nextScenes = activeEpisode.scenes.map((sc) =>
        queuedSceneNums.has(sc.sceneNumber)
          ? { ...sc, generationStatus: 'queued' as const }
          : sc,
      );
      await onUpdateEpisode(activeEpisode.episodeId, { scenes: nextScenes });

      setNotice(
        isWorkerOffline
          ? `Created ${queuedIds.length} scene jobs. Worker Offline – Waiting for Production Worker.`
          : `Queued ${queuedIds.length} scene jobs for your Local Production Worker.`,
      );
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Batch scene queueing failed.');
    } finally {
      setDispatchingScene(null);
    }
  };

  const handleCancelJob = async (jobId: string, sceneNumber: number) => {
    if (!activeEpisode) return;
    setBusyJobActionId(jobId);
    setErrorMsg(null);
    setNotice(null);
    try {
      await onCancelJob(jobId);
      const nextScenes = activeEpisode.scenes.map((sc) =>
        sc.sceneNumber === sceneNumber && !sc.generatedImageUrl
          ? { ...sc, generationStatus: 'pending' as const }
          : sc,
      );
      await onUpdateEpisode(activeEpisode.episodeId, { scenes: nextScenes });
      setNotice(`Job ${jobId} (Scene ${sceneNumber}) cancelled.`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to cancel job.');
    } finally {
      setBusyJobActionId(null);
    }
  };

  const handleRetryJob = async (jobId: string, sceneNumber: number) => {
    if (!activeEpisode) return;
    setBusyJobActionId(jobId);
    setErrorMsg(null);
    setNotice(null);
    try {
      await onRetryJob(jobId);
      setLastDispatchedJobId(jobId);
      const nextScenes = activeEpisode.scenes.map((sc) =>
        sc.sceneNumber === sceneNumber ? { ...sc, generationStatus: 'queued' as const } : sc,
      );
      await onUpdateEpisode(activeEpisode.episodeId, { scenes: nextScenes });
      setNotice(`Job ${jobId} (Scene ${sceneNumber}) re-queued.`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to retry job.');
    } finally {
      setBusyJobActionId(null);
    }
  };

  const approveScene = async (sceneNumber: number) => {
    if (!activeEpisode) return;
    const nextScenes = activeEpisode.scenes.map((sc) =>
      sc.sceneNumber === sceneNumber ? { ...sc, generationStatus: 'approved' as const } : sc,
    );
    await onUpdateEpisode(activeEpisode.episodeId, { scenes: nextScenes });
  };

  const handleRecheck = async () => {
    setRechecking(true);
    try {
      await onRecheckConnections();
    } finally {
      setRechecking(false);
    }
  };

  const allScenesActive =
    Boolean(activeEpisode && activeEpisode.scenes.length > 0) &&
    activeEpisode!.scenes.every((sc) => {
      const j = episodeSceneJobs.get(sc.sceneNumber);
      return Boolean(j && isActiveStatus(j.status));
    });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">
            Scene Generator
          </h1>
          <p className="text-sm text-[#94A3B8] mt-1">
            Dispatch ComfyUI image generation jobs to your local Windows 11 Worker. The browser never connects to ComfyUI directly.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {episodes.length > 0 && (
            <select
              value={activeEpisode?.episodeId ?? ''}
              onChange={(e) => onSelectEpisode(e.target.value)}
              className="bg-[#121824] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
            >
              {episodes.map((ep) => (
                <option key={ep.episodeId} value={ep.episodeId}>
                  {ep.title}
                </option>
              ))}
            </select>
          )}
          {activeEpisode && activeEpisode.scenes.length > 0 && (
            <button
              type="button"
              disabled={dispatchingScene !== null || allScenesActive}
              onClick={() => void queueAllScenes()}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 disabled:opacity-50 whitespace-nowrap cursor-pointer"
            >
              <RefreshCw
                className={`w-4 h-4 ${dispatchingScene === 'all' ? 'animate-spin' : ''}`}
              />
              <span>
                {dispatchingScene === 'all'
                  ? 'Queueing Scenes...'
                  : allScenesActive
                    ? 'All Scenes Active'
                    : 'Queue Missing / Regenerate All'}
              </span>
            </button>
          )}
        </div>
      </div>

      {/* Explicit Worker Offline Banner */}
      {isWorkerOffline && (
        <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <div className="text-xs font-semibold text-amber-300">
                Worker Offline – Waiting for Production Worker
              </div>
              <p className="text-xs text-[#CBD5E1]">
                Jobs you queue are persisted to the cloud queue and Firestore, and remain at 0% until your Windows 11 Python worker (ComfyUI + FFmpeg) comes online and claims them.
              </p>
            </div>
          </div>
          <span className="font-mono-tabular text-[11px] text-amber-300 shrink-0">
            Status: Offline
          </span>
        </div>
      )}

      {errorMsg && (
        <div className="p-3.5 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">
          {errorMsg}
        </div>
      )}
      {notice && (
        <div className="p-3.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300">
          {notice}
        </div>
      )}

      {/* Visible Live Pipeline Diagnostics Section */}
      <section
        aria-label="Scene Generator Diagnostics"
        className="bg-[#121824] border border-[#232D3F] rounded-xl p-4 sm:p-5 space-y-4"
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-amber-400" />
            <h2 className="font-display text-sm font-semibold text-[#F1F5F9]">
              Pipeline Diagnostics
            </h2>
          </div>
          <button
            type="button"
            disabled={rechecking}
            onClick={() => void handleRecheck()}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0B0F17] border border-[#232D3F] text-xs font-medium text-[#CBD5E1] hover:text-[#F1F5F9] hover:border-slate-500 disabled:opacity-50 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${rechecking ? 'animate-spin' : ''}`} />
            <span>{rechecking ? 'Checking...' : 'Check Connections'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
          <div className="p-3 rounded-lg bg-[#0B0F17] border border-[#232D3F] space-y-1">
            <div className="text-[#64748B]">API Connection Status</div>
            <div className={`font-mono-tabular font-medium ${getConnectionTextClass(apiStatus)}`}>
              {formatConnectionLabel(apiStatus)}
            </div>
            <div className="text-[11px] text-[#64748B] truncate">
              Endpoint: POST /api/jobs · GET /api/health
            </div>
          </div>

          <div className="p-3 rounded-lg bg-[#0B0F17] border border-[#232D3F] space-y-1">
            <div className="text-[#64748B]">Firestore Connection Status</div>
            <div
              className={`font-mono-tabular font-medium ${getConnectionTextClass(firestoreStatus)}`}
            >
              {formatConnectionLabel(firestoreStatus)}
            </div>
            <div className="text-[11px] text-[#64748B] font-mono-tabular truncate">
              Mirror Docs: {firestoreJobs.length} ·{' '}
              {diagnosticJob
                ? diagnosticFsMirror
                  ? 'Job Synced'
                  : 'Syncing Job...'
                : 'Listener Active'}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-[#0B0F17] border border-[#232D3F] space-y-1">
            <div className="text-[#64748B]">Worker Status</div>
            <div className={`font-mono-tabular font-medium ${getWorkerStatusTextClass(workerStatus)}`}>
              {isWorkerOffline
                ? 'Worker Offline – Waiting for Production Worker'
                : `${workerStatus}${activeWorker ? ` (${activeWorker.name})` : ''}`}
            </div>
            <div className="text-[11px] text-[#64748B] font-mono-tabular truncate">
              {!workerAuthConfigured
                ? 'WORKER_API_SECRET not set in server secrets'
                : activeWorker?.lastHeartbeat
                  ? `Last heartbeat: ${new Date(activeWorker.lastHeartbeat).toLocaleTimeString()}`
                  : 'No worker registered'}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-[#0B0F17] border border-[#232D3F] space-y-1">
            <div className="text-[#64748B]">Job ID</div>
            <div className="font-mono-tabular font-medium text-[#F1F5F9] break-all">
              {diagnosticJob?.jobId ?? lastDispatchedJobId ?? 'None'}
            </div>
            <div className="text-[11px] text-[#64748B] font-mono-tabular">
              {typeof diagnosticJob?.sceneNumber === 'number'
                ? `Target: Scene ${diagnosticJob.sceneNumber}`
                : 'Dispatch a scene to inspect job ID'}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-[#0B0F17] border border-[#232D3F] space-y-1">
            <div className="text-[#64748B]">Job Status</div>
            <div className="font-mono-tabular font-medium text-amber-400">
              {diagnosticJob
                ? `${diagnosticJob.status} (${diagnosticJob.progress}%)`
                : 'idle'}
            </div>
            <div className="text-[11px] text-[#94A3B8] truncate">
              {diagnosticJob?.stageMessage ?? 'No active scene job selected'}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-[#0B0F17] border border-[#232D3F] space-y-1">
            <div className="text-[#64748B]">Last Error</div>
            <div
              className={`font-mono-tabular break-words ${
                diagnosticLastError ? 'text-red-300' : 'text-emerald-400'
              }`}
            >
              {diagnosticLastError ?? 'None'}
            </div>
          </div>
        </div>
      </section>

      {/* Style Target Reference Banner */}
      <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5 grid md:grid-cols-12 gap-5 items-center">
        <div className="md:col-span-4 aspect-video rounded-lg overflow-hidden border border-[#232D3F] bg-[#0B0F17]">
          {!specimenFailed ? (
            <img
              src={STYLE_SPECIMEN}
              alt="Motion Comic target visual aesthetic reference"
              referrerPolicy="no-referrer"
              onError={() => setSpecimenFailed(true)}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-xs text-[#64748B]">
              16:9 Motion Comic Reference
            </div>
          )}
        </div>
        <div className="md:col-span-8 space-y-2">
          <div className="text-xs font-medium text-amber-400">ComfyUI Style Target Reference</div>
          <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
            16:9 Widescreen Japanese Motion Comic Pipeline
          </h2>
          <p className="text-xs text-[#94A3B8] leading-relaxed">
            Generated scene frames appear below only after your local Windows 11 Production Worker executes ComfyUI and uploads the resulting image back to the studio. Unrendered scenes honestly display awaiting-worker progress from the backend and Firestore.
          </p>
        </div>
      </div>

      {!activeEpisode || activeEpisode.scenes.length === 0 ? (
        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-12 text-center space-y-2">
          <p className="text-sm text-[#94A3B8]">
            No scenes available for the selected episode yet.
          </p>
          <p className="text-xs text-[#64748B]">
            Generate a structured Japanese story in Story Studio first.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {activeEpisode.scenes.map((sc) => {
            const latestJob = episodeSceneJobs.get(sc.sceneNumber);
            const active = isActiveStatus(latestJob?.status);
            const fsSynced = latestJob ? firestoreJobMap.has(latestJob.jobId) : false;
            const progressPct = latestJob ? Math.max(0, Math.min(100, latestJob.progress)) : 0;
            const isDispatchingThis = dispatchingScene === sc.sceneNumber || dispatchingScene === 'all';
            const isActionBusy = latestJob ? busyJobActionId === latestJob.jobId : false;

            return (
              <div
                key={sc.sceneNumber}
                className="bg-[#121824] border border-[#232D3F] rounded-xl p-5 grid lg:grid-cols-12 gap-5"
              >
                {/* Left: 16:9 Generated Frame or Honest Awaiting Worker State */}
                <div className="lg:col-span-4 space-y-2.5">
                  <div className="aspect-video rounded-lg overflow-hidden border border-[#232D3F] bg-[#0B0F17] flex items-center justify-center">
                    {sc.generatedImageUrl ? (
                      <img
                        src={sc.generatedImageUrl}
                        alt={`Scene ${sc.sceneNumber}`}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="p-4 text-center space-y-1.5">
                        <ImageIcon className="w-6 h-6 text-[#475569] mx-auto" />
                        <div className="text-xs font-medium text-[#CBD5E1] font-mono-tabular">
                          {latestJob
                            ? `${latestJob.status} (${progressPct}%)`
                            : 'Awaiting Local Worker Render'}
                        </div>
                        <div className="text-[11px] text-[#94A3B8]">
                          {latestJob && isWorkerOffline && active
                            ? 'Worker Offline – Waiting for Production Worker'
                            : latestJob?.errorMessage
                              ? latestJob.errorMessage
                              : latestJob?.stageMessage || 'ComfyUI executes locally on Windows 11'}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Real backend progress bar (never simulated) */}
                  {latestJob && (
                    <div className="space-y-1.5 p-2.5 rounded-lg bg-[#0B0F17] border border-[#232D3F]">
                      <div className="flex items-center justify-between text-[11px] font-mono-tabular">
                        <span className="text-[#94A3B8] truncate pr-2">
                          {latestJob.jobId}
                        </span>
                        <span
                          className={
                            latestJob.status === 'failed'
                              ? 'text-red-400'
                              : latestJob.status === 'completed'
                                ? 'text-emerald-400'
                                : 'text-amber-400'
                          }
                        >
                          {latestJob.status} · {progressPct}%
                        </span>
                      </div>
                      <div className="h-1.5 rounded-full bg-[#171F2E] overflow-hidden">
                        <div
                          className={`h-full transition-all duration-300 ${
                            latestJob.status === 'failed'
                              ? 'bg-red-500'
                              : latestJob.status === 'completed'
                                ? 'bg-emerald-500'
                                : 'bg-amber-500'
                          }`}
                          style={{ width: `${progressPct}%` }}
                        />
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-[#64748B] font-mono-tabular">
                        <span className="truncate pr-2">
                          {isWorkerOffline && active
                            ? 'Worker Offline – Waiting for Production Worker'
                            : latestJob.errorMessage || latestJob.stageMessage || 'Queued'}
                        </span>
                        <span className="shrink-0">
                          {fsSynced ? 'Firestore synced' : 'Pending sync'}
                        </span>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-[11px] font-mono-tabular text-[#94A3B8]">
                    <span>Scene {sc.sceneNumber}</span>
                    <span>
                      {sc.cameraMovement} · {sc.durationSeconds}s
                    </span>
                  </div>
                </div>

                {/* Right: Scene Details & ComfyUI Prompts */}
                <div className="lg:col-span-8 flex flex-col justify-between space-y-4">
                  <div className="space-y-2.5">
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      <span className="text-[#CBD5E1] font-medium">
                        {sc.location} · {sc.timeOfDay} · Mood: {sc.mood}
                      </span>
                      <span className="font-mono-tabular text-amber-400">
                        Status: {latestJob ? `${latestJob.status} (${progressPct}%)` : sc.generationStatus}
                      </span>
                    </div>

                    <p className="text-sm text-[#F1F5F9]">{sc.narration}</p>

                    {sc.dialogue?.length > 0 && (
                      <div className="text-xs text-[#CBD5E1] space-y-1">
                        {sc.dialogue.map((d, idx) => (
                          <div key={idx}>
                            <span className="text-amber-300 font-medium">{d.characterName}:</span> 「{d.line}」
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="grid sm:grid-cols-2 gap-3 pt-1">
                      <div className="p-2.5 rounded-lg bg-[#0B0F17] border border-[#232D3F] text-[11px]">
                        <div className="text-[#64748B] mb-1">ComfyUI Positive Prompt</div>
                        <div className="text-[#CBD5E1] break-words">{sc.imagePrompt}</div>
                      </div>
                      <div className="p-2.5 rounded-lg bg-[#0B0F17] border border-[#232D3F] text-[11px]">
                        <div className="text-[#64748B] mb-1">Negative Prompt</div>
                        <div className="text-[#94A3B8] break-words">{sc.negativePrompt}</div>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-end gap-2 pt-2 border-t border-[#232D3F]">
                    {latestJob && active && (
                      <button
                        type="button"
                        disabled={isActionBusy}
                        onClick={() => void handleCancelJob(latestJob.jobId, sc.sceneNumber)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#171F2E] border border-red-500/30 text-xs font-medium text-red-300 hover:bg-red-500/10 disabled:opacity-50 cursor-pointer"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>{isActionBusy ? 'Cancelling...' : 'Cancel Job'}</span>
                      </button>
                    )}

                    {latestJob &&
                      (latestJob.status === 'failed' || latestJob.status === 'cancelled') && (
                        <button
                          type="button"
                          disabled={isActionBusy}
                          onClick={() => void handleRetryJob(latestJob.jobId, sc.sceneNumber)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#171F2E] border border-amber-500/30 text-xs font-medium text-amber-300 hover:bg-amber-500/10 disabled:opacity-50 cursor-pointer"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>{isActionBusy ? 'Retrying...' : 'Retry Job'}</span>
                        </button>
                      )}

                    <button
                      type="button"
                      disabled={dispatchingScene !== null || active}
                      onClick={() => void queueSceneJob(sc.sceneNumber)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-semibold text-xs hover:bg-amber-400 disabled:opacity-50 cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>
                        {isDispatchingThis
                          ? 'Submitting...'
                          : active
                            ? `Job ${latestJob?.status} (${progressPct}%)`
                            : sc.generatedImageUrl
                              ? 'Regenerate Image'
                              : 'Generate Scene Image'}
                      </span>
                    </button>

                    <button
                      type="button"
                      disabled={!sc.generatedImageUrl}
                      onClick={() => void approveScene(sc.sceneNumber)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#171F2E] border border-[#232D3F] text-xs font-medium text-emerald-400 hover:border-emerald-500/40 disabled:opacity-40 cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Approve Image</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
