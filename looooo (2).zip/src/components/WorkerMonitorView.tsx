import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Cpu,
  RotateCcw,
  Server,
  Wrench,
  XCircle,
} from 'lucide-react';
import { useMemo, useState } from 'react';
import type { ConnectionState, ProductionJob, WorkerNode } from '../types/studio';
import { ProductionStatusLabel, WorkerStatusLabel } from './StatusText';

interface WorkerMonitorViewProps {
  workers: WorkerNode[];
  jobs: ProductionJob[];
  workerAuthConfigured: boolean;
  apiStatus: ConnectionState;
  firestoreStatus: ConnectionState;
  backendError: string | null;
  onRetryJob: (jobId: string) => Promise<void>;
  onCancelJob: (jobId: string) => Promise<void>;
  onOpenSetup: () => void;
}

type JobFilterTab = 'all' | 'pending' | 'completed' | 'failed';

function formatRelativeAge(isoTimestamp?: string): string {
  if (!isoTimestamp) return 'Never';
  const ts = Date.parse(isoTimestamp);
  if (!Number.isFinite(ts)) return 'Unknown';
  const diffSec = Math.max(0, Math.floor((Date.now() - ts) / 1000));
  if (diffSec < 60) return `${diffSec}s ago`;
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  return `${Math.floor(diffMin / 60)}h ago`;
}

export function WorkerMonitorView({
  workers,
  jobs,
  workerAuthConfigured,
  apiStatus,
  firestoreStatus,
  backendError,
  onRetryJob,
  onCancelJob,
  onOpenSetup,
}: WorkerMonitorViewProps) {
  const [activeTab, setActiveTab] = useState<JobFilterTab>('all');
  const [busyJobId, setBusyJobId] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  const primary = workers[0] ?? null;

  const pendingJobs = useMemo(
    () =>
      jobs.filter((j) =>
        ['queued', 'claimed', 'processing', 'uploading'].includes(j.status),
      ),
    [jobs],
  );
  const completedJobs = useMemo(
    () =>
      jobs.filter((j) =>
        ['completed', 'pending_approval', 'approved'].includes(j.status),
      ),
    [jobs],
  );
  const failedJobs = useMemo(
    () =>
      jobs.filter((j) => ['failed', 'cancelled', 'rejected'].includes(j.status)),
    [jobs],
  );

  const filteredJobs = useMemo(() => {
    switch (activeTab) {
      case 'pending':
        return pendingJobs;
      case 'completed':
        return completedJobs;
      case 'failed':
        return failedJobs;
      default:
        return jobs;
    }
  }, [activeTab, jobs, pendingJobs, completedJobs, failedJobs]);

  const activeClaimedJob = useMemo(
    () =>
      primary?.currentJobId
        ? jobs.find((j) => j.jobId === primary.currentJobId) ?? null
        : null,
    [primary, jobs],
  );

  const handleRetry = async (jobId: string) => {
    setBusyJobId(jobId);
    setActionError(null);
    try {
      await onRetryJob(jobId);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to retry job.');
    } finally {
      setBusyJobId(null);
    }
  };

  const handleCancel = async (jobId: string) => {
    setBusyJobId(jobId);
    setActionError(null);
    try {
      await onCancelJob(jobId);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to cancel job.');
    } finally {
      setBusyJobId(null);
    }
  };

  const machineName = primary?.machineName || primary?.hostname || null;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">
            Worker Monitor
          </h1>
          <p className="text-sm text-[#94A3B8] mt-1">
            Live Windows 11 Production Worker telemetry, atomic lease tracking, and job execution diagnostics. Metrics remain Unavailable until a real authenticated worker sends heartbeats.
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenSetup}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Wrench className="w-4 h-4" />
          <span>Windows 11 Worker Setup</span>
        </button>
      </div>

      {/* Diagnostic Alerts */}
      {!workerAuthConfigured && (
        <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200 flex items-start gap-3">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <strong>WORKER_API_SECRET</strong> is not configured on the backend server. Add a 16+ character secret to your server environment secrets and matching{' '}
            <code className="font-mono-tabular">worker/.env</code> on your Windows 11 PC before starting the worker.
          </div>
        </div>
      )}

      {(backendError || actionError || primary?.lastError) && (
        <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-200 space-y-1">
          <div className="font-semibold text-red-300 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>Diagnostic Error Detected</span>
          </div>
          {backendError && <div className="font-mono-tabular">API: {backendError}</div>}
          {actionError && <div className="font-mono-tabular">Action: {actionError}</div>}
          {primary?.lastError && (
            <div className="font-mono-tabular">Worker: {primary.lastError}</div>
          )}
        </div>
      )}

      {/* Primary Worker Identity & Telemetry Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5 space-y-2">
          <div className="text-xs text-[#94A3B8]">Worker Status</div>
          <div className="flex items-center justify-between gap-2">
            <WorkerStatusLabel status={primary?.status ?? 'Offline'} />
            <span className="font-mono-tabular text-[11px] text-[#64748B]">
              {workers.length} registered
            </span>
          </div>
          <div className="text-[11px] font-mono-tabular text-[#94A3B8]">
            Last heartbeat:{' '}
            {primary?.lastHeartbeat
              ? `${new Date(primary.lastHeartbeat).toLocaleString()} (${formatRelativeAge(primary.lastHeartbeat)})`
              : 'Not connected'}
          </div>
        </div>

        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5 space-y-2">
          <div className="text-xs text-[#94A3B8]">Machine Name & Version</div>
          <div className="font-mono-tabular text-base font-semibold text-[#F1F5F9] truncate">
            {machineName ?? 'Not connected'}
          </div>
          <div className="text-[11px] font-mono-tabular text-[#94A3B8] truncate">
            Version: {primary?.version ?? 'Unavailable'} · OS: {primary?.os ?? 'Windows 11'}
          </div>
        </div>

        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5 space-y-2">
          <div className="text-xs text-[#94A3B8]">Current Job ID</div>
          <div className="font-mono-tabular text-sm font-semibold text-[#F1F5F9] break-all">
            {primary?.currentJobId ?? 'Idle (No active job)'}
          </div>
          <div className="text-[11px] font-mono-tabular text-[#94A3B8]">
            {activeClaimedJob?.leaseExpiresAt
              ? `Lease expires: ${new Date(activeClaimedJob.leaseExpiresAt).toLocaleTimeString()}`
              : 'Lease: 120s atomic claim window'}
          </div>
        </div>

        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5 space-y-2">
          <div className="text-xs text-[#94A3B8]">Hardware Metrics (PC-Reported)</div>
          <div className="font-mono-tabular text-sm font-semibold text-[#F1F5F9]">
            CPU:{' '}
            {primary?.metrics?.cpuUsagePercent !== null &&
            primary?.metrics?.cpuUsagePercent !== undefined
              ? `${primary.metrics.cpuUsagePercent}%`
              : 'Unavailable'}{' '}
            · GPU:{' '}
            {primary?.metrics?.gpuUsagePercent !== null &&
            primary?.metrics?.gpuUsagePercent !== undefined
              ? `${primary.metrics.gpuUsagePercent}%`
              : 'Unavailable'}
          </div>
          <div className="text-[11px] font-mono-tabular text-[#94A3B8] truncate">
            {primary?.metrics?.gpuMemoryTotalMb
              ? `${primary.metrics.gpuName ?? 'GPU'} · ${primary.metrics.gpuMemoryUsedMb ?? 0}/${primary.metrics.gpuMemoryTotalMb} MB · Disk ${primary.metrics.diskFreeGb ?? '?'} GB`
              : primary?.metrics?.diskFreeGb !== undefined && primary?.metrics?.diskFreeGb !== null
                ? `Disk free: ${primary.metrics.diskFreeGb} GB · GPU telemetry unavailable`
                : 'Awaiting real worker hardware report'}
          </div>
        </div>
      </div>

      {/* Job Counts + Control Plane Status */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-4 space-y-1">
          <div className="text-xs text-[#94A3B8] flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>Pending & Active Jobs</span>
          </div>
          <div className="font-mono-tabular text-2xl font-semibold text-amber-400">
            {pendingJobs.length}
          </div>
        </div>

        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-4 space-y-1">
          <div className="text-xs text-[#94A3B8] flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Completed Jobs</span>
          </div>
          <div className="font-mono-tabular text-2xl font-semibold text-emerald-400">
            {completedJobs.length}
          </div>
        </div>

        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-4 space-y-1">
          <div className="text-xs text-[#94A3B8] flex items-center gap-1.5">
            <XCircle className="w-3.5 h-3.5 text-red-400" />
            <span>Failed / Cancelled</span>
          </div>
          <div className="font-mono-tabular text-2xl font-semibold text-red-400">
            {failedJobs.length}
          </div>
        </div>

        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-4 space-y-1">
          <div className="text-xs text-[#94A3B8] flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-sky-400" />
            <span>Control API</span>
          </div>
          <div
            className={`font-mono-tabular text-sm font-semibold pt-1 ${
              apiStatus === 'connected' ? 'text-emerald-400' : 'text-red-400'
            }`}
          >
            {apiStatus === 'connected' ? 'Connected' : apiStatus}
          </div>
        </div>

        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-4 space-y-1 col-span-2 lg:col-span-1">
          <div className="text-xs text-[#94A3B8] flex items-center gap-1.5">
            <Server className="w-3.5 h-3.5 text-sky-400" />
            <span>Firestore Sync</span>
          </div>
          <div
            className={`font-mono-tabular text-sm font-semibold pt-1 ${
              firestoreStatus === 'connected' ? 'text-emerald-400' : 'text-amber-400'
            }`}
          >
            {firestoreStatus === 'connected' ? 'Connected' : firestoreStatus}
          </div>
        </div>
      </div>

      {/* Active Execution & Lease Detail */}
      <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-amber-400" />
            <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
              Active Worker Execution & Lease Monitor
            </h2>
          </div>
          {primary && (
            <span className="font-mono-tabular text-xs text-[#94A3B8]">
              Worker ID: {primary.workerId}
            </span>
          )}
        </div>

        <div className="grid md:grid-cols-3 gap-4 text-xs">
          <div className="p-3.5 rounded-lg bg-[#0B0F17] border border-[#232D3F] space-y-1">
            <div className="text-[#64748B]">Execution Progress</div>
            <div className="flex items-center justify-between font-mono-tabular text-[#F1F5F9]">
              <span>{activeClaimedJob?.stageMessage ?? 'Awaiting job claim'}</span>
              <span>
                {primary?.currentJobProgress !== null &&
                primary?.currentJobProgress !== undefined
                  ? `${primary.currentJobProgress}%`
                  : '0%'}
              </span>
            </div>
            <div className="h-2 rounded-full bg-[#171F2E] overflow-hidden mt-1.5">
              <div
                className="h-full bg-amber-500 transition-all"
                style={{ width: `${primary?.currentJobProgress ?? 0}%` }}
              />
            </div>
          </div>

          <div className="p-3.5 rounded-lg bg-[#0B0F17] border border-[#232D3F] space-y-1">
            <div className="text-[#64748B]">Lease & Retry Policy</div>
            <div className="font-mono-tabular text-[#CBD5E1]">
              Heartbeat Timeout: 45s · Job Lease: 120s
            </div>
            <div className="text-[11px] text-[#94A3B8]">
              Expired leases automatically re-queue up to maxAttempts (default 3).
            </div>
          </div>

          <div className="p-3.5 rounded-lg bg-[#0B0F17] border border-[#232D3F] space-y-1">
            <div className="text-[#64748B]">Last Worker Diagnostic Error</div>
            <div
              className={`font-mono-tabular break-words ${
                primary?.lastError ? 'text-red-300' : 'text-emerald-400'
              }`}
            >
              {primary?.lastError || 'None reported'}
            </div>
          </div>
        </div>
      </div>

      {/* Registered Worker Nodes */}
      <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5 space-y-4">
        <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
          Registered Worker Nodes
        </h2>
        {workers.length === 0 ? (
          <div className="p-6 rounded-lg bg-[#0B0F17] border border-[#232D3F] text-xs text-[#94A3B8] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <span>
              No Production Workers have registered yet. Existing queued jobs remain safely stored in Firestore & backend queue until your Windows 11 PC connects.
            </span>
            <button
              type="button"
              onClick={onOpenSetup}
              className="px-3 py-1.5 rounded-lg bg-[#171F2E] border border-[#232D3F] text-amber-400 hover:border-amber-500/40 shrink-0 cursor-pointer"
            >
              View Setup Steps
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#232D3F] text-[#94A3B8]">
                  <th className="pb-2.5 pr-4 font-medium">Worker / Machine</th>
                  <th className="pb-2.5 pr-4 font-medium">Version</th>
                  <th className="pb-2.5 pr-4 font-medium">Status</th>
                  <th className="pb-2.5 pr-4 font-medium">Last Heartbeat</th>
                  <th className="pb-2.5 pr-4 font-medium">Current Job ID</th>
                  <th className="pb-2.5 font-medium">Last Error</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#232D3F]/60">
                {workers.map((w) => (
                  <tr key={w.workerId}>
                    <td className="py-3 pr-4">
                      <div className="font-medium text-[#F1F5F9]">{w.name}</div>
                      <div className="font-mono-tabular text-[11px] text-[#64748B]">
                        {w.machineName || w.hostname} · {w.os} · {w.workerId}
                      </div>
                    </td>
                    <td className="py-3 pr-4 font-mono-tabular text-[#CBD5E1]">
                      {w.version ?? '—'}
                    </td>
                    <td className="py-3 pr-4">
                      <WorkerStatusLabel status={w.status} />
                    </td>
                    <td className="py-3 pr-4 font-mono-tabular text-[#94A3B8]">
                      {new Date(w.lastHeartbeat).toLocaleString()} ({formatRelativeAge(w.lastHeartbeat)})
                    </td>
                    <td className="py-3 pr-4 font-mono-tabular text-[#CBD5E1]">
                      {w.currentJobId ?? 'Idle'}
                    </td>
                    <td className="py-3 font-mono-tabular text-red-300 max-w-xs truncate">
                      {w.lastError ?? 'None'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Pending, Completed & Failed Jobs Monitor */}
      <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
            Worker Job Queue & Execution History
          </h2>
          <div className="flex flex-wrap gap-2 text-xs">
            {(
              [
                { id: 'all', label: `All (${jobs.length})` },
                { id: 'pending', label: `Pending / Active (${pendingJobs.length})` },
                { id: 'completed', label: `Completed (${completedJobs.length})` },
                { id: 'failed', label: `Failed (${failedJobs.length})` },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-1.5 rounded-lg font-mono-tabular border transition-colors cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-amber-500/15 border-amber-500/40 text-amber-300'
                    : 'bg-[#0B0F17] border-[#232D3F] text-[#94A3B8] hover:text-[#F1F5F9]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {filteredJobs.length === 0 ? (
          <div className="p-8 text-center text-xs text-[#64748B] bg-[#0B0F17] rounded-lg border border-[#232D3F]">
            No jobs match this filter.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#232D3F] text-[#94A3B8]">
                  <th className="pb-2.5 pr-4 font-medium">Job ID</th>
                  <th className="pb-2.5 pr-4 font-medium">Episode / Task</th>
                  <th className="pb-2.5 pr-4 font-medium">Status</th>
                  <th className="pb-2.5 pr-4 font-medium">Attempts</th>
                  <th className="pb-2.5 pr-4 font-medium">Diagnostics / Error</th>
                  <th className="pb-2.5 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#232D3F]/60">
                {filteredJobs.map((job) => {
                  const isActive = ['queued', 'claimed', 'processing', 'uploading'].includes(
                    job.status,
                  );
                  const canRetry = job.status === 'failed' || job.status === 'cancelled';
                  const busy = busyJobId === job.jobId;

                  return (
                    <tr key={job.jobId}>
                      <td className="py-3 pr-4 font-mono-tabular text-[#CBD5E1] align-top">
                        <div>{job.jobId}</div>
                        <div className="text-[11px] text-[#64748B]">
                          {job.workerId ? `Worker: ${job.workerId}` : 'Unassigned'}
                        </div>
                      </td>
                      <td className="py-3 pr-4 align-top">
                        <div className="font-medium text-[#F1F5F9]">{job.episodeTitle}</div>
                        <div className="font-mono-tabular text-[11px] text-[#94A3B8]">
                          {job.type}
                          {typeof job.sceneNumber === 'number'
                            ? ` · Scene ${job.sceneNumber}`
                            : ''}
                        </div>
                      </td>
                      <td className="py-3 pr-4 align-top">
                        <ProductionStatusLabel status={job.status} />
                        <div className="font-mono-tabular text-[11px] text-[#94A3B8] mt-1">
                          {job.progress}%
                        </div>
                      </td>
                      <td className="py-3 pr-4 font-mono-tabular text-[#CBD5E1] align-top">
                        <div>
                          {job.attemptCount}/{job.maxAttempts}
                        </div>
                        {job.leaseExpiresAt && isActive && (
                          <div className="text-[11px] text-[#64748B]">
                            Lease: {new Date(job.leaseExpiresAt).toLocaleTimeString()}
                          </div>
                        )}
                      </td>
                      <td className="py-3 pr-4 align-top max-w-xs">
                        {job.errorMessage ? (
                          <div className="text-red-300 font-mono-tabular break-words">
                            {job.errorMessage}
                          </div>
                        ) : (
                          <div className="text-[#94A3B8] break-words">
                            {job.stageMessage || '—'}
                          </div>
                        )}
                      </td>
                      <td className="py-3 text-right align-top whitespace-nowrap">
                        <div className="inline-flex items-center gap-2">
                          {canRetry && (
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => void handleRetry(job.jobId)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[#171F2E] border border-amber-500/30 text-amber-300 hover:bg-amber-500/10 disabled:opacity-50 cursor-pointer"
                            >
                              <RotateCcw className="w-3 h-3" />
                              <span>Retry</span>
                            </button>
                          )}
                          {isActive && (
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => void handleCancel(job.jobId)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[#171F2E] border border-red-500/30 text-red-300 hover:bg-red-500/10 disabled:opacity-50 cursor-pointer"
                            >
                              <XCircle className="w-3 h-3" />
                              <span>Cancel</span>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
