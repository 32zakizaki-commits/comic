import { Edit3, FolderPlus, Plus, Trash2 } from 'lucide-react';
import { useState } from 'react';
import type {
  Episode,
  NavSection,
  Project,
  StoryGenre,
  VisualStyle,
} from '../types/studio';
import { ProductionStatusLabel } from './StatusText';

interface ProjectsViewProps {
  projects: Project[];
  episodes: Episode[];
  onCreateProject: (input: {
    title: string;
    description: string;
    visualStyle: VisualStyle;
  }) => Promise<string>;
  onUpdateProject: (
    projectId: string,
    updates: Partial<Pick<Project, 'title' | 'description' | 'visualStyle' | 'status'>>,
  ) => Promise<void>;
  onDeleteProject: (projectId: string) => Promise<void>;
  onCreateEpisode: (input: {
    projectId: string;
    title: string;
    genre: StoryGenre;
  }) => Promise<string>;
  onDeleteEpisode: (episodeId: string) => Promise<void>;
  onOpenEpisode: (section: NavSection, episodeId: string) => void;
}

const VISUAL_STYLES: VisualStyle[] = [
  'Motion Comic',
  'Seinen Ink',
  'Watercolor Anime',
  'Noir Manga',
];

const GENRES: StoryGenre[] = [
  'Drama',
  'Business',
  'Revenge',
  'Mystery',
  'Romance',
  'Historical',
  'Psychological',
  'Thriller',
  'Inspirational',
];

export function ProjectsView({
  projects,
  episodes,
  onCreateProject,
  onUpdateProject,
  onDeleteProject,
  onCreateEpisode,
  onDeleteEpisode,
  onOpenEpisode,
}: ProjectsViewProps) {
  const [showProjectForm, setShowProjectForm] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [visualStyle, setVisualStyle] = useState<VisualStyle>('Motion Comic');
  const [projectStatus, setProjectStatus] = useState<'active' | 'archived' | 'completed'>('active');
  const [saving, setSaving] = useState(false);

  const [confirmDeleteProject, setConfirmDeleteProject] = useState<Project | null>(null);
  const [episodeProjectId, setEpisodeProjectId] = useState<string | null>(null);
  const [epTitle, setEpTitle] = useState('');
  const [epGenre, setEpGenre] = useState<StoryGenre>('Drama');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const openCreateModal = () => {
    setEditingProject(null);
    setTitle('');
    setDescription('');
    setVisualStyle('Motion Comic');
    setProjectStatus('active');
    setErrorMsg(null);
    setShowProjectForm(true);
  };

  const openEditModal = (proj: Project) => {
    setEditingProject(proj);
    setTitle(proj.title);
    setDescription(proj.description);
    setVisualStyle(proj.visualStyle);
    setProjectStatus(proj.status);
    setErrorMsg(null);
    setShowProjectForm(true);
  };

  const handleSaveProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMsg('Project title is required.');
      return;
    }
    setSaving(true);
    setErrorMsg(null);
    try {
      if (editingProject) {
        await onUpdateProject(editingProject.projectId, {
          title: title.trim(),
          description: description.trim(),
          visualStyle,
          status: projectStatus,
        });
      } else {
        await onCreateProject({
          title: title.trim(),
          description: description.trim(),
          visualStyle,
        });
      }
      setShowProjectForm(false);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to save project.');
    } finally {
      setSaving(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!confirmDeleteProject) return;
    setSaving(true);
    try {
      await onDeleteProject(confirmDeleteProject.projectId);
      setConfirmDeleteProject(null);
    } finally {
      setSaving(false);
    }
  };

  const handleCreateEpisode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!episodeProjectId || !epTitle.trim()) return;
    setSaving(true);
    try {
      const epId = await onCreateEpisode({
        projectId: episodeProjectId,
        title: epTitle.trim(),
        genre: epGenre,
      });
      setEpisodeProjectId(null);
      setEpTitle('');
      onOpenEpisode('story-studio', epId);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">Projects</h1>
          <p className="text-sm text-[#94A3B8] mt-1">
            Organize Japanese Motion Comic series and manage episodes inside each project.
          </p>
        </div>
        <button
          type="button"
          onClick={openCreateModal}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <FolderPlus className="w-4 h-4" />
          <span>New Project</span>
        </button>
      </div>

      {projects.length === 0 ? (
        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-12 text-center space-y-4">
          <h2 className="font-display text-lg font-medium text-[#F1F5F9]">No Projects Yet</h2>
          <p className="text-sm text-[#94A3B8] max-w-md mx-auto">
            Create your first Japanese Motion Comic series to define recurring characters, generate scripts, and queue renders.
          </p>
          <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create First Project</span>
          </button>
        </div>
      ) : (
        <div className="space-y-5">
          {projects.map((proj) => {
            const projEpisodes = episodes.filter((e) => e.projectId === proj.projectId);
            return (
              <div
                key={proj.projectId}
                className="bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-5"
              >
                <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-[#94A3B8]">
                      <span>Language: Japanese (ja)</span>
                      <span aria-hidden="true">·</span>
                      <span>Style: {proj.visualStyle}</span>
                      <span aria-hidden="true">·</span>
                      <span className="capitalize">Status: {proj.status}</span>
                    </div>
                    <h2 className="font-display text-xl font-semibold text-[#F1F5F9]">
                      {proj.title}
                    </h2>
                    {proj.description && (
                      <p className="text-sm text-[#94A3B8] max-w-3xl leading-relaxed">
                        {proj.description}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        setEpisodeProjectId(proj.projectId);
                        setEpTitle('');
                        setEpGenre('Drama');
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#171F2E] border border-[#232D3F] text-xs font-medium text-amber-400 hover:border-amber-500/40 whitespace-nowrap cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Episode</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => openEditModal(proj)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#171F2E] border border-[#232D3F] text-xs font-medium text-[#F1F5F9] hover:border-slate-500 cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteProject(proj)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#171F2E] border border-[#232D3F] text-xs font-medium text-red-400 hover:border-red-500/40 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>

                {/* Episodes Table Inside Project */}
                <div className="border-t border-[#232D3F] pt-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-xs font-semibold text-[#94A3B8]">
                      Episodes ({projEpisodes.length})
                    </h3>
                  </div>
                  {projEpisodes.length === 0 ? (
                    <p className="text-xs text-[#64748B] py-2">
                      No episodes in this project yet.
                    </p>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-[#232D3F] text-[#94A3B8]">
                            <th className="pb-2 font-medium">Title</th>
                            <th className="pb-2 font-medium">Genre</th>
                            <th className="pb-2 font-medium">Scenes</th>
                            <th className="pb-2 font-medium">Status</th>
                            <th className="pb-2 font-medium text-right">Workflow</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#232D3F]/60">
                          {projEpisodes.map((ep) => (
                            <tr key={ep.episodeId} className="hover:bg-[#171F2E]/40">
                              <td className="py-2.5 pr-4 font-medium text-[#F1F5F9]">
                                {ep.title}
                                {ep.japaneseTitle ? ` (${ep.japaneseTitle})` : ''}
                              </td>
                              <td className="py-2.5 pr-4 text-[#94A3B8]">{ep.genre}</td>
                              <td className="py-2.5 pr-4 font-mono-tabular text-[#F1F5F9]">
                                {ep.scenes?.length ?? 0}
                              </td>
                              <td className="py-2.5 pr-4">
                                <ProductionStatusLabel status={ep.status} />
                              </td>
                              <td className="py-2.5 text-right space-x-3 whitespace-nowrap">
                                <button
                                  type="button"
                                  onClick={() => onOpenEpisode('story-studio', ep.episodeId)}
                                  className="text-amber-400 hover:text-amber-300 font-medium cursor-pointer"
                                >
                                  Story
                                </button>
                                <button
                                  type="button"
                                  onClick={() => onOpenEpisode('scenes', ep.episodeId)}
                                  className="text-amber-400 hover:text-amber-300 font-medium cursor-pointer"
                                >
                                  Scenes
                                </button>
                                <button
                                  type="button"
                                  onClick={() => onOpenEpisode('video-composer', ep.episodeId)}
                                  className="text-amber-400 hover:text-amber-300 font-medium cursor-pointer"
                                >
                                  Video
                                </button>
                                <button
                                  type="button"
                                  onClick={() => void onDeleteEpisode(ep.episodeId)}
                                  className="text-red-400 hover:text-red-300 cursor-pointer"
                                >
                                  Remove
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create/Edit Project Modal */}
      {showProjectForm && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-5">
            <h3 className="font-display text-lg font-semibold text-[#F1F5F9]">
              {editingProject ? 'Edit Project' : 'Create Project'}
            </h3>
            <form onSubmit={(e) => void handleSaveProject(e)} className="space-y-4">
              {errorMsg && (
                <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">
                  {errorMsg}
                </div>
              )}
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-[#94A3B8]">Project Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g., Tokyo Dusk Chronicles"
                  className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9] focus:outline-none focus:border-amber-500"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-[#94A3B8]">Language</label>
                  <input
                    type="text"
                    readOnly
                    value="Japanese (ja)"
                    className="w-full bg-[#0B0F17]/60 border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#94A3B8]"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-[#94A3B8]">Visual Style</label>
                  <select
                    value={visualStyle}
                    onChange={(e) => setVisualStyle(e.target.value as VisualStyle)}
                    className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9] focus:outline-none focus:border-amber-500"
                  >
                    {VISUAL_STYLES.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              {editingProject && (
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-[#94A3B8]">Project Status</label>
                  <select
                    value={projectStatus}
                    onChange={(e) =>
                      setProjectStatus(e.target.value as 'active' | 'archived' | 'completed')
                    }
                    className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
                  >
                    <option value="active">Active</option>
                    <option value="completed">Completed</option>
                    <option value="archived">Archived</option>
                  </select>
                </div>
              )}
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-[#94A3B8]">Series Description</label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe the world, narrative arc, and visual tone..."
                  className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9] focus:outline-none focus:border-amber-500"
                />
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowProjectForm(false)}
                  className="px-4 py-2 text-sm text-[#94A3B8] hover:text-[#F1F5F9] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 disabled:opacity-60 cursor-pointer"
                >
                  {saving ? 'Saving...' : editingProject ? 'Save Changes' : 'Create Project'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Project Confirmation Modal */}
      {confirmDeleteProject && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#121824] border border-red-500/30 rounded-xl p-6 space-y-4">
            <h3 className="font-display text-lg font-semibold text-[#F1F5F9]">
              Delete Project?
            </h3>
            <p className="text-sm text-[#94A3B8]">
              Deleting <strong className="text-[#F1F5F9]">{confirmDeleteProject.title}</strong> will permanently remove the project and all linked characters and episodes. This cannot be undone.
            </p>
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setConfirmDeleteProject(null)}
                className="px-4 py-2 text-sm text-[#94A3B8] hover:text-[#F1F5F9] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={saving}
                onClick={() => void handleConfirmDelete()}
                className="px-4 py-2 rounded-lg bg-red-600 text-white font-semibold text-sm hover:bg-red-500 disabled:opacity-60 cursor-pointer"
              >
                {saving ? 'Deleting...' : 'Delete Permanently'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Episode Modal */}
      {episodeProjectId && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-4">
            <h3 className="font-display text-lg font-semibold text-[#F1F5F9]">
              Add Episode to Project
            </h3>
            <form onSubmit={(e) => void handleCreateEpisode(e)} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-[#94A3B8]">Episode Title</label>
                <input
                  type="text"
                  required
                  value={epTitle}
                  onChange={(e) => setEpTitle(e.target.value)}
                  placeholder="Episode 01 — Silent Ledger"
                  className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-[#94A3B8]">Genre</label>
                <select
                  value={epGenre}
                  onChange={(e) => setEpGenre(e.target.value as StoryGenre)}
                  className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
                >
                  {GENRES.map((g) => (
                    <option key={g} value={g}>
                      {g}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setEpisodeProjectId(null)}
                  className="px-4 py-2 text-sm text-[#94A3B8] hover:text-[#F1F5F9] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 cursor-pointer"
                >
                  {saving ? 'Creating...' : 'Create Episode'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
