import {
  Activity,
  BookOpen,
  CheckSquare,
  Clapperboard,
  FolderKanban,
  Image,
  LayoutDashboard,
  ListOrdered,
  LogOut,
  Mic,
  Settings,
  Users,
  Wrench,
  Youtube,
  X,
} from 'lucide-react';
import type { NavSection, WorkerStatus } from '../types/studio';
import { WorkerStatusLabel } from './StatusText';

interface SidebarProps {
  activeSection: NavSection;
  onSelect: (section: NavSection) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  workerStatus: WorkerStatus;
  pendingApprovalsCount: number;
  queuedJobsCount: number;
  userDisplayName: string;
  userEmail: string | null;
  onSignOut: () => void;
}

const NAV_ITEMS: Array<{
  id: NavSection;
  label: string;
  Icon: typeof LayoutDashboard;
  group: string;
}> = [
  { id: 'dashboard', label: 'Dashboard', Icon: LayoutDashboard, group: 'Studio' },
  { id: 'projects', label: 'Projects', Icon: FolderKanban, group: 'Studio' },
  { id: 'story-studio', label: 'Story Studio', Icon: BookOpen, group: 'Pre-Production' },
  { id: 'characters', label: 'Character Manager', Icon: Users, group: 'Pre-Production' },
  { id: 'scenes', label: 'Scene Generator', Icon: Image, group: 'Production' },
  { id: 'voice-studio', label: 'Voice Studio', Icon: Mic, group: 'Production' },
  { id: 'video-composer', label: 'Video Composer', Icon: Clapperboard, group: 'Production' },
  { id: 'production-queue', label: 'Production Queue', Icon: ListOrdered, group: 'Operations' },
  { id: 'approval-center', label: 'Approval Center', Icon: CheckSquare, group: 'Operations' },
  { id: 'worker-monitor', label: 'Worker Monitor', Icon: Activity, group: 'Operations' },
  { id: 'worker-setup', label: 'Worker Setup', Icon: Wrench, group: 'Operations' },
  { id: 'youtube-publishing', label: 'YouTube Publishing', Icon: Youtube, group: 'Release' },
  { id: 'settings', label: 'Settings', Icon: Settings, group: 'Release' },
];

export function Sidebar({
  activeSection,
  onSelect,
  mobileOpen,
  onCloseMobile,
  workerStatus,
  pendingApprovalsCount,
  queuedJobsCount,
  userDisplayName,
  userEmail,
  onSignOut,
}: SidebarProps) {
  const groups = ['Studio', 'Pre-Production', 'Production', 'Operations', 'Release'];

  const navContent = (
    <div className="flex flex-col h-full bg-[#0E131D] border-r border-[#232D3F]">
      {/* Brand Header */}
      <div className="h-16 px-5 flex items-center justify-between border-b border-[#232D3F] shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-md bg-amber-500 text-slate-950 flex items-center justify-center font-display font-bold text-sm shrink-0">
            JC
          </div>
          <span className="font-display font-semibold text-base tracking-tight text-[#F1F5F9] truncate">
            JapanComic Studio
          </span>
        </div>
        <button
          type="button"
          onClick={onCloseMobile}
          aria-label="Close navigation"
          className="lg:hidden p-1.5 rounded-md text-[#94A3B8] hover:text-[#F1F5F9] hover:bg-[#171F2E]"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-5">
        {groups.map((groupName) => {
          const items = NAV_ITEMS.filter((i) => i.group === groupName);
          return (
            <div key={groupName} className="space-y-1">
              <div className="px-3 pb-1 text-[11px] font-medium text-[#64748B]">
                {groupName}
              </div>
              {items.map((item) => {
                const Icon = item.Icon;
                const active = activeSection === item.id;
                const count =
                  item.id === 'approval-center' && pendingApprovalsCount > 0
                    ? pendingApprovalsCount
                    : item.id === 'production-queue' && queuedJobsCount > 0
                      ? queuedJobsCount
                      : null;

                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      onSelect(item.id);
                      onCloseMobile();
                    }}
                    className={`w-full flex items-center justify-between gap-2 px-3 py-2 rounded-lg text-sm transition-colors cursor-pointer ${
                      active
                        ? 'bg-amber-500/12 text-amber-400 font-medium'
                        : 'text-[#94A3B8] hover:text-[#F1F5F9] hover:bg-[#151C28]'
                    }`}
                  >
                    <span className="flex items-center gap-2.5 min-w-0">
                      <Icon className="w-4 h-4 shrink-0" />
                      <span className="truncate whitespace-nowrap">{item.label}</span>
                    </span>
                    {count !== null && (
                      <span className="font-mono-tabular text-xs text-amber-400 shrink-0">
                        {count}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          );
        })}
      </nav>

      {/* Worker Summary + Account Footer */}
      <div className="p-4 border-t border-[#232D3F] space-y-3 shrink-0 bg-[#0B0F17]/60">
        <div className="flex items-center justify-between text-xs">
          <span className="text-[#94A3B8]">Local Worker</span>
          <WorkerStatusLabel status={workerStatus} />
        </div>
        <div className="flex items-center justify-between gap-2 pt-2 border-t border-[#232D3F]/80">
          <div className="min-w-0">
            <div className="text-xs font-medium text-[#F1F5F9] truncate">{userDisplayName}</div>
            {userEmail && <div className="text-[11px] text-[#64748B] truncate">{userEmail}</div>}
          </div>
          <button
            type="button"
            onClick={onSignOut}
            title="Sign out"
            className="p-1.5 rounded-md text-[#94A3B8] hover:text-[#F1F5F9] hover:bg-[#171F2E] transition-colors shrink-0 cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden lg:block w-64 shrink-0 h-screen sticky top-0">
        {navContent}
      </aside>
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div className="w-64 h-full">{navContent}</div>
          <div
            className="flex-1 bg-black/60"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
        </div>
      )}
    </>
  );
}
