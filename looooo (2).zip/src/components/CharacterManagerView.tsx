import { Plus, Trash2, Upload, UserCheck } from 'lucide-react';
import { useState } from 'react';
import type { Character, Project } from '../types/studio';

interface CharacterManagerViewProps {
  projects: Project[];
  characters: Character[];
  onSaveCharacter: (
    input: Omit<Character, 'userId' | 'createdAt' | 'updatedAt'>,
    isNew: boolean,
  ) => Promise<string>;
  onDeleteCharacter: (characterId: string) => Promise<void>;
  onUploadReferenceImage: (
    projectId: string,
    characterId: string,
    file: File,
  ) => Promise<string>;
}

export function CharacterManagerView({
  projects,
  characters,
  onSaveCharacter,
  onDeleteCharacter,
  onUploadReferenceImage,
}: CharacterManagerViewProps) {
  const [selectedProjectId, setSelectedProjectId] = useState(projects[0]?.projectId ?? '');
  const [editingChar, setEditingChar] = useState<Character | null>(null);
  const [showForm, setShowForm] = useState(false);

  const [name, setName] = useState('');
  const [ageDescription, setAgeDescription] = useState('');
  const [personality, setPersonality] = useState('');
  const [appearance, setAppearance] = useState('');
  const [clothing, setClothing] = useState('');
  const [referenceImages, setReferenceImages] = useState<string[]>([]);
  const [comfyLoraTag, setComfyLoraTag] = useState('');
  const [ipAdapterWeight, setIpAdapterWeight] = useState<number>(0.75);
  const [voiceId, setVoiceId] = useState('pNInz6obpgDQGcFmaJgB');
  const [stability, setStability] = useState(0.55);
  const [similarityBoost, setSimilarityBoost] = useState(0.78);
  const [voiceDirection, setVoiceDirection] = useState('Measured Japanese dramatic tone');

  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const filteredChars = characters.filter(
    (c) => !selectedProjectId || c.projectId === selectedProjectId,
  );

  const openNew = () => {
    const pid = selectedProjectId || projects[0]?.projectId || '';
    setSelectedProjectId(pid);
    setEditingChar(null);
    setName('');
    setAgeDescription('');
    setPersonality('');
    setAppearance('');
    setClothing('');
    setReferenceImages([]);
    setComfyLoraTag('');
    setIpAdapterWeight(0.75);
    setVoiceId('pNInz6obpgDQGcFmaJgB');
    setStability(0.55);
    setSimilarityBoost(0.78);
    setVoiceDirection('Measured Japanese dramatic tone');
    setErrorMsg(null);
    setShowForm(true);
  };

  const openEdit = (c: Character) => {
    setEditingChar(c);
    setSelectedProjectId(c.projectId);
    setName(c.name);
    setAgeDescription(c.ageDescription);
    setPersonality(c.personality);
    setAppearance(c.appearance);
    setClothing(c.clothing);
    setReferenceImages(c.referenceImages ?? []);
    setComfyLoraTag(c.comfyLoraTag ?? '');
    setIpAdapterWeight(c.ipAdapterWeight ?? 0.75);
    setVoiceId(c.voiceId);
    setStability(c.voiceSettings?.stability ?? 0.55);
    setSimilarityBoost(c.voiceSettings?.similarityBoost ?? 0.78);
    setVoiceDirection(c.voiceSettings?.voiceDirection ?? '');
    setErrorMsg(null);
    setShowForm(true);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (referenceImages.length >= 5) {
      setErrorMsg('Maximum 5 reference images per character.');
      return;
    }
    const pid = selectedProjectId || projects[0]?.projectId;
    if (!pid) {
      setErrorMsg('Select a project first.');
      return;
    }
    setUploading(true);
    setErrorMsg(null);
    try {
      const charId = editingChar?.characterId || `chr_${Date.now().toString(36)}`;
      const url = await onUploadReferenceImage(pid, charId, file);
      setReferenceImages((prev) => [...prev, url]);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Reference image upload failed.');
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const pid = selectedProjectId || projects[0]?.projectId;
    if (!pid) {
      setErrorMsg('Create a project first.');
      return;
    }
    if (!name.trim()) {
      setErrorMsg('Character name is required.');
      return;
    }
    setSaving(true);
    setErrorMsg(null);
    try {
      await onSaveCharacter(
        {
          characterId: editingChar?.characterId ?? `chr_${Date.now().toString(36)}`,
          projectId: pid,
          name: name.trim(),
          ageDescription: ageDescription.trim(),
          personality: personality.trim(),
          appearance: appearance.trim(),
          clothing: clothing.trim(),
          referenceImages,
          comfyLoraTag: comfyLoraTag.trim(),
          ipAdapterWeight,
          voiceId: voiceId.trim() || 'pNInz6obpgDQGcFmaJgB',
          voiceSettings: {
            stability,
            similarityBoost,
            style: 0.25,
            speakingRate: 1.0,
            voiceDirection: voiceDirection.trim(),
          },
        },
        !editingChar,
      );
      setShowForm(false);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to save character.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">
            Character Manager
          </h1>
          <p className="text-sm text-[#94A3B8] mt-1">
            Maintain consistent Japanese character designs, ElevenLabs voice profiles, and ComfyUI IPAdapter / LoRA hooks.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={selectedProjectId}
            onChange={(e) => setSelectedProjectId(e.target.value)}
            className="bg-[#121824] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
          >
            <option value="">All Projects</option>
            {projects.map((p) => (
              <option key={p.projectId} value={p.projectId}>
                {p.title}
              </option>
            ))}
          </select>
          <button
            type="button"
            disabled={projects.length === 0}
            onClick={openNew}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 disabled:opacity-60 whitespace-nowrap cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>New Character</span>
          </button>
        </div>
      </div>

      {filteredChars.length === 0 ? (
        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-12 text-center space-y-3">
          <p className="text-sm text-[#94A3B8]">
            No characters defined yet. Add characters so Story Studio and ComfyUI preserve appearance across scenes.
          </p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
          {filteredChars.map((ch) => {
            const proj = projects.find((p) => p.projectId === ch.projectId);
            return (
              <div
                key={ch.characterId}
                className="bg-[#121824] border border-[#232D3F] rounded-xl p-5 flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="text-xs text-[#94A3B8]">
                        {proj?.title ?? 'Project'} · {ch.ageDescription || 'Unspecified age'}
                      </div>
                      <h2 className="font-display text-lg font-semibold text-[#F1F5F9] mt-0.5">
                        {ch.name}
                      </h2>
                    </div>
                    <UserCheck className="w-4 h-4 text-amber-400 shrink-0" />
                  </div>

                  {ch.referenceImages?.length > 0 && (
                    <div className="flex items-center gap-2 overflow-x-auto pb-1">
                      {ch.referenceImages.map((url, idx) => (
                        <img
                          key={idx}
                          src={url}
                          alt={`${ch.name} reference ${idx + 1}`}
                          referrerPolicy="no-referrer"
                          className="w-16 h-16 rounded-lg object-cover border border-[#232D3F] shrink-0"
                        />
                      ))}
                    </div>
                  )}

                  <div className="space-y-1.5 text-xs text-[#CBD5E1]">
                    <p>
                      <span className="text-[#64748B]">Appearance:</span> {ch.appearance}
                    </p>
                    <p>
                      <span className="text-[#64748B]">Clothing:</span> {ch.clothing}
                    </p>
                    <p>
                      <span className="text-[#64748B]">Personality:</span> {ch.personality}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-[#232D3F] text-[11px] font-mono-tabular text-[#94A3B8] space-y-1">
                    <div>Voice ID: {ch.voiceId}</div>
                    <div>
                      ComfyUI IPAdapter: {ch.ipAdapterWeight ?? 0.75}
                      {ch.comfyLoraTag ? ` · LoRA: ${ch.comfyLoraTag}` : ''}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-3 pt-2 border-t border-[#232D3F]">
                  <button
                    type="button"
                    onClick={() => openEdit(ch)}
                    className="text-xs font-medium text-amber-400 hover:text-amber-300 cursor-pointer"
                  >
                    Edit Sheet
                  </button>
                  <button
                    type="button"
                    onClick={() => void onDeleteCharacter(ch.characterId)}
                    className="inline-flex items-center gap-1 text-xs text-red-400 hover:text-red-300 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-2xl bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-4 my-8">
            <h3 className="font-display text-lg font-semibold text-[#F1F5F9]">
              {editingChar ? 'Edit Character Sheet' : 'New Character Sheet'}
            </h3>
            <form onSubmit={(e) => void handleSave(e)} className="space-y-4">
              {errorMsg && (
                <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">
                  {errorMsg}
                </div>
              )}

              <div className="grid sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-xs text-[#94A3B8]">Project</label>
                  <select
                    disabled={Boolean(editingChar)}
                    value={selectedProjectId}
                    onChange={(e) => setSelectedProjectId(e.target.value)}
                    className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
                  >
                    {projects.map((p) => (
                      <option key={p.projectId} value={p.projectId}>
                        {p.title}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-[#94A3B8]">Character Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g., Renji Takahashi"
                    className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-[#94A3B8]">Age Description</label>
                  <input
                    type="text"
                    value={ageDescription}
                    onChange={(e) => setAgeDescription(e.target.value)}
                    placeholder="Late 30s"
                    className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs text-[#94A3B8]">Appearance (ComfyUI Prompt Anchor)</label>
                  <textarea
                    rows={3}
                    value={appearance}
                    onChange={(e) => setAppearance(e.target.value)}
                    placeholder="Sharp dark eyes, tousled black hair, faint scar on left brow..."
                    className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-[#94A3B8]">Clothing</label>
                  <textarea
                    rows={3}
                    value={clothing}
                    onChange={(e) => setClothing(e.target.value)}
                    placeholder="Charcoal wool trench coat over dark turtleneck..."
                    className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs text-[#94A3B8]">Personality & Speech Manner</label>
                <input
                  type="text"
                  value={personality}
                  onChange={(e) => setPersonality(e.target.value)}
                  placeholder="Stoic, observant, speaks in terse formal Japanese..."
                  className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
                />
              </div>

              {/* ComfyUI IPAdapter / LoRA + Voice Settings */}
              <div className="grid sm:grid-cols-3 gap-3 pt-2 border-t border-[#232D3F]">
                <div className="space-y-1">
                  <label className="text-xs text-[#94A3B8]">ComfyUI LoRA Tag (Future Hook)</label>
                  <input
                    type="text"
                    value={comfyLoraTag}
                    onChange={(e) => setComfyLoraTag(e.target.value)}
                    placeholder="<lora:seinen_char:0.8>"
                    className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-xs font-mono-tabular text-[#F1F5F9]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-[#94A3B8]">IPAdapter Weight</label>
                  <input
                    type="number"
                    step="0.05"
                    min="0"
                    max="2"
                    value={ipAdapterWeight}
                    onChange={(e) => setIpAdapterWeight(Number(e.target.value))}
                    className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-xs font-mono-tabular text-[#F1F5F9]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-[#94A3B8]">ElevenLabs Voice ID</label>
                  <input
                    type="text"
                    value={voiceId}
                    onChange={(e) => setVoiceId(e.target.value)}
                    className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-xs font-mono-tabular text-[#F1F5F9]"
                  />
                </div>
              </div>

              {/* Reference Image Upload */}
              <div className="space-y-2 pt-2 border-t border-[#232D3F]">
                <div className="flex items-center justify-between">
                  <label className="text-xs text-[#94A3B8]">
                    Reference Images ({referenceImages.length}/5)
                  </label>
                  <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#171F2E] border border-[#232D3F] text-xs font-medium text-amber-400 hover:border-amber-500/40 cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{uploading ? 'Uploading...' : 'Upload Image'}</span>
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      disabled={uploading}
                      onChange={(e) => void handleFileUpload(e)}
                      className="hidden"
                    />
                  </label>
                </div>
                {referenceImages.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {referenceImages.map((url, idx) => (
                      <div key={idx} className="relative group">
                        <img
                          src={url}
                          alt={`Reference ${idx + 1}`}
                          referrerPolicy="no-referrer"
                          className="w-16 h-16 rounded-lg object-cover border border-[#232D3F]"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            setReferenceImages((prev) => prev.filter((_, i) => i !== idx))
                          }
                          className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-red-600 text-white text-[10px] flex items-center justify-center cursor-pointer"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="px-4 py-2 text-sm text-[#94A3B8] hover:text-[#F1F5F9] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 cursor-pointer"
                >
                  {saving ? 'Saving...' : 'Save Character'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
