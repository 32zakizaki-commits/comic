import { RotateCcw, XCircle } from 'lucide-react';
import { useState } from 'react';
import type { ProductionJob, ProductionStatus } from '../types/studio';
import { ProductionStatusLabel } from './StatusText';

interface ProductionQueueViewProps {
  jobs: ProductionJob[];
  onCancelJob: (jobId: string) => Promise<void>;
  onRetryJob: (jobId: string) => Promise<void>;
}

const FILTERS: Array<{ id: 'all' | ProductionStatus; label: string }> = [
  { id: 'all', label: 'All' },
  { id: 'queued', label: 'Queued' },
  { id: 'processing', label: 'Processing' },
  { id: 'pending_approval', label: 'Pending Approval' },
  { id: 'completed', label: 'Completed' },
  { id: 'failed', label: 'Failed' },
];

export function ProductionQueueView({
  jobs,
  onCancelJob,
  onRetryJob,
}: ProductionQueueViewProps) {
  const [filter, setFilter] = useState<'all' | ProductionStatus>('all');
  const [expandedJobId, setExpandedJobId] = useState<string | null>(null);

  const visibleJobs =
    filter === 'all' ? jobs : jobs.filter((j) => j.status === filter);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">
            Production Queue
          </h1>
          <p className="text-sm text-[#94A3B8] mt-1">
            Atomic worker job queue with lease monitoring, automatic timeout recovery, and retry tracking.
          </p>
        </div>

        {/* Interactive Filter Tabs */}
        <div className="flex flex-wrap items-center gap-1 p-1 bg-[#121824] border border-[#232D3F] rounded-lg">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setFilter(f.id)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                filter === f.id
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-[#94A3B8] hover:text-[#F1F5F9]'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {visibleJobs.length === 0 ? (
        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-12 text-center space-y-2">
          <p className="text-sm text-[#94A3B8]">No jobs match the selected filter.</p>
          <p className="text-xs text-[#64748B]">
            Jobs dispatched from Scene Generator or Video Composer appear here with live worker progress.
          </p>
        </div>
      ) : (
        <div className="bg-[#121824] border border-[#232D3F] rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#232D3F] bg-[#0E131D] text-[#94A3B8]">
                  <th className="py-3 px-4 font-medium">Job ID</th>
                  <th className="py-3 px-4 font-medium">Episode / Target</th>
                  <th className="py-3 px-4 font-medium">Type</th>
                  <th className="py-3 px-4 font-medium">Status</th>
                  <th className="py-3 px-4 font-medium">Progress</th>
                  <th className="py-3 px-4 font-medium">Attempts</th>
                  <th className="py-3 px-4 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#232D3F]/60">
                {visibleJobs.map((job) => {
                  const expanded = expandedJobId === job.jobId;
                  return (
                    <>
                      <tr
                        key={job.jobId}
                        onClick={() =>
                          setExpandedJobId(expanded ? null : job.jobId)
                        }
                        className="hover:bg-[#171F2E]/60 cursor-pointer"
                      >
                        <td className="py-3 px-4 font-mono-tabular text-[#94A3B8]">
                          {job.jobId}
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-medium text-[#F1F5F9]">
                            {job.episodeTitle}
                            {typeof job.sceneNumber === 'number'
                              ? ` · Scene ${job.sceneNumber}`
                              : ''}
                          </div>
                          {job.stageMessage && (
                            <div className="text-[11px] text-[#64748B] truncate max-w-xs">
                              {job.stageMessage}
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-4 font-mono-tabular text-[#CBD5E1]">
                          {job.type}
                        </td>
                        <td className="py-3 px-4">
                          <ProductionStatusLabel status={job.status} />
                        </td>
                        <td className="py-3 px-4 w-36">
                          <div className="flex items-center gap-2">
                            <div className="flex-1 h-1.5 rounded-full bg-[#0B0F17] overflow-hidden">
                              <div
                                className="h-full bg-amber-500 transition-all"
                                style={{ width: `${job.progress}%` }}
                              />
                            </div>
                            <span className="font-mono-tabular text-[#F1F5F9] w-8 text-right">
                              {job.progress}%
                            </span>
                          </div>
                        </td>
                        <td className="py-3 px-4 font-mono-tabular text-[#94A3B8]">
                          {job.attemptCount}/{job.maxAttempts}
                        </td>
                        <td
                          className="py-3 px-4 text-right space-x-2 whitespace-nowrap"
                          onClick={(e) => e.stopPropagation()}
                        >
                          {(job.status === 'failed' || job.status === 'cancelled') && (
                            <button
                              type="button"
                              onClick={() => void onRetryJob(job.jobId)}
                              className="inline-flex items-center gap-1 text-amber-400 hover:text-amber-300 cursor-pointer"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                              <span>Retry</span>
                            </button>
                          )}
                          {['queued', 'claimed', 'processing', 'uploading'].includes(
                            job.status,
                          ) && (
                            <button
                              type="button"
                              onClick={() => void onCancelJob(job.jobId)}
                              className="inline-flex items-center gap-1 text-red-400 hover:text-red-300 cursor-pointer"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              <span>Cancel</span>
                            </button>
                          )}
                        </td>
                      </tr>
                      {expanded && (
                        <tr key={`${job.jobId}_details`} className="bg-[#0B0F17]">
                          <td colSpan={7} className="p-4 space-y-2">
                            <div className="flex flex-wrap gap-x-6 gap-y-1 text-[11px] font-mono-tabular text-[#94A3B8]">
                              <span>Worker: {job.workerId ?? 'Unassigned'}</span>
                              <span>
                                Lease Expires:{' '}
                                {job.leaseExpiresAt
                                  ? new Date(job.leaseExpiresAt).toLocaleTimeString()
                                  : 'N/A'}
                              </span>
                              <span>Created: {new Date(job.createdAt).toLocaleString()}</span>
                            </div>
                            {job.errorMessage && (
                              <div className="p-2.5 rounded bg-red-500/10 border border-red-500/30 text-xs text-red-300">
                                Error: {job.errorMessage}
                              </div>
                            )}
                            <div className="space-y-1 pt-1">
                              <div className="text-[11px] font-medium text-[#94A3B8]">
                                Transition History
                              </div>
                              {job.history.map((h, i) => (
                                <div
                                  key={i}
                                  className="text-[11px] font-mono-tabular text-[#CBD5E1]"
                                >
                                  [{new Date(h.timestamp).toLocaleTimeString()}] {h.status} —{' '}
                                  {h.message}
                                </div>
                              ))}
                            </div>
                          </td>
                        </tr>
                      )}
                    </>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
