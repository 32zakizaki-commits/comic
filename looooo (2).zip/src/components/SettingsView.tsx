import { CheckCircle2, Save, Shield, XCircle } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { IntegrationStatus, StudioSettings } from '../types/studio';

interface SettingsViewProps {
  integrations: IntegrationStatus | null;
  settings: StudioSettings | null;
  onSaveSettings: (next: Omit<StudioSettings, 'userId' | 'updatedAt'>) => Promise<void>;
}

export function SettingsView({
  integrations,
  settings,
  onSaveSettings,
}: SettingsViewProps) {
  const [comfyuiUrl, setComfyuiUrl] = useState(
    settings?.comfyuiUrl ?? 'http://127.0.0.1:8188',
  );
  const [defaultVoiceDirection, setDefaultVoiceDirection] = useState(
    settings?.defaultVoiceDirection ??
      'Deep professional Japanese male narrator, calm documentary pacing',
  );
  const [storagePrefix, setStoragePrefix] = useState(
    settings?.storagePrefix ?? 'japancomic-studio/renders',
  );
  const [saving, setSaving] = useState(false);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  useEffect(() => {
    if (settings) {
      setComfyuiUrl(settings.comfyuiUrl);
      setDefaultVoiceDirection(settings.defaultVoiceDirection ?? '');
      setStoragePrefix(settings.storagePrefix ?? '');
    }
  }, [settings]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSavedNotice(null);
    try {
      await onSaveSettings({
        comfyuiUrl: comfyuiUrl.trim() || 'http://127.0.0.1:8188',
        defaultVoiceDirection: defaultVoiceDirection.trim(),
        videoResolution: '1920x1080',
        videoFps: 30,
        videoFormat: 'mp4',
        videoCodec: 'H.264',
        audioCodec: 'AAC',
        aspectRatio: '16:9',
        storagePrefix: storagePrefix.trim(),
      });
      setSavedNotice('Studio pipeline preferences saved to Cloud Firestore.');
    } finally {
      setSaving(false);
    }
  };

  const integrationRows = [
    {
      name: 'Gemini API (Story & Scene Planner)',
      configured: integrations?.geminiConfigured ?? false,
      secretVar: 'GEMINI_API_KEY',
    },
    {
      name: 'ElevenLabs API (Japanese TTS)',
      configured: integrations?.elevenlabsConfigured ?? false,
      secretVar: 'ELEVENLABS_API_KEY',
    },
    {
      name: 'Firebase Auth, Firestore & Storage',
      configured: integrations?.firebaseConfigured ?? false,
      secretVar: 'firebase-applet-config.json',
    },
    {
      name: 'Worker Authentication Secret',
      configured: integrations?.workerAuthConfigured ?? false,
      secretVar: 'WORKER_API_SECRET',
    },
    {
      name: 'YouTube Data API v3 OAuth',
      configured: integrations?.youtubeConfigured ?? false,
      secretVar: 'YOUTUBE_CLIENT_ID / SECRET / REFRESH_TOKEN',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">Settings</h1>
        <p className="text-sm text-[#94A3B8] mt-1">
          Server-side secret status (secrets are never exposed to the browser) and studio rendering defaults.
        </p>
      </div>

      {/* Server-side Integration Status Table */}
      <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-4">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-amber-400" />
          <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
            Server-Side Integrations & Secret Status
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#232D3F] text-[#94A3B8]">
                <th className="pb-2.5 font-medium">Integration</th>
                <th className="pb-2.5 font-medium">Server Environment Key</th>
                <th className="pb-2.5 font-medium text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#232D3F]/60">
              {integrationRows.map((row) => (
                <tr key={row.name}>
                  <td className="py-3 pr-4 font-medium text-[#F1F5F9]">{row.name}</td>
                  <td className="py-3 pr-4 font-mono-tabular text-[#94A3B8]">
                    {row.secretVar}
                  </td>
                  <td className="py-3 text-right">
                    {row.configured ? (
                      <span className="inline-flex items-center gap-1.5 text-emerald-400 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Configured (Masked)</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 text-amber-400 font-medium">
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Not configured</span>
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Non-secret Local Worker & Output Preferences */}
      <form
        onSubmit={(e) => void handleSave(e)}
        className="bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-5 max-w-3xl"
      >
        <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
          Local Worker & Output Configuration
        </h2>

        {savedNotice && (
          <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300">
            {savedNotice}
          </div>
        )}

        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-[#94A3B8]">
              Local Worker ComfyUI URL (PC-only localhost)
            </label>
            <input
              type="text"
              value={comfyuiUrl}
              onChange={(e) => setComfyuiUrl(e.target.value)}
              className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm font-mono-tabular text-[#F1F5F9]"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-[#94A3B8]">
              Firebase Storage Bucket & Prefix
            </label>
            <input
              type="text"
              value={storagePrefix}
              onChange={(e) => setStoragePrefix(e.target.value)}
              className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm font-mono-tabular text-[#F1F5F9]"
            />
            {integrations?.storageBucket && (
              <div className="text-[11px] font-mono-tabular text-[#64748B]">
                Bucket: {integrations.storageBucket}
              </div>
            )}
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-medium text-[#94A3B8]">
            Default Japanese Narrator Direction
          </label>
          <input
            type="text"
            value={defaultVoiceDirection}
            onChange={(e) => setDefaultVoiceDirection(e.target.value)}
            className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
          />
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-6 gap-3 pt-2 border-t border-[#232D3F] text-xs">
          <div>
            <div className="text-[#64748B]">Resolution</div>
            <div className="font-mono-tabular text-[#F1F5F9] mt-0.5">1920×1080</div>
          </div>
          <div>
            <div className="text-[#64748B]">FPS</div>
            <div className="font-mono-tabular text-[#F1F5F9] mt-0.5">30</div>
          </div>
          <div>
            <div className="text-[#64748B]">Format</div>
            <div className="font-mono-tabular text-[#F1F5F9] mt-0.5">MP4</div>
          </div>
          <div>
            <div className="text-[#64748B]">Video</div>
            <div className="font-mono-tabular text-[#F1F5F9] mt-0.5">H.264</div>
          </div>
          <div>
            <div className="text-[#64748B]">Audio</div>
            <div className="font-mono-tabular text-[#F1F5F9] mt-0.5">AAC</div>
          </div>
          <div>
            <div className="text-[#64748B]">Aspect</div>
            <div className="font-mono-tabular text-[#F1F5F9] mt-0.5">16:9</div>
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Saving...' : 'Save Studio Preferences'}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
