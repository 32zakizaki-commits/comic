import {
  Activity,
  Check,
  CheckCircle2,
  Copy,
  ShieldCheck,
  Terminal,
  Wrench,
  XCircle,
} from 'lucide-react';
import { useState } from 'react';
import type { ConnectionState, WorkerNode } from '../types/studio';
import { WorkerStatusLabel } from './StatusText';

interface WorkerSetupViewProps {
  workers: WorkerNode[];
  workerAuthConfigured: boolean;
  sharedBackendUrl?: string;
  apiStatus: ConnectionState;
  onOpenMonitor: () => void;
}

const DEFAULT_SHARED_BACKEND_URL =
  'https://ais-pre-iwein4jbokv72xdav7enbz-964336458859.europe-west2.run.app';

function resolveWorkerBackendUrl(sharedUrl?: string): string {
  if (sharedUrl && sharedUrl.startsWith('http')) {
    return sharedUrl.replace('://ais-dev-', '://ais-pre-').replace(/\/+$/, '');
  }
  if (typeof window !== 'undefined' && window.location?.origin) {
    const origin = window.location.origin.replace(/\/+$/, '');
    if (origin.includes('localhost') || origin.includes('127.0.0.1')) {
      return DEFAULT_SHARED_BACKEND_URL;
    }
    return origin.replace('://ais-dev-', '://ais-pre-');
  }
  return DEFAULT_SHARED_BACKEND_URL;
}

export function WorkerSetupView({
  workers,
  workerAuthConfigured,
  sharedBackendUrl,
  apiStatus,
  onOpenMonitor,
}: WorkerSetupViewProps) {
  const [copiedBlock, setCopiedBlock] = useState<'env' | 'powershell' | null>(null);

  const backendUrl = resolveWorkerBackendUrl(sharedBackendUrl);

  const envTemplate = `# Cloud Control Center Shared Production URL (HTTPS — do not use localhost or ais-dev-)
STUDIO_BACKEND_URL=${backendUrl}

# Must match WORKER_API_SECRET configured in Cloud backend environment secrets (16+ characters)
WORKER_API_SECRET=REPLACE_WITH_YOUR_SECRET

# Worker identity for your ASUS Windows 11 PC
WORKER_ID=win11-asus-workstation-01
WORKER_NAME=ASUS-Win11-Studio

# Local ComfyUI API (never exposed publicly)
COMFYUI_URL=http://127.0.0.1:8188
COMFYUI_CHECKPOINT=animagineXL_v31.safetensors

# Local FFmpeg binary path
FFMPEG_BIN=ffmpeg

# Heartbeat and job polling cadence (seconds)
HEARTBEAT_INTERVAL_SEC=15
POLL_INTERVAL_SEC=5`;

  const powershellScript = `# 1. Navigate to the worker folder on your ASUS Windows 11 PC
cd C:\\JapanComicStudio\\worker

# 2. Create and activate Python 3.11+ virtual environment
python -m venv .venv
.\\.venv\\Scripts\\Activate.ps1

# 3. Install worker dependencies (requests, psutil, python-dotenv)
pip install -r requirements.txt

# 4. Create worker\\.env from template (then paste your values)
copy .env.example .env
notepad .env

# 5. Verify FFmpeg & launch the Worker
ffmpeg -version
python worker.py`;

  const copyText = async (block: 'env' | 'powershell', text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedBlock(block);
      setTimeout(() => setCopiedBlock(null), 2000);
    } catch {
      // Clipboard API unavailable in restricted frame; user can still select text manually.
    }
  };

  const primary = workers[0] ?? null;
  const anyOnline = workers.some((w) => w.status === 'Online' || w.status === 'Busy');

  const envVars = [
    {
      name: 'STUDIO_BACKEND_URL',
      required: true,
      example: backendUrl,
      desc: 'Public HTTPS URL of your JapanComic Studio Control Center.',
    },
    {
      name: 'WORKER_API_SECRET',
      required: true,
      example: '(16+ char shared secret)',
      desc: 'Must match WORKER_API_SECRET in your server Secrets. Never placed in frontend code.',
    },
    {
      name: 'WORKER_ID',
      required: false,
      example: 'win11-asus-workstation-01',
      desc: 'Unique alphanumeric ID for this Windows 11 machine.',
    },
    {
      name: 'WORKER_NAME',
      required: false,
      example: 'ASUS-Win11-Studio',
      desc: 'Human-readable display name shown in Worker Monitor.',
    },
    {
      name: 'COMFYUI_URL',
      required: true,
      example: 'http://127.0.0.1:8188',
      desc: 'Local ComfyUI loopback API. Stays strictly on localhost.',
    },
    {
      name: 'COMFYUI_CHECKPOINT',
      required: true,
      example: 'animagineXL_v31.safetensors',
      desc: 'Checkpoint filename inside ComfyUI models/checkpoints/.',
    },
    {
      name: 'FFMPEG_BIN',
      required: true,
      example: 'ffmpeg',
      desc: 'FFmpeg executable name (if in PATH) or full path like C:\\ffmpeg\\bin\\ffmpeg.exe.',
    },
    {
      name: 'HEARTBEAT_INTERVAL_SEC',
      required: false,
      example: '15',
      desc: 'Seconds between authenticated worker heartbeats (timeout is 45s).',
    },
    {
      name: 'POLL_INTERVAL_SEC',
      required: false,
      example: '5',
      desc: 'Seconds between atomic /api/worker/claim polling requests.',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">
            Windows 11 Worker Setup
          </h1>
          <p className="text-sm text-[#94A3B8] mt-1">
            Install and connect the local Python Production Worker on your ASUS Windows 11 workstation. All communication runs outbound over authenticated HTTPS.
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenMonitor}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#121824] border border-[#232D3F] text-sm font-medium text-[#F1F5F9] hover:border-amber-500/40 whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Activity className="w-4 h-4 text-amber-400" />
          <span>Open Worker Monitor</span>
        </button>
      </div>

      {/* Live Connection Readiness Checklist */}
      <div className="grid sm:grid-cols-3 gap-4">
        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-4 space-y-1.5">
          <div className="text-xs text-[#94A3B8]">1. Cloud Control API</div>
          <div className="flex items-center gap-2 text-sm font-mono-tabular font-semibold">
            {apiStatus === 'connected' ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-400">Online & Reachable</span>
              </>
            ) : (
              <>
                <XCircle className="w-4 h-4 text-red-400" />
                <span className="text-red-400">{apiStatus}</span>
              </>
            )}
          </div>
        </div>

        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-4 space-y-1.5">
          <div className="text-xs text-[#94A3B8]">2. Server WORKER_API_SECRET</div>
          <div className="flex items-center gap-2 text-sm font-mono-tabular font-semibold">
            {workerAuthConfigured ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-400">Configured (16+ chars)</span>
              </>
            ) : (
              <>
                <XCircle className="w-4 h-4 text-amber-400" />
                <span className="text-amber-400">Not configured in server secrets</span>
              </>
            )}
          </div>
        </div>

        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-4 space-y-1.5">
          <div className="text-xs text-[#94A3B8]">3. Local Windows 11 Worker</div>
          <div className="flex items-center justify-between">
            <WorkerStatusLabel status={primary?.status ?? 'Offline'} />
            <span className="text-[11px] font-mono-tabular text-[#94A3B8]">
              {anyOnline ? primary?.machineName || primary?.hostname : 'Waiting for connection'}
            </span>
          </div>
        </div>
      </div>

      {/* Security Architecture Callout */}
      <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
        <div className="space-y-1 text-xs text-[#CBD5E1] leading-relaxed">
          <div className="font-semibold text-[#F1F5F9]">
            Deployed Cloud Run Endpoint &amp; Zero Frontend Secrets
          </div>
          <p className="text-[#94A3B8]">
            Point your Windows 11 worker to your <strong>live deployed Cloud Run URL</strong> (currently resolved as <code className="font-mono-tabular text-amber-300">{backendUrl}</code>) — never use <code className="font-mono-tabular">http://localhost:3000</code>, an <code className="font-mono-tabular">ais-dev-</code> development preview URL (blocked by browser cookie auth), or an unpublished <code className="font-mono-tabular">ais-pre-</code> URL (which returns HTTP 404 until deployed/published). Verify <code className="font-mono-tabular">GET /api/health</code> returns HTTP 200 JSON before starting <code className="font-mono-tabular">worker.py</code>.
          </p>
        </div>
      </div>

      {/* Step-by-step Windows 11 Installation */}
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-amber-400" />
              <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
                PowerShell Setup Commands (Windows 11)
              </h2>
            </div>
            <button
              type="button"
              onClick={() => void copyText('powershell', powershellScript)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#0B0F17] border border-[#232D3F] text-xs text-[#CBD5E1] hover:text-[#F1F5F9] cursor-pointer"
            >
              {copiedBlock === 'powershell' ? (
                <Check className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <Copy className="w-3.5 h-3.5" />
              )}
              <span>{copiedBlock === 'powershell' ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          <ol className="list-decimal list-inside space-y-2 text-xs text-[#CBD5E1]">
            <li>Install <strong>Python 3.11+</strong>, <strong>FFmpeg</strong> (added to Windows PATH), and NVIDIA GPU drivers.</li>
            <li>Start <strong>ComfyUI</strong> locally so <code className="font-mono-tabular text-amber-300">http://127.0.0.1:8188</code> is running with your anime/motion-comic checkpoint loaded.</li>
            <li>Set <code className="font-mono-tabular text-amber-300">WORKER_API_SECRET</code> (16+ random characters) in your Cloud Control Center Secrets panel.</li>
            <li>Run the PowerShell commands below inside your local <code className="font-mono-tabular">worker/</code> folder:</li>
          </ol>

          <pre className="p-3.5 rounded-lg bg-[#0B0F17] border border-[#232D3F] text-[11px] font-mono-tabular text-[#E2E8F0] overflow-x-auto">
            {powershellScript}
          </pre>
        </div>

        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Wrench className="w-4 h-4 text-amber-400" />
              <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
                worker/.env Configuration Template
              </h2>
            </div>
            <button
              type="button"
              onClick={() => void copyText('env', envTemplate)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#0B0F17] border border-[#232D3F] text-xs text-[#CBD5E1] hover:text-[#F1F5F9] cursor-pointer"
            >
              {copiedBlock === 'env' ? (
                <Check className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <Copy className="w-3.5 h-3.5" />
              )}
              <span>{copiedBlock === 'env' ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          <p className="text-xs text-[#94A3B8]">
            Your Cloud Control Center URL is pre-filled below. Replace <code className="font-mono-tabular text-amber-300">REPLACE_WITH_YOUR_SECRET</code> with your exact server <code className="font-mono-tabular">WORKER_API_SECRET</code>.
          </p>

          <pre className="p-3.5 rounded-lg bg-[#0B0F17] border border-[#232D3F] text-[11px] font-mono-tabular text-[#E2E8F0] overflow-x-auto">
            {envTemplate}
          </pre>
        </div>
      </div>

      {/* Required Environment Variables Table */}
      <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5 space-y-4">
        <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
          Worker Environment Variables Reference
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#232D3F] text-[#94A3B8]">
                <th className="pb-2.5 pr-4 font-medium">Variable</th>
                <th className="pb-2.5 pr-4 font-medium">Required</th>
                <th className="pb-2.5 pr-4 font-medium">Example Value</th>
                <th className="pb-2.5 font-medium">Purpose</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#232D3F]/60">
              {envVars.map((v) => (
                <tr key={v.name}>
                  <td className="py-2.5 pr-4 font-mono-tabular text-amber-300">{v.name}</td>
                  <td className="py-2.5 pr-4 font-mono-tabular text-[#CBD5E1]">
                    {v.required ? 'Yes' : 'Optional'}
                  </td>
                  <td className="py-2.5 pr-4 font-mono-tabular text-[#94A3B8] max-w-xs truncate">
                    {v.example}
                  </td>
                  <td className="py-2.5 text-[#CBD5E1]">{v.desc}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
