import { CheckCircle2, Film, MessageSquareWarning, XCircle } from 'lucide-react';
import { useState } from 'react';
import type { ApprovalRecord, Episode, Project } from '../types/studio';
import { ProductionStatusLabel } from './StatusText';

interface ApprovalCenterViewProps {
  projects: Project[];
  episodes: Episode[];
  approvals: ApprovalRecord[];
  onSubmitReview: (input: {
    episode: Episode;
    decision: 'approved' | 'rejected' | 'changes_requested';
    comments: string;
  }) => Promise<void>;
}

export function ApprovalCenterView({
  projects,
  episodes,
  approvals,
  onSubmitReview,
}: ApprovalCenterViewProps) {
  const [selectedEpId, setSelectedEpId] = useState<string>(
    episodes.find((e) => e.status === 'pending_approval')?.episodeId ??
      episodes[0]?.episodeId ??
      '',
  );
  const [comments, setComments] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const activeEpisode =
    episodes.find((e) => e.episodeId === selectedEpId) ?? episodes[0] ?? null;

  const project = activeEpisode
    ? projects.find((p) => p.projectId === activeEpisode.projectId)
    : null;

  const handleDecision = async (
    decision: 'approved' | 'rejected' | 'changes_requested',
  ) => {
    if (!activeEpisode) return;
    if (!comments.trim() && decision !== 'approved') {
      setErrorMsg('Please include review comments when rejecting or requesting changes.');
      return;
    }
    setSubmitting(true);
    setErrorMsg(null);
    setNotice(null);
    try {
      await onSubmitReview({
        episode: activeEpisode,
        decision,
        comments: comments.trim() || 'Approved for YouTube publishing preparation.',
      });
      setComments('');
      setNotice(
        decision === 'approved'
          ? 'Episode approved. YouTube Publishing is now unlocked.'
          : `Review decision recorded (${decision}).`,
      );
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to submit approval review.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">
            Approval Center
          </h1>
          <p className="text-sm text-[#94A3B8] mt-1">
            Manual quality assurance gate. YouTube publishing remains locked until an episode is explicitly approved.
          </p>
        </div>

        {episodes.length > 0 && (
          <select
            value={activeEpisode?.episodeId ?? ''}
            onChange={(e) => setSelectedEpId(e.target.value)}
            className="bg-[#121824] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
          >
            {episodes.map((ep) => (
              <option key={ep.episodeId} value={ep.episodeId}>
                {ep.title} ({ep.status})
              </option>
            ))}
          </select>
        )}
      </div>

      {errorMsg && (
        <div className="p-3.5 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">
          {errorMsg}
        </div>
      )}
      {notice && (
        <div className="p-3.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300">
          {notice}
        </div>
      )}

      {!activeEpisode ? (
        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-12 text-center text-sm text-[#94A3B8]">
          No episodes available for review yet.
        </div>
      ) : (
        <div className="grid xl:grid-cols-12 gap-6">
          {/* Left: Video Preview & Scene Strip */}
          <div className="xl:col-span-7 space-y-5">
            <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-xs text-[#94A3B8]">
                    {project?.title ?? 'Project'} · {activeEpisode.genre}
                  </div>
                  <h2 className="font-display text-xl font-semibold text-[#F1F5F9] mt-0.5">
                    {activeEpisode.title}
                  </h2>
                  {activeEpisode.japaneseTitle && (
                    <div className="text-xs text-[#CBD5E1] mt-0.5">
                      {activeEpisode.japaneseTitle}
                    </div>
                  )}
                </div>
                <ProductionStatusLabel status={activeEpisode.status} />
              </div>

              <div className="aspect-video rounded-lg overflow-hidden bg-[#0B0F17] border border-[#232D3F] flex items-center justify-center">
                {activeEpisode.videoOutput?.url ? (
                  <video
                    controls
                    src={activeEpisode.videoOutput.url}
                    className="w-full h-full object-contain bg-black"
                  />
                ) : (
                  <div className="p-6 text-center space-y-2">
                    <Film className="w-7 h-7 text-[#475569] mx-auto" />
                    <div className="text-xs font-medium text-[#94A3B8]">
                      No Rendered Video Attached Yet
                    </div>
                    <div className="text-[11px] text-[#64748B]">
                      Render the episode via Video Composer + Local Worker before final approval.
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-3 gap-3 text-xs pt-2 border-t border-[#232D3F]">
                <div>
                  <span className="text-[#64748B]">Scenes:</span>{' '}
                  <span className="font-mono-tabular text-[#F1F5F9]">
                    {activeEpisode.scenes?.length ?? 0}
                  </span>
                </div>
                <div>
                  <span className="text-[#64748B]">Resolution:</span>{' '}
                  <span className="font-mono-tabular text-[#F1F5F9]">
                    {activeEpisode.videoOutput?.resolution ?? '1920x1080 target'}
                  </span>
                </div>
                <div>
                  <span className="text-[#64748B]">Script Approved:</span>{' '}
                  <span className="text-[#F1F5F9]">
                    {activeEpisode.scriptApproved ? 'Yes' : 'No'}
                  </span>
                </div>
              </div>
            </div>

            {/* Generated Scenes Overview */}
            <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-3">
              <h3 className="font-display text-base font-semibold text-[#F1F5F9]">
                Script & Scene Storyboard ({activeEpisode.scenes.length})
              </h3>
              <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                {activeEpisode.scenes.map((sc) => (
                  <div
                    key={sc.sceneNumber}
                    className="p-3 rounded-lg bg-[#0B0F17] border border-[#232D3F] flex gap-3"
                  >
                    <div className="w-28 aspect-video rounded bg-[#121824] border border-[#232D3F] shrink-0 overflow-hidden flex items-center justify-center text-[10px] text-[#64748B]">
                      {sc.generatedImageUrl ? (
                        <img
                          src={sc.generatedImageUrl}
                          alt={`Scene ${sc.sceneNumber}`}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        `Scene ${sc.sceneNumber}`
                      )}
                    </div>
                    <div className="min-w-0 space-y-1">
                      <div className="text-xs font-medium text-amber-400">
                        Scene {sc.sceneNumber} · {sc.location}
                      </div>
                      <p className="text-xs text-[#E2E8F0] line-clamp-2">{sc.narration}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Decision Form & Audit Trail */}
          <div className="xl:col-span-5 space-y-6">
            <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-4">
              <h3 className="font-display text-base font-semibold text-[#F1F5F9]">
                Reviewer Decision
              </h3>
              <div className="space-y-1.5">
                <label className="text-xs text-[#94A3B8]">Review Notes & Feedback</label>
                <textarea
                  rows={4}
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  placeholder="Note pacing, Japanese pronunciation, subtitle timing, or visual continuity feedback..."
                  className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2">
                <button
                  type="button"
                  disabled={submitting}
                  onClick={() => void handleDecision('approved')}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-lg bg-emerald-600 text-white font-semibold text-xs hover:bg-emerald-500 disabled:opacity-60 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Approve</span>
                </button>
                <button
                  type="button"
                  disabled={submitting}
                  onClick={() => void handleDecision('changes_requested')}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-lg bg-[#171F2E] border border-amber-500/40 text-amber-300 font-semibold text-xs hover:bg-amber-500/10 disabled:opacity-60 cursor-pointer"
                >
                  <MessageSquareWarning className="w-4 h-4" />
                  <span>Request Changes</span>
                </button>
                <button
                  type="button"
                  disabled={submitting}
                  onClick={() => void handleDecision('rejected')}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-lg bg-red-600/90 text-white font-semibold text-xs hover:bg-red-500 disabled:opacity-60 cursor-pointer"
                >
                  <XCircle className="w-4 h-4" />
                  <span>Reject</span>
                </button>
              </div>
            </div>

            <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-3">
              <h3 className="font-display text-base font-semibold text-[#F1F5F9]">
                Approval Audit Trail
              </h3>
              {approvals.filter((a) => a.episodeId === activeEpisode.episodeId).length === 0 ? (
                <p className="text-xs text-[#64748B]">No review decisions recorded for this episode yet.</p>
              ) : (
                <div className="space-y-2.5">
                  {approvals
                    .filter((a) => a.episodeId === activeEpisode.episodeId)
                    .map((apr) => (
                      <div
                        key={apr.approvalId}
                        className="p-3 rounded-lg bg-[#0B0F17] border border-[#232D3F] text-xs space-y-1"
                      >
                        <div className="flex justify-between">
                          <span className="font-semibold capitalize text-[#F1F5F9]">
                            {apr.decision.replace('_', ' ')}
                          </span>
                          <span className="font-mono-tabular text-[#64748B]">
                            Reviewer: {apr.reviewerId.slice(0, 10)}…
                          </span>
                        </div>
                        <p className="text-[#94A3B8]">{apr.comments}</p>
                      </div>
                    ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
