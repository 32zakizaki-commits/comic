import { Clapperboard, Download, Film } from 'lucide-react';
import { useState } from 'react';
import type { Episode, JobType, ProductionJob } from '../types/studio';
import { ProductionStatusLabel } from './StatusText';

interface VideoComposerViewProps {
  episodes: Episode[];
  jobs: ProductionJob[];
  selectedEpisodeId: string | null;
  onSelectEpisode: (episodeId: string) => void;
  onEnqueueJob: (input: {
    projectId: string;
    episodeId: string;
    episodeTitle: string;
    type: JobType;
    payload: Record<string, unknown>;
    idempotencyKey?: string;
  }) => Promise<unknown>;
  onUpdateEpisode: (episodeId: string, updates: Partial<Episode>) => Promise<void>;
}

export function VideoComposerView({
  episodes,
  jobs,
  selectedEpisodeId,
  onSelectEpisode,
  onEnqueueJob,
  onUpdateEpisode,
}: VideoComposerViewProps) {
  const activeEpisode =
    episodes.find((e) => e.episodeId === selectedEpisodeId) ?? episodes[0] ?? null;

  const [dispatching, setDispatching] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const renderJobs = activeEpisode
    ? jobs.filter(
        (j) =>
          j.episodeId === activeEpisode.episodeId &&
          (j.type === 'video_render' || j.type === 'full_episode'),
      )
    : [];

  const activeRenderJob = renderJobs[0] ?? null;

  const handleQueueRender = async () => {
    if (!activeEpisode) return;
    setDispatching(true);
    setNotice(null);
    setErrorMsg(null);
    try {
      await onEnqueueJob({
        projectId: activeEpisode.projectId,
        episodeId: activeEpisode.episodeId,
        episodeTitle: activeEpisode.title,
        type: 'video_render',
        idempotencyKey: `render_${activeEpisode.episodeId}_${Date.now()}`,
        payload: {
          episodeTitle: activeEpisode.title,
          japaneseTitle: activeEpisode.japaneseTitle ?? activeEpisode.title,
          scenes: activeEpisode.scenes,
          narrationAudioUrl: activeEpisode.narrationAudioUrl ?? '',
          outputSpec: {
            resolution: '1920x1080',
            fps: 30,
            format: 'mp4',
            videoCodec: 'H.264',
            audioCodec: 'AAC',
            aspectRatio: '16:9',
          },
        },
      });
      await onUpdateEpisode(activeEpisode.episodeId, { status: 'queued' });
      setNotice('1080p FFmpeg render job queued for Local Production Worker.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to queue render job.');
    } finally {
      setDispatching(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">
            Video Composer
          </h1>
          <p className="text-sm text-[#94A3B8] mt-1">
            Dispatch 1920×1080 30fps H.264/AAC FFmpeg rendering to the local Windows 11 Production Worker.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {episodes.length > 0 && (
            <select
              value={activeEpisode?.episodeId ?? ''}
              onChange={(e) => onSelectEpisode(e.target.value)}
              className="bg-[#121824] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
            >
              {episodes.map((ep) => (
                <option key={ep.episodeId} value={ep.episodeId}>
                  {ep.title}
                </option>
              ))}
            </select>
          )}
          {activeEpisode && (
            <button
              type="button"
              disabled={dispatching || activeEpisode.scenes.length === 0}
              onClick={() => void handleQueueRender()}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 disabled:opacity-50 whitespace-nowrap cursor-pointer"
            >
              <Clapperboard className="w-4 h-4" />
              <span>{dispatching ? 'Queueing...' : 'Queue FFmpeg Render'}</span>
            </button>
          )}
        </div>
      </div>

      {errorMsg && (
        <div className="p-3.5 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">
          {errorMsg}
        </div>
      )}
      {notice && (
        <div className="p-3.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300">
          {notice}
        </div>
      )}

      <div className="grid lg:grid-cols-12 gap-6">
        {/* Left: Video Preview / Honest Waiting State */}
        <div className="lg:col-span-8 bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
              Master Video Output
            </h2>
            {activeEpisode && <ProductionStatusLabel status={activeEpisode.status} />}
          </div>

          <div className="aspect-video rounded-lg overflow-hidden bg-[#0B0F17] border border-[#232D3F] flex items-center justify-center">
            {activeEpisode?.videoOutput?.url ? (
              <video
                controls
                src={activeEpisode.videoOutput.url}
                className="w-full h-full object-contain bg-black"
              />
            ) : (
              <div className="p-8 text-center space-y-2 max-w-md">
                <Film className="w-8 h-8 text-[#475569] mx-auto" />
                <div className="text-sm font-medium text-[#CBD5E1]">
                  {activeRenderJob
                    ? `Render Job: ${activeRenderJob.status} (${activeRenderJob.progress}%)`
                    : 'No Rendered Master Video Yet'}
                </div>
                <p className="text-xs text-[#64748B] leading-relaxed">
                  {activeRenderJob?.stageMessage ||
                    'Video rendering happens exclusively on your Windows 11 Production Worker via FFmpeg (pan/zoom, subtitles, audio sync). Completed MP4 files appear here once uploaded.'}
                </p>
              </div>
            )}
          </div>

          {activeRenderJob && (
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-[#94A3B8]">{activeRenderJob.stageMessage}</span>
                <span className="font-mono-tabular text-[#F1F5F9]">
                  {activeRenderJob.progress}%
                </span>
              </div>
              <div className="h-2 rounded-full bg-[#0B0F17] overflow-hidden">
                <div
                  className="h-full bg-amber-500 transition-all duration-300"
                  style={{ width: `${activeRenderJob.progress}%` }}
                />
              </div>
            </div>
          )}

          {activeEpisode?.videoOutput?.url && (
            <div className="flex items-center justify-between pt-2 border-t border-[#232D3F] text-xs">
              <span className="font-mono-tabular text-[#94A3B8]">
                Duration: {activeEpisode.videoOutput.durationSec}s · {activeEpisode.videoOutput.resolution} · {activeEpisode.videoOutput.fps} FPS
              </span>
              <a
                href={activeEpisode.videoOutput.url}
                download
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#171F2E] border border-[#232D3F] text-amber-400 hover:border-amber-500/40"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download MP4</span>
              </a>
            </div>
          )}
        </div>

        {/* Right: Target Encoding Spec + Render History */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-3">
            <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
              Target FFmpeg Output Spec
            </h2>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-[#232D3F]/60">
                <span className="text-[#94A3B8]">Resolution</span>
                <span className="font-mono-tabular text-[#F1F5F9]">1920 × 1080</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#232D3F]/60">
                <span className="text-[#94A3B8]">Frame Rate</span>
                <span className="font-mono-tabular text-[#F1F5F9]">30 FPS</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#232D3F]/60">
                <span className="text-[#94A3B8]">Container / Aspect</span>
                <span className="font-mono-tabular text-[#F1F5F9]">MP4 · 16:9</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#232D3F]/60">
                <span className="text-[#94A3B8]">Video Codec</span>
                <span className="font-mono-tabular text-[#F1F5F9]">H.264 (libx264)</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#94A3B8]">Audio Codec</span>
                <span className="font-mono-tabular text-[#F1F5F9]">AAC 48kHz</span>
              </div>
            </div>
          </div>

          <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-3">
            <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
              Render History
            </h2>
            {!activeEpisode?.videoOutput?.renderHistory?.length ? (
              <p className="text-xs text-[#64748B]">No completed renders recorded yet.</p>
            ) : (
              <div className="space-y-2.5">
                {activeEpisode.videoOutput.renderHistory.map((item) => (
                  <div
                    key={item.renderId}
                    className="p-3 rounded-lg bg-[#0B0F17] border border-[#232D3F] text-xs space-y-1"
                  >
                    <div className="flex justify-between font-mono-tabular text-[#F1F5F9]">
                      <span>{item.resolution}</span>
                      <span>{item.durationSec}s</span>
                    </div>
                    <div className="text-[11px] text-[#94A3B8]">
                      {new Date(item.renderedAt).toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
