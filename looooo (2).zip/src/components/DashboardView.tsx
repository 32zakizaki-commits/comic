import { ArrowRight, Plus, Server } from 'lucide-react';
import { useState } from 'react';
import type {
  Episode,
  NavSection,
  ProductionJob,
  Project,
  StoryGenre,
  WorkerNode,
  WorkerStatus,
} from '../types/studio';
import { ProductionStatusLabel, WorkerStatusLabel } from './StatusText';

interface DashboardViewProps {
  projects: Project[];
  episodes: Episode[];
  jobs: ProductionJob[];
  workers: WorkerNode[];
  onNavigate: (section: NavSection, episodeId?: string) => void;
  onCreateQuickEpisode: (input: {
    projectId: string;
    title: string;
    genre: StoryGenre;
  }) => Promise<string>;
}

const GENRES: StoryGenre[] = [
  'Drama',
  'Business',
  'Revenge',
  'Mystery',
  'Romance',
  'Historical',
  'Psychological',
  'Thriller',
  'Inspirational',
];

export function DashboardView({
  projects,
  episodes,
  jobs,
  workers,
  onNavigate,
  onCreateQuickEpisode,
}: DashboardViewProps) {
  const [showNewEpisodeModal, setShowNewEpisodeModal] = useState(false);
  const [selectedProjectId, setSelectedProjectId] = useState(projects[0]?.projectId ?? '');
  const [newEpTitle, setNewEpTitle] = useState('');
  const [newEpGenre, setNewEpGenre] = useState<StoryGenre>('Drama');
  const [creating, setCreating] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const completedEpisodes = episodes.filter(
    (e) => e.status === 'completed' || e.status === 'approved',
  ).length;
  const pendingApprovals = episodes.filter((e) => e.status === 'pending_approval').length;
  const failedJobs = jobs.filter((j) => j.status === 'failed').length;

  const primaryWorker = workers[0] ?? null;
  const workerStatus: WorkerStatus = primaryWorker?.status ?? 'Offline';

  const handleQuickCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    const pid = selectedProjectId || projects[0]?.projectId;
    if (!pid) {
      setErrorMsg('Create a project first before creating an episode.');
      return;
    }
    if (!newEpTitle.trim()) {
      setErrorMsg('Episode title is required.');
      return;
    }
    setCreating(true);
    setErrorMsg(null);
    try {
      const epId = await onCreateQuickEpisode({
        projectId: pid,
        title: newEpTitle.trim(),
        genre: newEpGenre,
      });
      setShowNewEpisodeModal(false);
      setNewEpTitle('');
      onNavigate('story-studio', epId);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to create episode.');
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">
            Studio Dashboard
          </h1>
          <p className="text-sm text-[#94A3B8] mt-1">
            Control center for Japanese Motion Comic production, local worker queues, and final release approvals.
          </p>
        </div>
        <button
          type="button"
          onClick={() => {
            setSelectedProjectId(projects[0]?.projectId ?? '');
            setShowNewEpisodeModal(true);
          }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Create New Episode</span>
        </button>
      </div>

      {/* 5-Column KPI Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-4">
        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5">
          <div className="text-xs text-[#94A3B8]">Total Projects</div>
          <div className="font-mono-tabular text-2xl font-semibold text-[#F1F5F9] mt-2">
            {projects.length}
          </div>
        </div>
        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5">
          <div className="text-xs text-[#94A3B8]">Total Episodes</div>
          <div className="font-mono-tabular text-2xl font-semibold text-[#F1F5F9] mt-2">
            {episodes.length}
          </div>
        </div>
        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5">
          <div className="text-xs text-[#94A3B8]">Completed Episodes</div>
          <div className="font-mono-tabular text-2xl font-semibold text-emerald-400 mt-2">
            {completedEpisodes}
          </div>
        </div>
        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5">
          <div className="text-xs text-[#94A3B8]">Pending Approvals</div>
          <div className="font-mono-tabular text-2xl font-semibold text-amber-400 mt-2">
            {pendingApprovals}
          </div>
        </div>
        <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-5">
          <div className="text-xs text-[#94A3B8]">Failed Jobs</div>
          <div className="font-mono-tabular text-2xl font-semibold text-red-400 mt-2">
            {failedJobs}
          </div>
        </div>
      </div>

      {/* Middle Grid: Worker Connection Status & Production Queue */}
      <div className="grid lg:grid-cols-12 gap-6">
        {/* Worker Connection Card */}
        <div className="lg:col-span-5 bg-[#121824] border border-[#232D3F] rounded-xl p-6 flex flex-col justify-between space-y-5">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Server className="w-4 h-4 text-amber-400" />
                <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
                  Local Production Worker
                </h2>
              </div>
              <WorkerStatusLabel status={workerStatus} />
            </div>

            <div className="border-t border-[#232D3F] pt-4 space-y-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-[#94A3B8]">Worker Host</span>
                <span className="font-mono-tabular text-xs text-[#F1F5F9]">
                  {primaryWorker ? `${primaryWorker.name} (${primaryWorker.hostname})` : 'Not connected'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#94A3B8]">Last Heartbeat</span>
                <span className="font-mono-tabular text-xs text-[#F1F5F9]">
                  {primaryWorker?.lastHeartbeat
                    ? new Date(primaryWorker.lastHeartbeat).toLocaleTimeString()
                    : 'Unavailable'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#94A3B8]">GPU Telemetry</span>
                <span className="font-mono-tabular text-xs text-[#F1F5F9]">
                  {primaryWorker?.metrics?.gpuName
                    ? `${primaryWorker.metrics.gpuName} · ${primaryWorker.metrics.gpuUsagePercent ?? 0}%`
                    : 'Not connected'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#94A3B8]">VRAM / Disk</span>
                <span className="font-mono-tabular text-xs text-[#F1F5F9]">
                  {primaryWorker?.metrics?.gpuMemoryTotalMb
                    ? `${primaryWorker.metrics.gpuMemoryUsedMb ?? 0}/${primaryWorker.metrics.gpuMemoryTotalMb} MB · ${primaryWorker.metrics.diskFreeGb ?? '—'} GB free`
                    : 'Unavailable'}
                </span>
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-[#232D3F] flex items-center justify-between">
            <span className="text-xs text-[#64748B]">
              Windows 11 ComfyUI + FFmpeg Bridge
            </span>
            <button
              type="button"
              onClick={() => onNavigate('worker-monitor')}
              className="inline-flex items-center gap-1 text-xs font-medium text-amber-400 hover:text-amber-300 cursor-pointer"
            >
              <span>Inspect Worker</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Production Queue Preview */}
        <div className="lg:col-span-7 bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
              Production Queue
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('production-queue')}
              className="inline-flex items-center gap-1 text-xs font-medium text-amber-400 hover:text-amber-300 cursor-pointer"
            >
              <span>View All Jobs</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {jobs.length === 0 ? (
            <div className="py-10 text-center space-y-2 border border-dashed border-[#232D3F] rounded-lg">
              <p className="text-sm text-[#94A3B8]">No production jobs queued yet.</p>
              <p className="text-xs text-[#64748B]">
                Generate scenes or queue a 1080p render to dispatch work to your local PC.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-[#232D3F] text-[#94A3B8]">
                    <th className="pb-2.5 font-medium">Episode</th>
                    <th className="pb-2.5 font-medium">Type</th>
                    <th className="pb-2.5 font-medium">Status</th>
                    <th className="pb-2.5 font-medium text-right">Progress</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#232D3F]/60">
                  {jobs.slice(0, 5).map((job) => (
                    <tr key={job.jobId} className="hover:bg-[#171F2E]/60">
                      <td className="py-3 pr-3 font-medium text-[#F1F5F9] truncate max-w-[200px]">
                        {job.episodeTitle}
                        {typeof job.sceneNumber === 'number' ? ` · Scene ${job.sceneNumber}` : ''}
                      </td>
                      <td className="py-3 pr-3 text-[#94A3B8] font-mono-tabular">{job.type}</td>
                      <td className="py-3 pr-3">
                        <ProductionStatusLabel status={job.status} />
                      </td>
                      <td className="py-3 text-right font-mono-tabular text-[#F1F5F9]">
                        {job.progress}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Recent Production Activity (Episodes) */}
      <div className="bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
            Recent Production Activity
          </h2>
          <button
            type="button"
            onClick={() => onNavigate('projects')}
            className="inline-flex items-center gap-1 text-xs font-medium text-amber-400 hover:text-amber-300 cursor-pointer"
          >
            <span>Manage Projects</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {episodes.length === 0 ? (
          <div className="py-10 text-center space-y-3 border border-dashed border-[#232D3F] rounded-lg">
            <p className="text-sm text-[#94A3B8]">
              {projects.length === 0
                ? 'Start by creating your first Japanese Motion Comic project.'
                : 'No episodes created yet. Create an episode to begin writing with Gemini.'}
            </p>
            <button
              type="button"
              onClick={() =>
                projects.length === 0 ? onNavigate('projects') : setShowNewEpisodeModal(true)
              }
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#171F2E] border border-[#232D3F] text-xs font-medium text-[#F1F5F9] hover:border-amber-500/40 cursor-pointer"
            >
              <span>{projects.length === 0 ? 'Go to Projects' : 'Create First Episode'}</span>
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-[#232D3F] text-xs text-[#94A3B8]">
                  <th className="pb-2.5 font-medium">Episode</th>
                  <th className="pb-2.5 font-medium">Project</th>
                  <th className="pb-2.5 font-medium">Genre</th>
                  <th className="pb-2.5 font-medium">Scenes</th>
                  <th className="pb-2.5 font-medium">Status</th>
                  <th className="pb-2.5 font-medium text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#232D3F]/60">
                {episodes.slice(0, 6).map((ep) => {
                  const proj = projects.find((p) => p.projectId === ep.projectId);
                  return (
                    <tr key={ep.episodeId} className="hover:bg-[#171F2E]/50">
                      <td className="py-3 pr-4">
                        <div className="font-medium text-[#F1F5F9]">{ep.title}</div>
                        {ep.japaneseTitle && (
                          <div className="text-xs text-[#94A3B8]">{ep.japaneseTitle}</div>
                        )}
                      </td>
                      <td className="py-3 pr-4 text-xs text-[#94A3B8]">
                        {proj?.title ?? '—'}
                      </td>
                      <td className="py-3 pr-4 text-xs text-[#94A3B8]">{ep.genre}</td>
                      <td className="py-3 pr-4 font-mono-tabular text-xs text-[#F1F5F9]">
                        {ep.scenes?.length ?? 0}
                      </td>
                      <td className="py-3 pr-4">
                        <ProductionStatusLabel status={ep.status} />
                      </td>
                      <td className="py-3 text-right">
                        <button
                          type="button"
                          onClick={() => onNavigate('story-studio', ep.episodeId)}
                          className="text-xs font-medium text-amber-400 hover:text-amber-300 cursor-pointer"
                        >
                          Open Studio
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Quick Create Episode Modal */}
      {showNewEpisodeModal && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold text-[#F1F5F9]">
                Create New Episode
              </h3>
              <button
                type="button"
                onClick={() => setShowNewEpisodeModal(false)}
                className="text-xs text-[#94A3B8] hover:text-[#F1F5F9] cursor-pointer"
              >
                Close
              </button>
            </div>

            {projects.length === 0 ? (
              <div className="space-y-4">
                <p className="text-sm text-[#94A3B8]">
                  You need at least one project before adding episodes.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setShowNewEpisodeModal(false);
                    onNavigate('projects');
                  }}
                  className="w-full py-2.5 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 cursor-pointer"
                >
                  Create a Project First
                </button>
              </div>
            ) : (
              <form onSubmit={(e) => void handleQuickCreate(e)} className="space-y-4">
                {errorMsg && (
                  <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">
                    {errorMsg}
                  </div>
                )}
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-[#94A3B8]">Project</label>
                  <select
                    value={selectedProjectId || projects[0]?.projectId || ''}
                    onChange={(e) => setSelectedProjectId(e.target.value)}
                    className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9] focus:outline-none focus:border-amber-500"
                  >
                    {projects.map((p) => (
                      <option key={p.projectId} value={p.projectId}>
                        {p.title}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-[#94A3B8]">Episode Title</label>
                  <input
                    type="text"
                    required
                    value={newEpTitle}
                    onChange={(e) => setNewEpTitle(e.target.value)}
                    placeholder="e.g., Ep 01 — Rain at Ginza Crossing"
                    className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9] focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-[#94A3B8]">Genre</label>
                  <select
                    value={newEpGenre}
                    onChange={(e) => setNewEpGenre(e.target.value as StoryGenre)}
                    className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9] focus:outline-none focus:border-amber-500"
                  >
                    {GENRES.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowNewEpisodeModal(false)}
                    className="px-4 py-2 rounded-lg text-sm text-[#94A3B8] hover:text-[#F1F5F9] cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={creating}
                    className="px-4 py-2 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 disabled:opacity-60 cursor-pointer"
                  >
                    {creating ? 'Creating...' : 'Create & Open Story Studio'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
