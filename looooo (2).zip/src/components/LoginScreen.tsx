import { Film, Lock, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { useFirebase } from '../contexts/FirebaseContext';

const BACKDROP_IMAGE = '/src/assets/images/studio_login_backdrop_1795391143287.jpg';

export function LoginScreen() {
  const { signInWithGoogle, signingIn, authError } = useFirebase();
  const [imgFailed, setImgFailed] = useState(false);

  return (
    <div className="min-h-screen bg-[#0B0F17] text-[#F1F5F9] grid lg:grid-cols-12">
      {/* Left Studio Editorial Visual Panel */}
      <div className="relative lg:col-span-7 overflow-hidden bg-[#121824] border-b lg:border-b-0 lg:border-r border-[#232D3F] min-h-[320px] lg:min-h-screen flex flex-col justify-between p-8 lg:p-12">
        {!imgFailed ? (
          <img
            src={BACKDROP_IMAGE}
            alt="Rain-slicked Tokyo dusk street illustration for JapanComic Studio"
            referrerPolicy="no-referrer"
            onError={() => setImgFailed(true)}
            className="absolute inset-0 w-full h-full object-cover opacity-55"
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-[#151D2E] via-[#0F141F] to-[#0B0F17]" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F17] via-[#0B0F17]/60 to-[#0B0F17]/40" />

        <div className="relative z-10 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center font-display font-bold text-lg">
            JC
          </div>
          <span className="font-display font-semibold text-lg tracking-tight text-[#F1F5F9]">
            JapanComic Studio
          </span>
        </div>

        <div className="relative z-10 max-w-xl space-y-5 pt-16 lg:pt-0">
          <p className="text-xs font-medium tracking-wide text-amber-400">
            Hybrid Motion Comic Control Center
          </p>
          <h1 className="font-display text-3xl sm:text-4xl lg:text-[2.75rem] font-semibold leading-[1.15] text-balance text-[#F1F5F9]">
            Direct original Japanese motion comics from script to 1080p master.
          </h1>
          <p className="text-sm sm:text-base text-[#CBD5E1] leading-relaxed">
            Orchestrate Gemini story generation, character visual continuity, ElevenLabs Japanese voiceovers, local Windows 11 ComfyUI & FFmpeg rendering, and human-approved YouTube publishing.
          </p>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-[#94A3B8] pt-2">
            <span>Cloud Firestore Control Plane</span>
            <span aria-hidden="true">·</span>
            <span>Authenticated Local Worker Bridge</span>
            <span aria-hidden="true">·</span>
            <span>1920×1080 30fps H.264 Master</span>
          </div>
        </div>
      </div>

      {/* Right Authentication Console */}
      <div className="lg:col-span-5 flex items-center justify-center p-8 lg:p-14 bg-[#0B0F17]">
        <div className="w-full max-w-md space-y-8">
          <div className="space-y-2">
            <h2 className="font-display text-2xl font-semibold text-[#F1F5F9]">
              Producer Sign In
            </h2>
            <p className="text-sm text-[#94A3B8] leading-relaxed">
              Sign in with your verified Google account to access your projects, episodes, and production queue.
            </p>
          </div>

          {authError && (
            <div className="p-3.5 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">
              {authError}
            </div>
          )}

          <button
            type="button"
            disabled={signingIn}
            onClick={() => void signInWithGoogle()}
            className="w-full flex items-center justify-center gap-3 px-5 py-3 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 transition-colors disabled:opacity-60 cursor-pointer"
          >
            <Film className="w-4 h-4 shrink-0" />
            <span>{signingIn ? 'Connecting to Studio...' : 'Continue with Google'}</span>
          </button>

          <div className="border-t border-[#232D3F] pt-6 space-y-3 text-xs text-[#94A3B8]">
            <div className="flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <p>
                All Gemini, ElevenLabs, and YouTube credentials stay strictly on the server. Local ComfyUI ports are never exposed to the public internet.
              </p>
            </div>
            <div className="flex items-start gap-2.5">
              <Lock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <p>
                Every episode requires explicit human approval in the Approval Center before YouTube publishing unlocks.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
