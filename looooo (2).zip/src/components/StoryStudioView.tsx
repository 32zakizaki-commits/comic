import { CheckCircle2, Edit3, RefreshCw, Save, Sparkles } from 'lucide-react';
import { useEffect, useState } from 'react';
import { apiFetch } from '../lib/apiClient';
import type {
  Character,
  Episode,
  Project,
  StoryGenre,
  StoryScript,
} from '../types/studio';
import { ProductionStatusLabel } from './StatusText';

interface StoryStudioViewProps {
  projects: Project[];
  episodes: Episode[];
  characters: Character[];
  selectedEpisodeId: string | null;
  onSelectEpisode: (episodeId: string) => void;
  onCreateEpisode: (input: {
    projectId: string;
    title: string;
    japaneseTitle?: string;
    genre: StoryGenre;
    mainIdea?: string;
    targetAudience?: string;
    desiredDuration?: string;
    sceneCount?: number;
    emotionalTone?: string;
    endingType?: string;
    storyScript?: StoryScript;
    scenes?: Episode['scenes'];
  }) => Promise<string>;
  onUpdateEpisode: (episodeId: string, updates: Partial<Episode>) => Promise<void>;
}

const GENRES: StoryGenre[] = [
  'Drama',
  'Business',
  'Revenge',
  'Mystery',
  'Romance',
  'Historical',
  'Psychological',
  'Thriller',
  'Inspirational',
];

export function StoryStudioView({
  projects,
  episodes,
  characters,
  selectedEpisodeId,
  onSelectEpisode,
  onCreateEpisode,
  onUpdateEpisode,
}: StoryStudioViewProps) {
  const activeEpisode =
    episodes.find((e) => e.episodeId === selectedEpisodeId) ?? episodes[0] ?? null;

  const [projectId, setProjectId] = useState(
    activeEpisode?.projectId ?? projects[0]?.projectId ?? '',
  );
  const [title, setTitle] = useState(activeEpisode?.title ?? '');
  const [genre, setGenre] = useState<StoryGenre>(activeEpisode?.genre ?? 'Drama');
  const [mainIdea, setMainIdea] = useState(activeEpisode?.mainIdea ?? '');
  const [targetAudience, setTargetAudience] = useState(
    activeEpisode?.targetAudience ?? 'Adult Japanese YouTube Story Audience (25–45)',
  );
  const [desiredDuration, setDesiredDuration] = useState(
    activeEpisode?.desiredDuration ?? '3 minutes',
  );
  const [sceneCount, setSceneCount] = useState<number>(activeEpisode?.sceneCount ?? 6);
  const [emotionalTone, setEmotionalTone] = useState(
    activeEpisode?.emotionalTone ?? 'Suspenseful, Atmospheric, Poignant',
  );
  const [endingType, setEndingType] = useState(
    activeEpisode?.endingType ?? 'Bittersweet Revelation',
  );

  const [scriptDraft, setScriptDraft] = useState<StoryScript | null>(
    activeEpisode?.storyScript ?? null,
  );
  const [editMode, setEditMode] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [statusNotice, setStatusNotice] = useState<string | null>(null);

  useEffect(() => {
    if (activeEpisode) {
      setProjectId(activeEpisode.projectId);
      setTitle(activeEpisode.title);
      setGenre(activeEpisode.genre);
      setMainIdea(activeEpisode.mainIdea ?? '');
      setTargetAudience(
        activeEpisode.targetAudience ?? 'Adult Japanese YouTube Story Audience (25–45)',
      );
      setDesiredDuration(activeEpisode.desiredDuration ?? '3 minutes');
      setSceneCount(activeEpisode.sceneCount ?? 6);
      setEmotionalTone(activeEpisode.emotionalTone ?? 'Suspenseful, Atmospheric, Poignant');
      setEndingType(activeEpisode.endingType ?? 'Bittersweet Revelation');
      setScriptDraft(activeEpisode.storyScript ?? null);
    }
  }, [activeEpisode?.episodeId]);

  const handleGenerate = async () => {
    const pid = projectId || projects[0]?.projectId;
    if (!pid) {
      setErrorMsg('Create a project first in the Projects tab.');
      return;
    }
    if (!title.trim() || !mainIdea.trim()) {
      setErrorMsg('Please enter both a Story Title and Main Idea.');
      return;
    }

    setGenerating(true);
    setErrorMsg(null);
    setStatusNotice(null);

    try {
      const proj = projects.find((p) => p.projectId === pid);
      const projCharacters = characters.filter((c) => c.projectId === pid);

      const res = await apiFetch<{ story: StoryScript }>('/api/gemini/story', {
        method: 'POST',
        body: JSON.stringify({
          title: title.trim(),
          genre,
          mainIdea: mainIdea.trim(),
          targetAudience: targetAudience.trim(),
          desiredDuration: desiredDuration.trim(),
          sceneCount,
          emotionalTone: emotionalTone.trim(),
          endingType: endingType.trim(),
          visualStyle: proj?.visualStyle ?? 'Motion Comic',
          characters: projCharacters,
        }),
      });

      setScriptDraft(res.story);
      setStatusNotice('Original Japanese script generated cleanly in structured JSON.');

      const safeSceneCount = Math.min(Math.max(Math.round(Number(sceneCount) || 6), 1), 50);

      if (activeEpisode) {
        await onUpdateEpisode(activeEpisode.episodeId, {
          title: title.trim().slice(0, 200),
          japaneseTitle: (res.story.japaneseTitle || title.trim()).slice(0, 300),
          genre,
          mainIdea: mainIdea.trim().slice(0, 8000),
          targetAudience: targetAudience.trim().slice(0, 300),
          desiredDuration: desiredDuration.trim().slice(0, 120),
          sceneCount: res.story.scenes.length || safeSceneCount,
          emotionalTone: emotionalTone.trim().slice(0, 300),
          endingType: endingType.trim().slice(0, 300),
          storyScript: res.story,
          scenes: res.story.scenes.slice(0, 50),
          scriptApproved: false,
        });
      } else {
        const newEpId = await onCreateEpisode({
          projectId: pid,
          title: title.trim().slice(0, 200),
          japaneseTitle: (res.story.japaneseTitle || title.trim()).slice(0, 300),
          genre,
          mainIdea: mainIdea.trim().slice(0, 8000),
          targetAudience: targetAudience.trim().slice(0, 300),
          desiredDuration: desiredDuration.trim().slice(0, 120),
          sceneCount: res.story.scenes.length || safeSceneCount,
          emotionalTone: emotionalTone.trim().slice(0, 300),
          endingType: endingType.trim().slice(0, 300),
          storyScript: res.story,
          scenes: res.story.scenes.slice(0, 50),
        });
        onSelectEpisode(newEpId);
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Story generation failed.');
    } finally {
      setGenerating(false);
    }
  };

  const handleSaveDraft = async (approve = false) => {
    if (!activeEpisode || !scriptDraft) return;
    setSaving(true);
    setErrorMsg(null);
    setStatusNotice(null);
    try {
      const safeScenes = (scriptDraft.scenes ?? []).slice(0, 50);
      await onUpdateEpisode(activeEpisode.episodeId, {
        title: (title.trim() || activeEpisode.title).slice(0, 200),
        japaneseTitle: (scriptDraft.japaneseTitle || title.trim()).slice(0, 300),
        genre,
        mainIdea: mainIdea.slice(0, 8000),
        targetAudience: targetAudience.trim().slice(0, 300),
        desiredDuration: desiredDuration.trim().slice(0, 120),
        sceneCount: Math.min(Math.max(safeScenes.length || Math.round(Number(sceneCount) || 6), 1), 50),
        emotionalTone: emotionalTone.trim().slice(0, 300),
        endingType: endingType.trim().slice(0, 300),
        storyScript: scriptDraft,
        scenes: safeScenes,
        scriptApproved: approve ? true : activeEpisode.scriptApproved,
      });
      setStatusNotice(
        approve
          ? 'Script approved and synced to Scene Generator.'
          : 'Script draft saved to Cloud Firestore.',
      );
      setEditMode(false);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to save draft.');
    } finally {
      setSaving(false);
    }
  };

  const updateSceneField = (
    idx: number,
    field: 'narration' | 'sceneDescription' | 'emotionalDirection' | 'visualDescription' | 'transition',
    value: string,
  ) => {
    if (!scriptDraft) return;
    const nextScenes = scriptDraft.scenes.map((sc, i) =>
      i === idx ? { ...sc, [field]: value } : sc,
    );
    setScriptDraft({ ...scriptDraft, scenes: nextScenes });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">Story Studio</h1>
          <p className="text-sm text-[#94A3B8] mt-1">
            Generate original structured Japanese stories and scene plans via server-side Gemini.
          </p>
        </div>

        {episodes.length > 0 && (
          <div className="flex items-center gap-2">
            <label className="text-xs text-[#94A3B8] whitespace-nowrap">Episode:</label>
            <select
              value={activeEpisode?.episodeId ?? ''}
              onChange={(e) => onSelectEpisode(e.target.value)}
              className="bg-[#121824] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9] max-w-xs"
            >
              {episodes.map((ep) => (
                <option key={ep.episodeId} value={ep.episodeId}>
                  {ep.title}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      <div className="grid xl:grid-cols-12 gap-6">
        {/* Left: Story Configuration Panel */}
        <div className="xl:col-span-5 bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-4">
          <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
            Story Direction
          </h2>

          {errorMsg && (
            <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">
              {errorMsg}
            </div>
          )}
          {statusNotice && (
            <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300">
              {statusNotice}
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-[#94A3B8]">Project</label>
            <select
              value={projectId}
              onChange={(e) => setProjectId(e.target.value)}
              className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
            >
              {projects.length === 0 && <option value="">No projects created</option>}
              {projects.map((p) => (
                <option key={p.projectId} value={p.projectId}>
                  {p.title}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-[#94A3B8]">Story Title</label>
              <input
                type="text"
                maxLength={200}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Midnight Watchmaker"
                className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-[#94A3B8]">Genre</label>
              <select
                value={genre}
                onChange={(e) => setGenre(e.target.value as StoryGenre)}
                className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
              >
                {GENRES.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-[#94A3B8]">Main Idea / Premise</label>
            <textarea
              rows={4}
              maxLength={8000}
              value={mainIdea}
              onChange={(e) => setMainIdea(e.target.value)}
              placeholder="Describe the original plot, central conflict, and setting in Japan..."
              className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-[#94A3B8]">Target Audience</label>
              <input
                type="text"
                maxLength={300}
                value={targetAudience}
                onChange={(e) => setTargetAudience(e.target.value)}
                className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-[#94A3B8]">Desired Duration</label>
              <input
                type="text"
                maxLength={120}
                value={desiredDuration}
                onChange={(e) => setDesiredDuration(e.target.value)}
                className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-[#94A3B8]">Scenes</label>
              <input
                type="number"
                min={3}
                max={24}
                value={sceneCount}
                onChange={(e) => {
                  const parsed = Math.round(Number(e.target.value));
                  setSceneCount(Number.isFinite(parsed) ? Math.min(50, Math.max(1, parsed)) : 6);
                }}
                className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm font-mono-tabular text-[#F1F5F9]"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-[#94A3B8]">Emotional Tone</label>
              <input
                type="text"
                maxLength={300}
                value={emotionalTone}
                onChange={(e) => setEmotionalTone(e.target.value)}
                className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-[#94A3B8]">Ending Type</label>
              <input
                type="text"
                maxLength={300}
                value={endingType}
                onChange={(e) => setEndingType(e.target.value)}
                className="w-full bg-[#0B0F17] border border-[#232D3F] rounded-lg px-3 py-2 text-sm text-[#F1F5F9]"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              type="button"
              disabled={generating || projects.length === 0}
              onClick={() => void handleGenerate()}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm hover:bg-amber-400 disabled:opacity-60 cursor-pointer"
            >
              {scriptDraft ? (
                <RefreshCw className={`w-4 h-4 ${generating ? 'animate-spin' : ''}`} />
              ) : (
                <Sparkles className="w-4 h-4" />
              )}
              <span>
                {generating
                  ? 'Generating Japanese Script...'
                  : scriptDraft
                    ? 'Regenerate'
                    : 'Generate Story'}
              </span>
            </button>

            {scriptDraft && (
              <>
                <button
                  type="button"
                  onClick={() => setEditMode(!editMode)}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#171F2E] border border-[#232D3F] text-xs font-medium text-[#F1F5F9] hover:border-slate-500 cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>{editMode ? 'Finish Editing' : 'Edit Script'}</span>
                </button>
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => void handleSaveDraft(false)}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#171F2E] border border-[#232D3F] text-xs font-medium text-[#F1F5F9] hover:border-slate-500 cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Draft</span>
                </button>
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => void handleSaveDraft(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 text-white text-xs font-medium hover:bg-emerald-500 cursor-pointer"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Approve Script</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Right: Structured Japanese Script Viewer / Editor */}
        <div className="xl:col-span-7 bg-[#121824] border border-[#232D3F] rounded-xl p-6 space-y-5">
          <div className="flex items-center justify-between border-b border-[#232D3F] pb-4">
            <div>
              <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
                {scriptDraft?.japaneseTitle || 'Structured Japanese Script'}
              </h2>
              {activeEpisode && (
                <div className="flex items-center gap-2 text-xs text-[#94A3B8] mt-1">
                  <ProductionStatusLabel status={activeEpisode.status} />
                  <span aria-hidden="true">·</span>
                  <span>
                    {activeEpisode.scriptApproved ? 'Script Approved' : 'Draft Pending Approval'}
                  </span>
                </div>
              )}
            </div>
            {scriptDraft && (
              <span className="font-mono-tabular text-xs text-[#94A3B8]">
                {scriptDraft.scenes.length} scenes · ~{scriptDraft.estimatedDurationSec}s
              </span>
            )}
          </div>

          {!scriptDraft ? (
            <div className="py-16 text-center space-y-2 border border-dashed border-[#232D3F] rounded-lg">
              <p className="text-sm text-[#94A3B8]">
                Configure your story direction and click Generate Story.
              </p>
              <p className="text-xs text-[#64748B]">
                All stories are original Japanese scripts returned in structured JSON with narration, dialogue, emotional cues, and camera transitions.
              </p>
            </div>
          ) : (
            <div className="space-y-4 max-h-[700px] overflow-y-auto pr-1">
              <div className="p-4 rounded-lg bg-[#0B0F17] border border-[#232D3F] space-y-2">
                <div className="text-xs font-medium text-[#94A3B8]">Synopsis & Narrator Direction</div>
                <p className="text-sm text-[#F1F5F9] leading-relaxed">{scriptDraft.synopsis}</p>
                <p className="text-xs text-amber-400/90">
                  Voice cue: {scriptDraft.narratorDirection}
                </p>
              </div>

              {scriptDraft.scenes.map((sc, idx) => (
                <div
                  key={sc.sceneNumber}
                  className="p-4 rounded-lg bg-[#0B0F17] border border-[#232D3F] space-y-3"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                    <span className="font-semibold text-amber-400">
                      Scene {sc.sceneNumber} · {sc.location} ({sc.timeOfDay})
                    </span>
                    <span className="font-mono-tabular text-[#94A3B8]">
                      {sc.durationSeconds}s · {sc.cameraMovement} · {sc.mood}
                    </span>
                  </div>

                  {editMode ? (
                    <div className="space-y-2">
                      <label className="text-[11px] text-[#94A3B8]">Japanese Narration</label>
                      <textarea
                        rows={2}
                        value={sc.narration}
                        onChange={(e) => updateSceneField(idx, 'narration', e.target.value)}
                        className="w-full bg-[#121824] border border-[#232D3F] rounded p-2 text-sm text-[#F1F5F9]"
                      />
                      <label className="text-[11px] text-[#94A3B8]">Scene Description</label>
                      <textarea
                        rows={2}
                        value={sc.sceneDescription}
                        onChange={(e) => updateSceneField(idx, 'sceneDescription', e.target.value)}
                        className="w-full bg-[#121824] border border-[#232D3F] rounded p-2 text-xs text-[#CBD5E1]"
                      />
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[11px] text-[#94A3B8]">Emotional Direction</label>
                          <input
                            type="text"
                            value={sc.emotionalDirection}
                            onChange={(e) =>
                              updateSceneField(idx, 'emotionalDirection', e.target.value)
                            }
                            className="w-full bg-[#121824] border border-[#232D3F] rounded p-2 text-xs text-[#CBD5E1]"
                          />
                        </div>
                        <div>
                          <label className="text-[11px] text-[#94A3B8]">Transition</label>
                          <input
                            type="text"
                            value={sc.transition}
                            onChange={(e) => updateSceneField(idx, 'transition', e.target.value)}
                            className="w-full bg-[#121824] border border-[#232D3F] rounded p-2 text-xs text-[#CBD5E1]"
                          />
                        </div>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="space-y-1">
                        <div className="text-[11px] text-[#64748B]">Narration</div>
                        <p className="text-sm text-[#F1F5F9] leading-relaxed">{sc.narration}</p>
                      </div>

                      {sc.dialogue?.length > 0 && (
                        <div className="space-y-1.5 border-t border-[#232D3F]/70 pt-2">
                          <div className="text-[11px] text-[#64748B]">Dialogue</div>
                          {sc.dialogue.map((d, dIdx) => (
                            <div key={dIdx} className="text-xs text-[#E2E8F0]">
                              <span className="font-semibold text-amber-300">{d.characterName}</span>{' '}
                              <span className="text-[#64748B]">({d.emotion})</span>: 「{d.line}」
                            </div>
                          ))}
                        </div>
                      )}

                      <div className="grid sm:grid-cols-2 gap-2 text-xs text-[#94A3B8] border-t border-[#232D3F]/70 pt-2">
                        <div>
                          <span className="text-[#64748B]">Visual:</span> {sc.visualDescription}
                        </div>
                        <div>
                          <span className="text-[#64748B]">Emotion / Transition:</span>{' '}
                          {sc.emotionalDirection} · {sc.transition}
                        </div>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
