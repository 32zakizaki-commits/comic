import { useCallback, useEffect, useRef, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { getDownloadURL, ref, uploadBytes } from 'firebase/storage';
import { useFirebase } from '../contexts/FirebaseContext';
import { apiFetch } from '../lib/apiClient';
import { db, handleFirestoreError, OperationType, storage } from '../lib/firebase';
import type {
  ApprovalRecord,
  Character,
  ConnectionState,
  Episode,
  IntegrationStatus,
  JobType,
  ProductionJob,
  ProductionStatus,
  Project,
  Scene,
  StoryGenre,
  StudioSettings,
  VisualStyle,
  WorkerNode,
} from '../types/studio';

function makeId(prefix: string): string {
  const rand = Math.random().toString(36).slice(2, 10);
  return `${prefix}_${Date.now().toString(36)}_${rand}`;
}

export interface FirestoreJobRecord {
  jobId: string;
  userId: string;
  projectId: string;
  episodeId: string;
  type: JobType;
  status: ProductionStatus;
  progress: number;
  sceneNumber?: number;
  stageMessage?: string;
  workerId?: string;
  errorMessage?: string;
  outputUrl?: string;
  attemptCount?: number;
  maxAttempts?: number;
  leaseExpiresAt?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

const ACTIVE_JOB_STATUSES: ProductionStatus[] = ['queued', 'claimed', 'processing', 'uploading'];

const VALID_VISUAL_STYLES = new Set<VisualStyle>([
  'Motion Comic',
  'Seinen Ink',
  'Watercolor Anime',
  'Noir Manga',
]);
const VALID_PROJECT_STATUSES = new Set<Project['status']>(['active', 'archived', 'completed']);
const VALID_GENRES = new Set<StoryGenre>([
  'Drama',
  'Business',
  'Revenge',
  'Mystery',
  'Romance',
  'Historical',
  'Psychological',
  'Thriller',
  'Inspirational',
]);
const VALID_PRODUCTION_STATUSES = new Set<ProductionStatus>([
  'draft',
  'queued',
  'claimed',
  'processing',
  'uploading',
  'completed',
  'failed',
  'cancelled',
  'pending_approval',
  'approved',
  'rejected',
]);

function stripUndefinedDeep<T>(value: T): T {
  if (Array.isArray(value)) {
    return value.filter((item) => item !== undefined).map((item) => stripUndefinedDeep(item)) as T;
  }
  if (value !== null && typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (v !== undefined) {
        out[k] = stripUndefinedDeep(v);
      }
    }
    return out as T;
  }
  return value;
}

function clampInt(value: unknown, min: number, max: number, fallback: number): number {
  const num = Number(value);
  if (!Number.isFinite(num)) return fallback;
  return Math.min(max, Math.max(min, Math.round(num)));
}

function sanitizeEpisodeUpdates(updates: Partial<Episode>): Record<string, unknown> {
  const clean: Record<string, unknown> = {};

  if (typeof updates.title === 'string') {
    const trimmed = updates.title.trim().slice(0, 200);
    if (trimmed.length >= 1) {
      clean.title = trimmed;
    }
  }
  if (typeof updates.japaneseTitle === 'string') {
    clean.japaneseTitle = updates.japaneseTitle.trim().slice(0, 300);
  }
  if (typeof updates.genre === 'string' && VALID_GENRES.has(updates.genre as StoryGenre)) {
    clean.genre = updates.genre;
  }
  if (typeof updates.mainIdea === 'string') {
    clean.mainIdea = updates.mainIdea.slice(0, 8000);
  }
  if (typeof updates.targetAudience === 'string') {
    clean.targetAudience = updates.targetAudience.trim().slice(0, 300);
  }
  if (typeof updates.desiredDuration === 'string') {
    clean.desiredDuration = updates.desiredDuration.trim().slice(0, 120);
  }
  if (updates.sceneCount !== undefined && updates.sceneCount !== null) {
    clean.sceneCount = clampInt(updates.sceneCount, 1, 50, 6);
  }
  if (typeof updates.emotionalTone === 'string') {
    clean.emotionalTone = updates.emotionalTone.trim().slice(0, 300);
  }
  if (typeof updates.endingType === 'string') {
    clean.endingType = updates.endingType.trim().slice(0, 300);
  }
  if (
    typeof updates.status === 'string' &&
    VALID_PRODUCTION_STATUSES.has(updates.status as ProductionStatus)
  ) {
    clean.status = updates.status;
  }
  if (typeof updates.scriptApproved === 'boolean') {
    clean.scriptApproved = updates.scriptApproved;
  }
  if (updates.storyScript && typeof updates.storyScript === 'object') {
    clean.storyScript = stripUndefinedDeep(updates.storyScript);
  }
  if (Array.isArray(updates.scenes)) {
    clean.scenes = updates.scenes
      .filter((s): s is Scene => Boolean(s && typeof s === 'object'))
      .slice(0, 50)
      .map((s) => stripUndefinedDeep(s));
  }
  if (typeof updates.narrationAudioUrl === 'string') {
    clean.narrationAudioUrl = updates.narrationAudioUrl.trim().slice(0, 1000);
  }
  if (updates.videoOutput && typeof updates.videoOutput === 'object') {
    clean.videoOutput = stripUndefinedDeep(updates.videoOutput);
  }
  if (updates.youtubeDraft && typeof updates.youtubeDraft === 'object') {
    clean.youtubeDraft = stripUndefinedDeep(updates.youtubeDraft);
  }

  return clean;
}

function getJobFingerprint(job: {
  status: ProductionStatus;
  progress: number;
  stageMessage?: string;
  workerId?: string;
  errorMessage?: string;
  outputUrl?: string;
  attemptCount?: number;
  leaseExpiresAt?: string;
}): string {
  return `${job.status}|${Math.round(job.progress)}|${job.stageMessage ?? ''}|${job.workerId ?? ''}|${job.errorMessage ?? ''}|${job.outputUrl ?? ''}|${job.attemptCount ?? 0}|${job.leaseExpiresAt ?? ''}`;
}

export function useStudioData() {
  const { user, authReady, firestoreStatus, firestoreError, recheckFirestoreConnection } =
    useFirebase();
  const [projects, setProjects] = useState<Project[]>([]);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [approvals, setApprovals] = useState<ApprovalRecord[]>([]);
  const [settings, setSettings] = useState<StudioSettings | null>(null);

  const [jobs, setJobs] = useState<ProductionJob[]>([]);
  const [firestoreJobs, setFirestoreJobs] = useState<FirestoreJobRecord[]>([]);
  const [workers, setWorkers] = useState<WorkerNode[]>([]);
  const [integrations, setIntegrations] = useState<IntegrationStatus | null>(null);

  const [loadingData, setLoadingData] = useState(true);
  const [backendError, setBackendError] = useState<string | null>(null);
  const [apiStatus, setApiStatus] = useState<ConnectionState>('checking');
  const [apiError, setApiError] = useState<string | null>(null);

  const syncedJobOutputsRef = useRef<Set<string>>(new Set());
  const mirroredJobFingerprintRef = useRef<Map<string, string>>(new Map());
  const firestoreJobsMapRef = useRef<Map<string, FirestoreJobRecord>>(new Map());
  const syncingJobIdsRef = useRef<Set<string>>(new Set());
  const rehydratingJobIdsRef = useRef<Set<string>>(new Set());
  const jobsListenerReadyRef = useRef(false);
  const episodesListenerReadyRef = useRef(false);
  const episodeIdsRef = useRef<Set<string>>(new Set());
  const episodesMapRef = useRef<Map<string, Episode>>(new Map());
  const charactersRef = useRef<Character[]>([]);

  // Firestore real-time subscriptions (strictly gated on authReady && user)
  useEffect(() => {
    if (!authReady || !user) {
      setProjects([]);
      setCharacters([]);
      setEpisodes([]);
      setApprovals([]);
      setSettings(null);
      setFirestoreJobs([]);
      firestoreJobsMapRef.current.clear();
      mirroredJobFingerprintRef.current.clear();
      episodeIdsRef.current.clear();
      jobsListenerReadyRef.current = false;
      episodesListenerReadyRef.current = false;
      setLoadingData(false);
      return;
    }

    setLoadingData(true);

    const qProjects = query(collection(db, 'projects'), where('userId', '==', user.uid));
    const unsubProjects = onSnapshot(
      qProjects,
      (snap) => {
        const list = snap.docs.map((d) => d.data() as Project);
        setProjects(list);
        setLoadingData(false);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'projects'),
    );

    const qCharacters = query(collection(db, 'characters'), where('userId', '==', user.uid));
    const unsubChars = onSnapshot(
      qCharacters,
      (snap) => {
        const list = snap.docs.map((d) => d.data() as Character);
        charactersRef.current = list;
        setCharacters(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'characters'),
    );

    const qEpisodes = query(collection(db, 'episodes'), where('userId', '==', user.uid));
    const unsubEpisodes = onSnapshot(
      qEpisodes,
      (snap) => {
        const list = snap.docs.map((d) => d.data() as Episode);
        episodeIdsRef.current = new Set(list.map((ep) => ep.episodeId));
        const epMap = new Map<string, Episode>();
        for (const ep of list) {
          epMap.set(ep.episodeId, ep);
        }
        episodesMapRef.current = epMap;
        episodesListenerReadyRef.current = true;
        setEpisodes(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'episodes'),
    );

    const qApprovals = query(collection(db, 'approvals'), where('userId', '==', user.uid));
    const unsubApprovals = onSnapshot(
      qApprovals,
      (snap) => {
        setApprovals(snap.docs.map((d) => d.data() as ApprovalRecord));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'approvals'),
    );

    const qJobs = query(collection(db, 'jobs'), where('userId', '==', user.uid));
    const unsubJobs = onSnapshot(
      qJobs,
      (snap) => {
        const list = snap.docs.map((d) => d.data() as FirestoreJobRecord);
        const nextMap = new Map<string, FirestoreJobRecord>();
        for (const item of list) {
          nextMap.set(item.jobId, item);
          mirroredJobFingerprintRef.current.set(item.jobId, getJobFingerprint(item));
        }
        firestoreJobsMapRef.current = nextMap;
        jobsListenerReadyRef.current = true;
        setFirestoreJobs(list);
      },
      (err) => {
        console.error('[firestore] jobs listener error:', err);
      },
    );

    const settingsRef = doc(db, 'settings', user.uid);
    const unsubSettings = onSnapshot(
      settingsRef,
      (snap) => {
        if (snap.exists()) {
          setSettings(snap.data() as StudioSettings);
        } else {
          setSettings(null);
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, `settings/${user.uid}`),
    );

    return () => {
      unsubProjects();
      unsubChars();
      unsubEpisodes();
      unsubApprovals();
      unsubJobs();
      unsubSettings();
    };
  }, [authReady, user]);

  // Persist/synchronize an authoritative backend ProductionJob into Firestore /jobs/{jobId}
  const syncJobToFirestore = useCallback(
    async (job: ProductionJob, throwOnError = false): Promise<void> => {
      if (!user) return;
      if (!throwOnError) {
        if (firestoreStatus === 'offline') return;
        if (!jobsListenerReadyRef.current || !episodesListenerReadyRef.current) return;
        if (!episodeIdsRef.current.has(job.episodeId)) return;
      }

      const fingerprint = getJobFingerprint(job);
      const existingMirror = firestoreJobsMapRef.current.get(job.jobId);
      if (existingMirror && mirroredJobFingerprintRef.current.get(job.jobId) === fingerprint) {
        return;
      }
      if (syncingJobIdsRef.current.has(job.jobId)) {
        return;
      }

      syncingJobIdsRef.current.add(job.jobId);
      try {
        const jobRef = doc(db, 'jobs', job.jobId);
        const clampedProgress = Math.max(0, Math.min(100, Math.round(job.progress || 0)));

        const buildCreatePayload = (): Record<string, unknown> => {
          const docPayload: Record<string, unknown> = {
            jobId: job.jobId,
            userId: user.uid,
            projectId: job.projectId,
            episodeId: job.episodeId,
            type: job.type,
            status: job.status,
            progress: clampedProgress,
            attemptCount: Math.max(0, Math.min(10, Math.round(job.attemptCount ?? 0))),
            maxAttempts: Math.max(1, Math.min(10, Math.round(job.maxAttempts ?? 3))),
            leaseExpiresAt: (job.leaseExpiresAt ?? '').slice(0, 64),
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          };
          if (typeof job.sceneNumber === 'number') {
            docPayload.sceneNumber = Math.max(1, Math.min(200, Math.round(job.sceneNumber)));
          }
          if (job.stageMessage) docPayload.stageMessage = job.stageMessage.slice(0, 500);
          if (job.workerId) docPayload.workerId = job.workerId.slice(0, 128);
          if (job.errorMessage) docPayload.errorMessage = job.errorMessage.slice(0, 1000);
          if (job.outputUrl) docPayload.outputUrl = job.outputUrl.slice(0, 1000);
          return docPayload;
        };

        const buildUpdatePayload = (): Record<string, unknown> => ({
          status: job.status,
          progress: clampedProgress,
          stageMessage: (job.stageMessage ?? '').slice(0, 500),
          workerId: (job.workerId ?? '').slice(0, 128),
          errorMessage: (job.errorMessage ?? '').slice(0, 1000),
          outputUrl: (job.outputUrl ?? '').slice(0, 1000),
          attemptCount: Math.max(0, Math.min(10, Math.round(job.attemptCount ?? 0))),
          maxAttempts: Math.max(1, Math.min(10, Math.round(job.maxAttempts ?? 3))),
          leaseExpiresAt: (job.leaseExpiresAt ?? '').slice(0, 64),
          updatedAt: serverTimestamp(),
        });

        await runTransaction(db, async (tx) => {
          const snap = await tx.get(jobRef);
          if (!snap.exists()) {
            tx.set(jobRef, buildCreatePayload());
          } else {
            const currentData = snap.data() as FirestoreJobRecord;
            if (currentData.status === 'completed') {
              return;
            }
            tx.update(jobRef, buildUpdatePayload());
          }
        });

        mirroredJobFingerprintRef.current.set(job.jobId, fingerprint);
      } catch (error) {
        const msg = error instanceof Error ? error.message : 'Failed to sync job to Firestore.';
        if (throwOnError) {
          throw new Error(`Firestore job sync failed: ${msg}`);
        }
        console.warn('[firestore] syncJobToFirestore warning:', msg);
      } finally {
        syncingJobIdsRef.current.delete(job.jobId);
      }
    },
    [user, firestoreStatus],
  );

  // Rehydrate Firestore jobs missing from the backend queue after a server restart
  const rehydrateMissingJobs = useCallback(
    async (backendJobs: ProductionJob[]): Promise<ProductionJob[]> => {
      if (!user || !jobsListenerReadyRef.current || !episodesListenerReadyRef.current) {
        return backendJobs;
      }
      const backendIds = new Set(backendJobs.map((j) => j.jobId));
      const missingDocs: Array<Record<string, unknown>> = [];

      for (const fsJob of firestoreJobsMapRef.current.values()) {
        if (!fsJob?.jobId || backendIds.has(fsJob.jobId)) continue;
        if (rehydratingJobIdsRef.current.has(fsJob.jobId)) continue;

        const ep = episodesMapRef.current.get(fsJob.episodeId);
        if (!ep) continue;

        let reconstructedPayload: Record<string, unknown> = {};
        if (fsJob.type === 'scene_image' && typeof fsJob.sceneNumber === 'number') {
          const sc = (ep.scenes ?? []).find((s) => s.sceneNumber === fsJob.sceneNumber);
          const projChars = charactersRef.current.filter((c) => c.projectId === ep.projectId);
          if (sc) {
            reconstructedPayload = {
              sceneNumber: sc.sceneNumber,
              imagePrompt: sc.imagePrompt,
              negativePrompt: sc.negativePrompt,
              cameraMovement: sc.cameraMovement,
              characters: projChars.filter((c) => sc.characters?.includes(c.name)),
              width: 1920,
              height: 1080,
            };
          }
        } else if (fsJob.type === 'video_render' || fsJob.type === 'full_episode') {
          reconstructedPayload = {
            episodeTitle: ep.title,
            japaneseTitle: ep.japaneseTitle ?? ep.title,
            scenes: ep.scenes ?? [],
            narrationAudioUrl: ep.narrationAudioUrl ?? '',
            outputSpec: {
              resolution: '1920x1080',
              fps: 30,
              format: 'mp4',
              videoCodec: 'H.264',
              audioCodec: 'AAC',
              aspectRatio: '16:9',
            },
          };
        }

        rehydratingJobIdsRef.current.add(fsJob.jobId);
        missingDocs.push({
          jobId: fsJob.jobId,
          projectId: fsJob.projectId,
          episodeId: fsJob.episodeId,
          episodeTitle: ep.title,
          sceneNumber: fsJob.sceneNumber,
          type: fsJob.type,
          status: fsJob.status,
          progress: fsJob.progress,
          stageMessage: fsJob.stageMessage,
          payload: reconstructedPayload,
          workerId: fsJob.workerId,
          leaseExpiresAt: fsJob.leaseExpiresAt,
          attemptCount: fsJob.attemptCount ?? 0,
          maxAttempts: fsJob.maxAttempts ?? 3,
          errorMessage: fsJob.errorMessage,
          outputUrl: fsJob.outputUrl,
        });
      }

      if (missingDocs.length === 0) {
        return backendJobs;
      }

      try {
        const res = await apiFetch<{ recoveredIds?: string[]; jobs?: ProductionJob[] }>(
          '/api/jobs/rehydrate',
          {
            method: 'POST',
            body: JSON.stringify({ jobs: missingDocs }),
          },
        );
        if (Array.isArray(res?.jobs)) {
          return res.jobs;
        }
      } catch (err) {
        console.warn('[rehydrate] Failed to rehydrate Firestore jobs into backend:', err);
      } finally {
        for (const docItem of missingDocs) {
          if (typeof docItem.jobId === 'string') {
            rehydratingJobIdsRef.current.delete(docItem.jobId);
          }
        }
      }
      return backendJobs;
    },
    [user],
  );

  // Backend polling for Health, Jobs, Workers, and Integration Status
  const refreshBackendState = useCallback(async () => {
    if (!authReady || !user) return;
    try {
      const healthRes = await fetch('/api/health');
      if (!healthRes.ok) {
        throw new Error(`API healthcheck returned HTTP ${healthRes.status}`);
      }
      const [jobsRes, workersRes, statusRes] = await Promise.all([
        apiFetch<{ jobs?: ProductionJob[] }>('/api/jobs'),
        apiFetch<{ workers?: WorkerNode[] }>('/api/workers'),
        apiFetch<IntegrationStatus>('/api/integrations/status'),
      ]);

      const rawJobs = Array.isArray(jobsRes?.jobs) ? jobsRes.jobs : [];
      const safeWorkers = Array.isArray(workersRes?.workers) ? workersRes.workers : [];
      const hydratedJobs = await rehydrateMissingJobs(rawJobs);

      setJobs(hydratedJobs);
      setWorkers(safeWorkers);
      if (statusRes && typeof statusRes === 'object') {
        setIntegrations(statusRes);
      }
      setApiStatus('connected');
      setApiError(null);
      setBackendError(null);

      // Mirror any newly updated backend jobs into Firestore /jobs/{jobId}
      for (const job of hydratedJobs) {
        void syncJobToFirestore(job, false);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to sync worker/job state.';
      setApiStatus('error');
      setApiError(msg);
      setBackendError(msg);
    }
  }, [authReady, user, syncJobToFirestore, rehydrateMissingJobs]);

  const safeJobs = Array.isArray(jobs) ? jobs : [];
  const hasActiveJobs = safeJobs.some((j) => ACTIVE_JOB_STATUSES.includes(j.status));

  useEffect(() => {
    if (!authReady || !user) return;
    void refreshBackendState();
    const intervalMs = hasActiveJobs ? 2000 : 5000;
    const timer = setInterval(() => {
      void refreshBackendState();
    }, intervalMs);
    return () => clearInterval(timer);
  }, [authReady, user, hasActiveJobs, refreshBackendState]);

  useEffect(() => {
    if (!authReady || !user || firestoreStatus !== 'connected') return;
    if (!jobsListenerReadyRef.current || !episodesListenerReadyRef.current) return;
    const currentJobs = Array.isArray(jobs) ? jobs : [];
    for (const job of currentJobs) {
      void syncJobToFirestore(job, false);
    }
    if (firestoreJobs.length > currentJobs.length) {
      void rehydrateMissingJobs(currentJobs).then((updated) => {
        if (updated.length !== currentJobs.length) {
          setJobs(updated);
        }
      });
    }
  }, [
    authReady,
    user,
    firestoreStatus,
    jobs,
    episodes,
    firestoreJobs,
    syncJobToFirestore,
    rehydrateMissingJobs,
  ]);

  // Sync terminal worker job outputs (completed, pending_approval, failed) back into Firestore Episode documents
  useEffect(() => {
    const currentJobs = Array.isArray(jobs) ? jobs : [];
    if (!user || currentJobs.length === 0 || episodes.length === 0) return;

    for (const job of currentJobs) {
      const syncKey = `${job.jobId}:${job.status}:${job.outputUrl ?? ''}`;
      if (syncedJobOutputsRef.current.has(syncKey)) continue;

      if (
        job.type === 'scene_image' &&
        typeof job.sceneNumber === 'number' &&
        job.status === 'failed'
      ) {
        const ep = episodes.find((e) => e.episodeId === job.episodeId);
        if (!ep) continue;
        syncedJobOutputsRef.current.add(syncKey);
        const updatedScenes = ep.scenes.map((sc) =>
          sc.sceneNumber === job.sceneNumber
            ? { ...sc, generationStatus: 'failed' as const }
            : sc,
        );
        void updateDoc(doc(db, 'episodes', ep.episodeId), {
          scenes: updatedScenes,
          updatedAt: serverTimestamp(),
        }).catch((e) => console.error('[sync] scene failed status update error:', e));
        continue;
      }

      if (
        (job.status === 'completed' || job.status === 'pending_approval') &&
        job.outputUrl
      ) {
        const ep = episodes.find((e) => e.episodeId === job.episodeId);
        if (!ep) continue;

        syncedJobOutputsRef.current.add(syncKey);

        if (job.type === 'scene_image' && typeof job.sceneNumber === 'number') {
          const updatedScenes = ep.scenes.map((sc) =>
            sc.sceneNumber === job.sceneNumber
              ? {
                  ...sc,
                  generatedImageUrl: job.outputUrl!,
                  generationStatus: 'generated' as const,
                }
              : sc,
          );
          void updateDoc(doc(db, 'episodes', ep.episodeId), {
            scenes: updatedScenes,
            updatedAt: serverTimestamp(),
          }).catch((e) => console.error('[sync] scene update error:', e));
        } else if (job.type === 'video_render' || job.type === 'full_episode') {
          const meta = job.outputMetadata ?? {};
          const durationSec = Number(meta.durationSec) || ep.scenes.reduce((a, s) => a + s.durationSeconds, 0);
          const newHistoryEntry = {
            renderId: makeId('rnd'),
            jobId: job.jobId,
            renderedAt: job.updatedAt,
            durationSec,
            resolution: '1920x1080',
            fps: 30,
            videoUrl: job.outputUrl,
            status: 'completed' as const,
            notes: 'Rendered by Local Production Worker (FFmpeg H.264/AAC)',
          };
          const prevHistory = ep.videoOutput?.renderHistory ?? [];
          void updateDoc(doc(db, 'episodes', ep.episodeId), {
            status: 'pending_approval',
            videoOutput: {
              url: job.outputUrl,
              durationSec,
              resolution: '1920x1080',
              fps: 30,
              format: 'mp4',
              videoCodec: 'H.264',
              audioCodec: 'AAC',
              aspectRatio: '16:9',
              renderedAt: job.updatedAt,
              renderHistory: [newHistoryEntry, ...prevHistory].slice(0, 15),
            },
            updatedAt: serverTimestamp(),
          }).catch((e) => console.error('[sync] video output update error:', e));
        }
      }
    }
  }, [user, jobs, episodes]);

  // Project Actions
  const createProject = async (input: {
    title: string;
    description: string;
    visualStyle: VisualStyle;
  }): Promise<string> => {
    if (!user) throw new Error('Sign in required');
    const projectId = makeId('prj');
    try {
      await setDoc(doc(db, 'projects', projectId), {
        projectId,
        userId: user.uid,
        title: input.title.trim().slice(0, 160),
        description: input.description.trim().slice(0, 4000),
        language: 'ja',
        visualStyle: input.visualStyle || 'Motion Comic',
        status: 'active',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      return projectId;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `projects/${projectId}`);
    }
  };

  const updateProject = async (
    projectId: string,
    updates: Partial<Pick<Project, 'title' | 'description' | 'visualStyle' | 'status'>>,
  ) => {
    const clean: Record<string, unknown> = {};
    if (typeof updates.title === 'string') {
      const t = updates.title.trim().slice(0, 160);
      if (t.length >= 1) clean.title = t;
    }
    if (typeof updates.description === 'string') {
      clean.description = updates.description.trim().slice(0, 4000);
    }
    if (updates.visualStyle && VALID_VISUAL_STYLES.has(updates.visualStyle)) {
      clean.visualStyle = updates.visualStyle;
    }
    if (updates.status && VALID_PROJECT_STATUSES.has(updates.status)) {
      clean.status = updates.status;
    }
    try {
      await updateDoc(doc(db, 'projects', projectId), {
        ...clean,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `projects/${projectId}`);
    }
  };

  const deleteProject = async (projectId: string) => {
    try {
      const batch = writeBatch(db);
      for (const ch of characters.filter((c) => c.projectId === projectId)) {
        batch.delete(doc(db, 'characters', ch.characterId));
      }
      for (const ep of episodes.filter((e) => e.projectId === projectId)) {
        batch.delete(doc(db, 'episodes', ep.episodeId));
      }
      batch.delete(doc(db, 'projects', projectId));
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `projects/${projectId}`);
    }
  };

  // Episode Actions
  const createEpisode = async (input: {
    projectId: string;
    title: string;
    japaneseTitle?: string;
    genre: StoryGenre;
    mainIdea?: string;
    targetAudience?: string;
    desiredDuration?: string;
    sceneCount?: number;
    emotionalTone?: string;
    endingType?: string;
    storyScript?: Episode['storyScript'];
    scenes?: Scene[];
  }): Promise<string> => {
    if (!user) throw new Error('Sign in required');
    const episodeId = makeId('eps');
    const safeTitle = input.title.trim().slice(0, 200) || 'Untitled Episode';
    const safeGenre: StoryGenre = VALID_GENRES.has(input.genre) ? input.genre : 'Drama';
    const safeScenes = Array.isArray(input.scenes)
      ? input.scenes
          .filter((s): s is Scene => Boolean(s && typeof s === 'object'))
          .slice(0, 50)
          .map((s) => stripUndefinedDeep(s))
      : [];

    const docPayload: Record<string, unknown> = {
      episodeId,
      userId: user.uid,
      projectId: input.projectId,
      title: safeTitle,
      genre: safeGenre,
      mainIdea: (input.mainIdea ?? '').slice(0, 8000),
      targetAudience: (input.targetAudience ?? 'Japanese Motion Comic Viewers').trim().slice(0, 300),
      desiredDuration: (input.desiredDuration ?? '3 minutes').trim().slice(0, 120),
      sceneCount: clampInt(input.sceneCount, 1, 50, safeScenes.length || 6),
      emotionalTone: (input.emotionalTone ?? 'Dramatic').trim().slice(0, 300),
      endingType: (input.endingType ?? 'Twist Ending').trim().slice(0, 300),
      status: 'draft',
      scriptApproved: false,
      scenes: safeScenes,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    if (typeof input.japaneseTitle === 'string' && input.japaneseTitle.trim()) {
      docPayload.japaneseTitle = input.japaneseTitle.trim().slice(0, 300);
    }
    if (input.storyScript && typeof input.storyScript === 'object') {
      docPayload.storyScript = stripUndefinedDeep(input.storyScript);
    }

    try {
      await setDoc(doc(db, 'episodes', episodeId), docPayload);
      return episodeId;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `episodes/${episodeId}`);
    }
  };

  const updateEpisode = async (episodeId: string, updates: Partial<Episode>) => {
    const cleanUpdates = sanitizeEpisodeUpdates(updates);
    try {
      await updateDoc(doc(db, 'episodes', episodeId), {
        ...cleanUpdates,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `episodes/${episodeId}`);
    }
  };

  const deleteEpisode = async (episodeId: string) => {
    try {
      await deleteDoc(doc(db, 'episodes', episodeId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `episodes/${episodeId}`);
    }
  };

  // Character Actions
  const saveCharacter = async (
    input: Omit<Character, 'userId' | 'createdAt' | 'updatedAt'>,
    isNew: boolean,
  ) => {
    if (!user) throw new Error('Sign in required');
    const characterId = input.characterId || makeId('chr');
    const safeWeight = Number.isFinite(Number(input.ipAdapterWeight))
      ? Math.min(2, Math.max(0, Number(input.ipAdapterWeight)))
      : 0.75;
    const payload = {
      characterId,
      userId: user.uid,
      projectId: input.projectId,
      name: (input.name ?? '').trim().slice(0, 120) || 'Unnamed Character',
      ageDescription: (input.ageDescription ?? '').trim().slice(0, 120),
      personality: (input.personality ?? '').trim().slice(0, 1000),
      appearance: (input.appearance ?? '').trim().slice(0, 1500),
      clothing: (input.clothing ?? '').trim().slice(0, 1000),
      referenceImages: (Array.isArray(input.referenceImages) ? input.referenceImages : [])
        .filter((u): u is string => typeof u === 'string' && u.length > 0)
        .map((u) => u.slice(0, 1000))
        .slice(0, 5),
      comfyLoraTag: (input.comfyLoraTag ?? '').trim().slice(0, 200),
      ipAdapterWeight: safeWeight,
      voiceId: (input.voiceId ?? '').trim().slice(0, 128) || 'pNInz6obpgDQGcFmaJgB',
      voiceSettings: stripUndefinedDeep(input.voiceSettings ?? {}),
    };
    try {
      if (isNew) {
        await setDoc(doc(db, 'characters', characterId), {
          ...payload,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } else {
        const { characterId: _cid, userId: _uid, projectId: _pid, ...editable } = payload;
        await updateDoc(doc(db, 'characters', characterId), {
          ...editable,
          updatedAt: serverTimestamp(),
        });
      }
      return characterId;
    } catch (error) {
      handleFirestoreError(
        error,
        isNew ? OperationType.CREATE : OperationType.UPDATE,
        `characters/${characterId}`,
      );
    }
  };

  const deleteCharacter = async (characterId: string) => {
    try {
      await deleteDoc(doc(db, 'characters', characterId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `characters/${characterId}`);
    }
  };

  const uploadCharacterReferenceImage = async (
    projectId: string,
    characterId: string,
    file: File,
  ): Promise<string> => {
    if (!user) throw new Error('Sign in required');
    const allowedTypes = ['image/png', 'image/jpeg', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      throw new Error('Only PNG, JPEG, or WEBP reference images are supported.');
    }
    if (file.size > 5 * 1024 * 1024) {
      throw new Error('Reference image must be 5 MB or smaller.');
    }

    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    const storagePath = `users/${user.uid}/projects/${projectId}/characters/${characterId}/${Date.now()}_${safeName}`;
    const storageRef = ref(storage, storagePath);
    await uploadBytes(storageRef, file, { contentType: file.type });
    return getDownloadURL(storageRef);
  };

  const [lastJobError, setLastJobError] = useState<string | null>(null);

  // Job Dispatch Actions
  const enqueueJob = async (input: {
    projectId: string;
    episodeId: string;
    episodeTitle: string;
    sceneNumber?: number;
    type: JobType;
    payload: Record<string, unknown>;
    idempotencyKey?: string;
  }): Promise<{ job: ProductionJob; deduplicated: boolean }> => {
    setLastJobError(null);
    try {
      const res = await apiFetch<{ job: ProductionJob; deduplicated: boolean }>('/api/jobs', {
        method: 'POST',
        body: JSON.stringify(input),
      });
      if (!res.job?.jobId) {
        throw new Error('Backend created job without returning a valid jobId.');
      }
      await syncJobToFirestore(res.job, true);
      setJobs((prev) => {
        const current = Array.isArray(prev) ? prev : [];
        const filtered = current.filter((j) => j.jobId !== res.job.jobId);
        return [res.job, ...filtered];
      });
      await refreshBackendState();
      return res;
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Failed to create job.';
      setLastJobError(msg);
      throw error;
    }
  };

  const cancelJob = async (jobId: string) => {
    setLastJobError(null);
    try {
      const res = await apiFetch<{ job: ProductionJob }>(
        `/api/jobs/${encodeURIComponent(jobId)}/cancel`,
        { method: 'POST' },
      );
      if (res.job) {
        await syncJobToFirestore(res.job, false);
      }
      await refreshBackendState();
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Failed to cancel job.';
      setLastJobError(msg);
      throw error;
    }
  };

  const retryJob = async (jobId: string) => {
    setLastJobError(null);
    try {
      const res = await apiFetch<{ job: ProductionJob }>(
        `/api/jobs/${encodeURIComponent(jobId)}/retry`,
        { method: 'POST' },
      );
      if (res.job) {
        await syncJobToFirestore(res.job, false);
      }
      await refreshBackendState();
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Failed to retry job.';
      setLastJobError(msg);
      throw error;
    }
  };

  const recheckConnections = async () => {
    await Promise.all([refreshBackendState(), recheckFirestoreConnection()]);
  };

  // Approval Action
  const submitApprovalReview = async (input: {
    episode: Episode;
    decision: 'approved' | 'rejected' | 'changes_requested';
    comments: string;
  }) => {
    if (!user) throw new Error('Sign in required');
    const approvalId = makeId('apr');

    await apiFetch(`/api/approvals/${encodeURIComponent(approvalId)}/review`, {
      method: 'POST',
      body: JSON.stringify({
        episodeId: input.episode.episodeId,
        projectId: input.episode.projectId,
        decision: input.decision,
        comments: input.comments,
      }),
    });

    try {
      await setDoc(doc(db, 'approvals', approvalId), {
        approvalId,
        userId: user.uid,
        projectId: input.episode.projectId,
        episodeId: input.episode.episodeId,
        reviewerId: user.uid,
        decision: input.decision,
        comments: input.comments.slice(0, 2000),
        reviewedAt: serverTimestamp(),
      });

      const nextStatus =
        input.decision === 'approved'
          ? 'approved'
          : input.decision === 'rejected'
            ? 'rejected'
            : 'draft';

      await updateDoc(doc(db, 'episodes', input.episode.episodeId), {
        status: nextStatus,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `approvals/${approvalId}`);
    }

    await refreshBackendState();
  };

  // Settings Save
  const saveStudioSettings = async (
    next: Omit<StudioSettings, 'userId' | 'updatedAt'>,
  ) => {
    if (!user) throw new Error('Sign in required');
    try {
      await setDoc(doc(db, 'settings', user.uid), {
        userId: user.uid,
        comfyuiUrl: (next.comfyuiUrl ?? 'http://127.0.0.1:8188').trim().slice(0, 255),
        defaultVoiceDirection: (next.defaultVoiceDirection ?? '').trim().slice(0, 300),
        videoResolution: '1920x1080',
        videoFps: 30,
        videoFormat: 'mp4',
        videoCodec: 'H.264',
        audioCodec: 'AAC',
        aspectRatio: '16:9',
        storagePrefix: (next.storagePrefix ?? '').trim().slice(0, 200),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `settings/${user.uid}`);
    }
  };

  const updateEpisodeScenes = async (episodeId: string, scenes: Scene[]) => {
    await updateEpisode(episodeId, { scenes });
  };

  return {
    projects: Array.isArray(projects) ? projects : [],
    characters: Array.isArray(characters) ? characters : [],
    episodes: Array.isArray(episodes) ? episodes : [],
    approvals: Array.isArray(approvals) ? approvals : [],
    settings,
    jobs: safeJobs,
    firestoreJobs: Array.isArray(firestoreJobs) ? firestoreJobs : [],
    workers: Array.isArray(workers) ? workers : [],
    integrations,
    loadingData,
    backendError,
    apiStatus,
    apiError,
    firestoreStatus,
    firestoreError,
    lastJobError,
    refreshBackendState,
    recheckConnections,
    createProject,
    updateProject,
    deleteProject,
    createEpisode,
    updateEpisode,
    updateEpisodeScenes,
    deleteEpisode,
    saveCharacter,
    deleteCharacter,
    uploadCharacterReferenceImage,
    enqueueJob,
    cancelJob,
    retryJob,
    submitApprovalReview,
    saveStudioSettings,
  };
}
