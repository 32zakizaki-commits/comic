import { Menu, RefreshCw } from 'lucide-react';
import { useState } from 'react';
import { ApprovalCenterView } from './components/ApprovalCenterView';
import { CharacterManagerView } from './components/CharacterManagerView';
import { DashboardView } from './components/DashboardView';
import { LoginScreen } from './components/LoginScreen';
import { ProductionQueueView } from './components/ProductionQueueView';
import { ProjectsView } from './components/ProjectsView';
import { SceneGeneratorView } from './components/SceneGeneratorView';
import { SettingsView } from './components/SettingsView';
import { Sidebar } from './components/Sidebar';
import { StoryStudioView } from './components/StoryStudioView';
import { VideoComposerView } from './components/VideoComposerView';
import { VoiceStudioView } from './components/VoiceStudioView';
import { WorkerMonitorView } from './components/WorkerMonitorView';
import { WorkerSetupView } from './components/WorkerSetupView';
import { YouTubePublishingView } from './components/YouTubePublishingView';
import { useFirebase } from './contexts/FirebaseContext';
import { useStudioData } from './hooks/useStudioData';
import type { NavSection } from './types/studio';

const SECTION_LABELS: Record<NavSection, string> = {
  dashboard: 'Dashboard',
  projects: 'Projects',
  'story-studio': 'Story Studio',
  characters: 'Character Manager',
  scenes: 'Scene Generator',
  'voice-studio': 'Voice Studio',
  'video-composer': 'Video Composer',
  'production-queue': 'Production Queue',
  'approval-center': 'Approval Center',
  'worker-monitor': 'Worker Monitor',
  'worker-setup': 'Worker Setup',
  'youtube-publishing': 'YouTube Publishing',
  settings: 'Settings',
};

export default function App() {
  const { user, authReady, signOutUser } = useFirebase();
  const studio = useStudioData();

  const [activeSection, setActiveSection] = useState<NavSection>('dashboard');
  const [selectedEpisodeId, setSelectedEpisodeId] = useState<string | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);

  if (!authReady) {
    return (
      <div className="min-h-screen bg-[#0B0F17] flex items-center justify-center">
        <div className="text-sm text-[#94A3B8]">Initializing JapanComic Studio...</div>
      </div>
    );
  }

  if (!user) {
    return <LoginScreen />;
  }

  const handleNavigate = (section: NavSection, episodeId?: string) => {
    if (episodeId) {
      setSelectedEpisodeId(episodeId);
    }
    setActiveSection(section);
  };

  const primaryWorkerStatus = studio.workers[0]?.status ?? 'Offline';
  const pendingApprovalsCount = studio.episodes.filter(
    (e) => e.status === 'pending_approval',
  ).length;
  const queuedJobsCount = studio.jobs.filter((j) =>
    ['queued', 'claimed', 'processing', 'uploading'].includes(j.status),
  ).length;

  return (
    <div className="min-h-screen bg-[#0B0F17] text-[#F1F5F9] flex">
      <Sidebar
        activeSection={activeSection}
        onSelect={(s) => handleNavigate(s)}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
        workerStatus={primaryWorkerStatus}
        pendingApprovalsCount={pendingApprovalsCount}
        queuedJobsCount={queuedJobsCount}
        userDisplayName={user.displayName || 'Studio Producer'}
        userEmail={user.email}
        onSignOut={() => void signOutUser()}
      />

      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Bar Contract: Breadcrumb trail left, Refresh action right */}
        <header className="h-16 px-4 sm:px-8 border-b border-[#232D3F] bg-[#0B0F17]/90 backdrop-blur flex items-center justify-between gap-4 sticky top-0 z-30">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              aria-label="Open navigation"
              className="lg:hidden p-2 rounded-lg text-[#94A3B8] hover:text-[#F1F5F9] hover:bg-[#121824]"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-xs sm:text-sm min-w-0">
              <span className="text-[#64748B] hidden sm:inline">JapanComic Studio</span>
              <span className="text-[#64748B] hidden sm:inline" aria-hidden="true">
                /
              </span>
              <span className="font-medium text-[#F1F5F9] truncate">
                {SECTION_LABELS[activeSection]}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => void studio.refreshBackendState()}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#121824] border border-[#232D3F] text-xs font-medium text-[#CBD5E1] hover:text-[#F1F5F9] hover:border-slate-500 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Sync State</span>
          </button>
        </header>

        <main className="flex-1 p-4 sm:p-8 max-w-[1440px] w-full mx-auto">
          {studio.backendError && (
            <div className="mb-6 p-3.5 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300 flex items-center justify-between gap-3">
              <span>{studio.backendError}</span>
              <button
                type="button"
                onClick={() => void studio.refreshBackendState()}
                className="underline text-red-200 shrink-0 cursor-pointer"
              >
                Retry
              </button>
            </div>
          )}

          {studio.loadingData ? (
            <div className="space-y-4">
              <div className="h-8 w-56 bg-[#121824] rounded-lg animate-pulse" />
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="h-24 bg-[#121824] rounded-xl animate-pulse" />
                ))}
              </div>
            </div>
          ) : (
            <>
              {activeSection === 'dashboard' && (
                <DashboardView
                  projects={studio.projects}
                  episodes={studio.episodes}
                  jobs={studio.jobs}
                  workers={studio.workers}
                  onNavigate={handleNavigate}
                  onCreateQuickEpisode={studio.createEpisode}
                />
              )}

              {activeSection === 'projects' && (
                <ProjectsView
                  projects={studio.projects}
                  episodes={studio.episodes}
                  onCreateProject={studio.createProject}
                  onUpdateProject={studio.updateProject}
                  onDeleteProject={studio.deleteProject}
                  onCreateEpisode={studio.createEpisode}
                  onDeleteEpisode={studio.deleteEpisode}
                  onOpenEpisode={handleNavigate}
                />
              )}

              {activeSection === 'story-studio' && (
                <StoryStudioView
                  projects={studio.projects}
                  episodes={studio.episodes}
                  characters={studio.characters}
                  selectedEpisodeId={selectedEpisodeId}
                  onSelectEpisode={setSelectedEpisodeId}
                  onCreateEpisode={studio.createEpisode}
                  onUpdateEpisode={studio.updateEpisode}
                />
              )}

              {activeSection === 'characters' && (
                <CharacterManagerView
                  projects={studio.projects}
                  characters={studio.characters}
                  onSaveCharacter={studio.saveCharacter}
                  onDeleteCharacter={studio.deleteCharacter}
                  onUploadReferenceImage={studio.uploadCharacterReferenceImage}
                />
              )}

              {activeSection === 'scenes' && (
                <SceneGeneratorView
                  episodes={studio.episodes}
                  characters={studio.characters}
                  jobs={studio.jobs}
                  firestoreJobs={studio.firestoreJobs}
                  workers={studio.workers}
                  workerAuthConfigured={studio.integrations?.workerAuthConfigured ?? true}
                  apiStatus={studio.apiStatus}
                  apiError={studio.apiError}
                  firestoreStatus={studio.firestoreStatus}
                  firestoreError={studio.firestoreError}
                  lastJobError={studio.lastJobError}
                  selectedEpisodeId={selectedEpisodeId}
                  onSelectEpisode={setSelectedEpisodeId}
                  onUpdateEpisode={studio.updateEpisode}
                  onEnqueueJob={studio.enqueueJob}
                  onCancelJob={studio.cancelJob}
                  onRetryJob={studio.retryJob}
                  onRecheckConnections={studio.recheckConnections}
                />
              )}

              {activeSection === 'voice-studio' && (
                <VoiceStudioView
                  episodes={studio.episodes}
                  characters={studio.characters}
                  integrations={studio.integrations}
                  selectedEpisodeId={selectedEpisodeId}
                  onSelectEpisode={setSelectedEpisodeId}
                  onUpdateEpisode={studio.updateEpisode}
                />
              )}

              {activeSection === 'video-composer' && (
                <VideoComposerView
                  episodes={studio.episodes}
                  jobs={studio.jobs}
                  selectedEpisodeId={selectedEpisodeId}
                  onSelectEpisode={setSelectedEpisodeId}
                  onEnqueueJob={studio.enqueueJob}
                  onUpdateEpisode={studio.updateEpisode}
                />
              )}

              {activeSection === 'production-queue' && (
                <ProductionQueueView
                  jobs={studio.jobs}
                  onCancelJob={studio.cancelJob}
                  onRetryJob={studio.retryJob}
                />
              )}

              {activeSection === 'approval-center' && (
                <ApprovalCenterView
                  projects={studio.projects}
                  episodes={studio.episodes}
                  approvals={studio.approvals}
                  onSubmitReview={studio.submitApprovalReview}
                />
              )}

              {activeSection === 'worker-monitor' && (
                <WorkerMonitorView
                  workers={studio.workers}
                  jobs={studio.jobs}
                  workerAuthConfigured={studio.integrations?.workerAuthConfigured ?? false}
                  apiStatus={studio.apiStatus}
                  firestoreStatus={studio.firestoreStatus}
                  backendError={studio.backendError}
                  onRetryJob={studio.retryJob}
                  onCancelJob={studio.cancelJob}
                  onOpenSetup={() => handleNavigate('worker-setup')}
                />
              )}

              {activeSection === 'worker-setup' && (
                <WorkerSetupView
                  workers={studio.workers}
                  workerAuthConfigured={studio.integrations?.workerAuthConfigured ?? false}
                  sharedBackendUrl={studio.integrations?.sharedBackendUrl}
                  apiStatus={studio.apiStatus}
                  onOpenMonitor={() => handleNavigate('worker-monitor')}
                />
              )}

              {activeSection === 'youtube-publishing' && (
                <YouTubePublishingView
                  episodes={studio.episodes}
                  integrations={studio.integrations}
                  onUpdateEpisode={studio.updateEpisode}
                />
              )}

              {activeSection === 'settings' && (
                <SettingsView
                  integrations={studio.integrations}
                  settings={studio.settings}
                  onSaveSettings={studio.saveStudioSettings}
                />
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
