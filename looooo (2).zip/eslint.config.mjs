import firebaseRulesPlugin from '@firebase/eslint-plugin-security-rules';

export default [
  {
    ignores: ['dist/**/*', '.data/**/*', 'worker/**/*', 'node_modules/**/*', 'src/**/*', 'server/**/*', '*.ts', '*.tsx', '*.js'],
  },
  firebaseRulesPlugin.configs['flat/recommended'],
];
