# JapanComic Studio

Hybrid AI-powered Japanese Motion Comic production control center and Windows 11 local rendering pipeline.

## Architecture
- **Cloud Control Center**: React + TypeScript + Tailwind CSS frontend served by an Express (`server.ts`) backend deployable to Google Cloud Run.
- **Firebase**: Google Sign-In Authentication, Cloud Firestore (hardened `firestore.rules`), and Firebase Storage for character references.
- **AI & Voice**: Server-side Gemini (`gemini-4-hydrogen`) for structured Japanese story/scene generation and server-side ElevenLabs for Japanese narration and character dialogue.
- **Local Production Worker**: Windows 11 Python worker (`worker/worker.py`) executing local ComfyUI image generation and 1920x1080 30fps H.264/AAC FFmpeg video rendering over authenticated outbound HTTPS.

## Environment Variables
Copy `.env.example` and configure server-side secrets:
- `GEMINI_API_KEY`: Required for Story Studio Japanese script generation.
- `WORKER_API_SECRET`: 16+ char secret shared between Cloud backend and `worker/.env`.
- `ELEVENLABS_API_KEY` & `ELEVENLABS_DEFAULT_VOICE_ID`: Required for Voice Studio synthesis.
- `YOUTUBE_CLIENT_ID`, `YOUTUBE_CLIENT_SECRET`, `YOUTUBE_REDIRECT_URI`, `YOUTUBE_REFRESH_TOKEN`: Required to enable YouTube publishing authorization.

## Running Locally & Deploying
```bash
npm install
npm run dev      # Starts Express + Vite on port 3000
npm run build    # Builds frontend into dist/
npm start        # Runs production server on port 3000
```

See `docs/API.md`, `docs/WORKER_API.md`, and `worker/README.md` for full API and Windows 11 Worker instructions.
